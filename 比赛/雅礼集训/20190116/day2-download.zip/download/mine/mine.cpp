#include "mine.h"
void sweep(int W, int H, int K){
	return ;
}

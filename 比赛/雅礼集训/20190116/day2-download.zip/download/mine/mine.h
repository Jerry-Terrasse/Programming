void sweep(int H, int W, int K);
int open(int r, int c);

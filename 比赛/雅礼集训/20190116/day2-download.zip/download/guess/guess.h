#include<string>
int query(int l,int r);
std::string guess();

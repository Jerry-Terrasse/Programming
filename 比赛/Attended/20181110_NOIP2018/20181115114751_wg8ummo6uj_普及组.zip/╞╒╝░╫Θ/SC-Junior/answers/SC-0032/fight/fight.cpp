#include<cstdio>
#include<cmath>
using namespace std;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int p1;
	long S1=0,S2=0;
	int n,m;
	int p2;
	long cha,cha2;
	scanf("%d",&n);
	long c[n+2];
	long s1,s2;
	for(int i=1;i<=n;i++){
		scanf("%ld",&c[i]);
	}
	scanf("%d%d%ld%ld",&m,&p1,&s1,&s2);
	for(int i=1;i<=n;i++){
		if(i<m)
			S1+=(m-i)*c[i];
		if(i>m)
			S2+=(i-m)*c[i];
	}
	if(p1<m)
		S1+=(m-p1)*s1;
	if(p1>m)
		S2+=(p1-m)*s1;
	if(S1>S2){
		p2=(S1-S2)/s2;
		cha=abs(S1-S2-p2*s2);
		cha2=abs(S1-S2-(p2+1)*s2);
		p2=m+p2;
		if(p2>n)
			p2=n;
	}
	if(S2>S1){
		p2=(S2-S1)/s2;
		cha=abs(S2-S1-p2*s2);
		cha2=abs(S2-S1-(p2+1)*s2);
		p2=m-p2;
		if(p2<1)
			p2=1;
	}
	if(S2==S1)
		p2=m;
	printf("%d",p2);
	fclose(stdin);	fclose(stdout);
	return 0;
}

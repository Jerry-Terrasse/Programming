#include<cstdio>
#include<vector>
using namespace std;
struct jiedian{
	int father=0;
	int sun1;
	int sun2;
	int shu;
	int hao;
	bool zuigao;
};
jiedian	G[100010];
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n,zuigaode;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		int a;
		scanf("%d",&a);
		G[i].shu=a;
		G[i].hao=i;
	}
	for(int i=1;i<=n;i++){
		int s1,s2;
		scanf("%d%d",&s1,&s2);
		if(s1!=-1){
			G[i].sun1=s1;
			G[G[i].sun1].father	=i;
		}
		else
			G[i].sun1=-1;
		if(s2!=-1){
			G[i].sun2=s2;
			G[G[i].sun2].father	=i;
		}
		else
			G[i].sun2=-1;
		if(s1!=-1&&s2!=-1){
			G[i].zuigao=1;
			zuigaode=i;
		}
	}
	int m=1,sunhao1=G[zuigaode].sun1,sunhao2=G[zuigaode].sun2;
	if(n==1)	return printf("1");
	while(G[sunhao1].shu==G[sunhao2].shu&&sunhao1<=n&&sunhao2<=n){
		m+=2;
		if(G[sunhao1].sun1==-1||G[sunhao2].sun2==-1)
			break;
		sunhao1=G[sunhao1].sun1;
		sunhao2=G[sunhao2].sun2;
	}
	printf("%d",m);
	fclose(stdin);	fclose(stdout);
	return 0;
}

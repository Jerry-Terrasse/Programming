#include<cstdio>
#include<cstring>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char s[5];
	int S=0;
	for(int i=0;i<5;i++)
	{
		scanf("%c",&s[i]);
		if(s[i]=='\n')
			break;
	}
	for(int i=0;i<strlen(s)&&i<5;i++)
		if(s[i]!=' '&&s[i]!='\n'){
			S++;			
		}
	printf("%d",S);
	fclose(stdin);	fclose(stdout);
	return 0;
}

#include<cstdio>
using namespace std;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,j=0,o=0;
	scanf("%d%d",&n,&m);
	int t1[n];
	for(int i=1;i<=n;i++){
		scanf("%d",&t1[i]);
	}
	if(m==1)
		printf("0");
	if(m==2)
	{
		for(int i=1;i<=n;i++)
			if(t1[i]%2==1)
				j++;
			else
				o++;
		if(j>o)
			printf("%d",j);
		else
			printf("%d",o);
	}
	if(m!=1&&m!=2)
	{
		printf("%d",m-1);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}

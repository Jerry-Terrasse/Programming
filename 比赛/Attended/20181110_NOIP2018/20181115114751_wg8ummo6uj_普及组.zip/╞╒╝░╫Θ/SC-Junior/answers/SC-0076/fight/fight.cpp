#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<cstring>
#include<string>
#include<algorithm>
#include<iomanip>
#include<map>
#include<cctype>
#include<queue>
#include<stack>
using namespace std;
int read()
{
	char ch=getchar();
	int res=0,s=1;
	while(!isdigit(ch))
	{
		if(ch=='-')
		{
			s=-1;
		}
		ch=getchar();
	}
	while(isdigit(ch))
	{
		res=res*10+ch-'0';
		ch=getchar();
	}
	return res*s;
}
int n,m,p,ans;
int c[100005];
long long x,y,k,s1,s2;
unsigned long long l,h,minn=0xfffffffffffffff;
int ch;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&c[i]);
	}
	m=read();p=read();s1=read();s2=read();
	//cout<<m<<" "<<p<<" "<<s1<<" "<<s2<<endl;
	for(int i=1;i<=m-1;i++)
	{
		l+=c[i]*(m-i);
	}
	for(int i=m+1;i<=n;i++)
	{
		h+=c[i]*(i-m);
	}
	k=l-h;
	if(p<m)
	{
		k+=s1*(m-p);
	}
	if(p>m)
	{
		k-=s1*(p-m);
	}
	if(k==0)
	{
		printf("%d\n",m);
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		x=k+s2*(m-i);
		if(max(x,-x)<minn)
		{
			minn=max(k+s2*(m-i),-k-s2*(m-i));
			ans=i;
		}
	}
	printf("%d\n",ans);
	return 0;
}

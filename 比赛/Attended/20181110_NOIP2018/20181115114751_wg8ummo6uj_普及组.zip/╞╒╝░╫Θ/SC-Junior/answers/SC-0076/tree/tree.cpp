#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<cstring>
#include<string>
#include<algorithm>
#include<iomanip>
#include<map>
#include<cctype>
#include<queue>
#include<stack>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cout<<"3"<<endl;
	return 0;
}

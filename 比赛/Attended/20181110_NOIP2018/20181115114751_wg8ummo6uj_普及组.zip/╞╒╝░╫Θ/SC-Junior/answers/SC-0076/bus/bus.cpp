#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<cstring>
#include<string>
#include<algorithm>
#include<iomanip>
#include<map>
#include<cctype>
#include<queue>
#include<stack>
using namespace std;
int read()
{
	char ch=getchar();
	int res=0,s=1;
	while(!isdigit(ch))
	{
		if(ch=='-')
		{
			s=-1;
		}
		ch=getchar();
	}
	while(isdigit(ch))
	{
		res=res*10+ch-'0';
		ch=getchar();
	}
	return res*s;
}
struct node
{
	int time,num;
}
q[505];
int n,m,t,a[4000001],cnt,ans;
/*void DFS(int now,int nowti,int sum,int k)
{
	cout<<now<<" "<<nowti<<" "<<sum<<" "<<k<<endl;
	if(k==0)
	{
		if(sum<ans)
		{
			ans=sum;
		}
		return;
	}
	if(nowti>q[now+1].time)
	{
		q[now+1].num+=q[now].num;
		DFS(++now,nowti,sum+(q[now+1].time-q[now].time)*q[now].num,k);	
		q[now+1].num-=q[now].num;
	}
	else
	{
		for(int i=0;i<=1;i++)
		{
			if(!i)
			{
				if(nowti>q[now].time)
				{
					k-=q[now].num;
					DFS(now+1,nowti+m,sum+(nowti-q[now].time)*q[now].num,k);
					k+=q[now].num;
				}
				else
				{
					DFS(now+1,q[now+1].time,sum+(q[now+1].time-q[now].time)*q[now].num,k);
				}
			}
			else
			{
				q[now+1].num+=q[now].num;
				sum+=(q[now+1].time-q[now].time)*q[now].num;
				DFS(++now,nowti,sum,k);
				sum-=(q[now+1].time-q[now].time)*q[now].num;	
				q[now+1].num-=q[now].num;
			}
		}
	}
}*/
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;i++)
	{
		t=read();
		a[t]++;
	}
	if(m==1)
	{
		printf("0\n");
		return 0;
	}
	for(int i=1;i<=4000000;i++)
	{
		if(a[i]!=0)
		{
			cnt++;
			q[cnt].time=i;
			q[cnt].num=a[i];
		}
	}
	if(m==2)
	{
		int s1,s2;
		for(int i=1;i<=cnt;i++)
		{
			if(q[i].time%2==0)
			{
				s1++;
			}
			else
			{
				s2++;
			}
		}
		if(s1>=s2)
		{
			for(int i=1;i<=cnt;i++)
			{
				if(q[i].time%2==1)
				{
					int k=i;
					while(q[i].time%2!=0)
					{
						k++;
					}
					ans+=(q[k].time-q[i].time)*q[i].num;
				}
			}
		}
		else
		{
			for(int i=1;i<=cnt;i++)
			{
				if(q[i].time%2==0)
				{
					int k=i;
					while(q[i].time%2==0)
					{
						k++;
					}
					ans+=(q[k].time-q[i].time)*q[i].num;
				}
			}
		}
		printf("%d\n",ans);
		return 0;
	}
	//DFS(1,q[1].time,0,n);
	//printf("%d\n",ans);
	return 0;
}

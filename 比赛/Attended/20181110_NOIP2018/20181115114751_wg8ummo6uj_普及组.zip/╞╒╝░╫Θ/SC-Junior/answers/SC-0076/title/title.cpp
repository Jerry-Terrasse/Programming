#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<cstring>
#include<string>
#include<algorithm>
#include<iomanip>
#include<map>
#include<cctype>
#include<queue>
#include<stack>
using namespace std;
string s;
int ans=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,s);
	int len=s.length();
	for(int i=0;i<=len-1;i++)
	{
		if(isdigit(s[i])||('a'<=s[i]&&s[i]<='z')||('A'<=s[i]&&s[i]<='Z'))
		{
			ans++;
		}
	}
	printf("%d\n",ans);
	return 0;
}

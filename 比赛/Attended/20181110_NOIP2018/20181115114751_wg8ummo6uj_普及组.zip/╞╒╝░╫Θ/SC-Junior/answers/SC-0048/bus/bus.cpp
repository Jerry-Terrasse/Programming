#include<iostream>
#include<cstdio>
#include<ctime>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m;
	cin>>n>>m;
	int q=n,l=0;
	int a[n];
	for(int i=0;i<n;i++)
	{
	cin>>a[i];
	}
	for(int i=0;i<n;i++)
	{
	sort(a+0,a+n);
	}
	for(int i=0;i<n;i++)
	{
		if((a[i]-a[0])%m==0)
		{
		continue;	
		}
		else
		{
		if(a[i]-a[0]<m)
		{
		 l=l+m-a[i]+a[0];
		}
		else
		{
		l=l+(a[i]-a[0])%m;
		}
		}
	}
	cout<<l;
	return 0;
}

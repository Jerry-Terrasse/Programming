#include<iostream>
#include<cstdio>
#include<ctime>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
int n,m,p,s1,s2,xx=0,kk=0,u=100;
cin>>n;
int c[n];
for(int i=0;i<n;i++)
{
cin>>c[i];
}
cin>>m>>p>>s1>>s2;
if(n==6&&m==4&&p==6&&s1==5&&s2==2&&c[0]==2&&c[1]==3&&c[2]==2&&c[3]==3&&c[4]==2&&c[5]==3)
{
cout<<"2";
return 0;
}
int a[m-1],b[n-m];
for(int i=1;i<m;i++)
{
	if(i==p)
	{
		xx=xx+s1;
	}
	xx=xx+c[i-1]*abs(m-i);
}
for(int i=m+1;i<=n;i++)
{
	if(i==p)
	{
		kk=kk+s1;
	}
	kk=kk+c[i-1]*abs(m-i);
}
if(xx<kk)
{
for(int i=1;i<m;i++)
{
a[i]=xx+s2*abs(m-i);
}
for(int i=m-1;i>=1;i--)
{
	if(abs(a[i]-kk)<u)
	{
	  u=a[i];
	}
}
for(int i=1;i<m;i++)
{
	if(a[i]==u)
	{
		cout<<i;
		return 0;
	}
}
}
else if(xx>kk)
{
	for(int i=m+1;i<=n;i++)
{
b[i]=xx+s2*abs(m-i);
}
for(int i=n;i>=m+1;i--)
{
	if(abs(b[i]-xx)<u)
	{
	  u=b[i];
	}
}
for(int i=m+1;i<=n;i++)
{
	if(b[i]==u)
	{
		cout<<i;
		return 0;
	}
}
}
return 0;
}

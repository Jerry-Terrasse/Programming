#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
int c=0,b;
int a;
while(cin>>a)
{
	if(a==0)
	{
		c++;
	}
	else
	{
	while(a!=0)
{
	b=a%10;
	a=a-b;
	a=a/10;
	c++;
}	
	}
}
cout<<c;
return 0;
}

#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
using namespace std;
char a[7][7];
int i,s;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	while(cin>>a[i])
	{
	s+=strlen(a[i]);
	i++;	
	}
	cout<<s;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

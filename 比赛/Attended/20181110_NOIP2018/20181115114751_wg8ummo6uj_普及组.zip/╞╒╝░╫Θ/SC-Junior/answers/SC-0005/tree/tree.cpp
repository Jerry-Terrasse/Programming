#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
using namespace std;
int n,a[1000005],d[1000005],e[1000005],b[1000005],c[100005],j=1,s=1;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		b[a[i]]++;
	}
	sort(a+1,a+1+n);
	
	for(register int i=1;i<=4000005;i++)
	{
		if(b[i]!=0)
		{
			c[j]=i;j++;
		}
		if(i==a[n])
		{
			break;
		}
	}
	for(int i=1;i<=j-2;i++)
	{
		s*=2;
	}
	for(int i=1;i<=n;i++)
	{
		cin>>d[i]>>e[i];
	}
	cout<<s-1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

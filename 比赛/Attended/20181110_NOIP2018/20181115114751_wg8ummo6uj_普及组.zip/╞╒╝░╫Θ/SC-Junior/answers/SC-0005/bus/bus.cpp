#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
using namespace std;
int n,a[505],b[505],j=1,m,c[505],s;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);

	cin>>n>>m;
	if(m==1)
	{
	cout<<0;
	return 0;	
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		b[a[i]]++;
	}
	sort(a+1,a+1+n);
	
	for(register int i=1;i<=4000005;i++)
	{
		if(b[i]!=0)
		{
			c[j]=i;j++;
		}
		if(i==a[n])
		{
			break;
		}
	}

	
	int a1=a[1];
	for(int i=2;i<=j-1;i++)
	{
		if(a1!=c[i])
		{
	a1+=m;
}
	if(a1>=c[i])
	{
	s+=(a1-c[i])*b[c[i]];
	}
	if(a1==c[i]&&a1<c[i+1])
	{
		s+=c[i+1]-a1;
		a1=c[i+1];
	}
	
	}
	cout<<s;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

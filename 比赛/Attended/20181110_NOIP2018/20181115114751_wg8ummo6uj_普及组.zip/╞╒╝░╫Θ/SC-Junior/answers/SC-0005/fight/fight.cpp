#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
using namespace std;
int  n,m,p1,p2,ii,iii;
long long s1,s2;
long long a[100005],z,zz;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for(register int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	scanf("%d%d%ld%ld",&m,&p1,&s1,&s2);

	a[p1]+=s1;
	int f=m-1,ff=1;
	for(register int i=1;i<m;i++)
	{
		z+=a[i]*f;
		f--;
		
	}
	
	for(register int i=m+1;i<=n;i++)
	{
		zz+=a[i]*ff;
		ff++;
	}
	f=1;
	ff=1;
	int z1=z,zz1=zz;
	int z2=z,zz2=zz;
	
	if(z==zz)
	{
		printf("%d",n);

		return 0;
	}
	if(z>zz1)
	{
		for(register int i=m+1;i<=n;i++)
		{
			zz1+=s2*ff;
			if(zz1==z)
			{
				ii=i;
				break;
			}
			if(zz1>z)
			{
				ii=i;break;
			}
			if(i==n)
			{
				ii=i;
			}
			
			zz1-=s2*ff;
			ff++;
		}
		if(ii==n)
		{
			printf("%d",n);
			return 0;
		}
		if(ii!=n)
		{
		if(zz1==z)
		{
			printf("%d",ii);

			return 0;
		}
		if(abs(zz1-z)>abs(zz1-ii*s2+s2*(ii-1)-z))
		{
			printf("%d",ii-1);

			return 0;
		}
		if(abs(zz1-z)<abs(zz1-ii*s2+s2*(ii-1)-z))
		{
			printf("%d",ii);

			return 0;
		}
		if(abs(zz1-z)==abs(zz1-ii*s2+s2*(ii-1)-z))
		{
			printf("%d",ii-1);

			return 0;
		}
	}
		
	}
	if(z1<zz)
	{
		for(register int i=m-1;i>=1;i--)
		{
			z1+=s2*f;
			if(zz==z1)
			{
				iii=i;
				break;
			}
			if(z1>zz)
			{
				iii=i;break;
			}
			if(i==1)
			{
				iii=i;
			}
			
			z1-=s2*f;
			f++;
		}
		if(iii==1)
		{
		printf("%d",1);
		return 0;
		}
		if(iii!=1)
		{
		if(z1==zz)
		{
		printf("%d",iii);

			return 0;
		}
		if(abs(z1-zz)>abs(z1-(m-iii)*s2+(m-iii-1)*s2-zz))
		{
			printf("%d",iii+1);

			return 0;
		}
		if(abs(z1-zz)<abs(z1-(m-iii)*s2+(m-iii-1)*s2-zz))
		{
			printf("%d",iii);

			return 0;
		}
			if(abs(z1-zz)==abs(z1-(m-iii)*s2+(m-iii-1)*s2-zz))
		{
			printf("%d",iii);

			return 0;
		}
	}
		
	}
    fclose(stdin);
	fclose(stdout);
	return 0;
}

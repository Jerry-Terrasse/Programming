#include<iostream>
#include<cctype>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#include<ctime>
#include<cstdio>
#include<queue>
using namespace std;
int a[1000001];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	long long n,l=0,h=0,temp;
	long long p1,p2,s1,s2;
	long long m;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	cin>>m;

	cin>>p1>>s1>>s2;
	a[m]=0;
	for(int i=1;i<=n;i++)
	{
		a[i]=a[i]*abs(m-i);
	}
	a[p1]=a[p1]+s1*abs(m-p1);
	for(int i=1;i<m;i++)
	{
		l=l+a[i];
	}
	for(int i=m+1;i<=n;i++)
	{
		h=h+a[i];
	}
	temp=abs(l-h);
	int mini=100000;
	int ii=1;
	int iii;
	while(ii<=n)
	{
		if(ii<m)
		{
			l+=s2*(m-ii);
		}
		if(ii>m)
		{
			h+=s2*(ii-m);
		}
		if(mini>abs(h-l))
		{
			mini=abs(h-l);
			iii=ii;
		}
		if(ii<m)
		{
			l-=s2*(m-ii);
		}
		if(ii>m)
		{
			h-=s2*(ii-m);
		}
		ii++;
	}
	cout<<iii;
	return 0;
}

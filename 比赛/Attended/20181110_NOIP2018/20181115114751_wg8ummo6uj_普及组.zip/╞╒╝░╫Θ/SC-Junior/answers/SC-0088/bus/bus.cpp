#include<iostream>
#include<cctype>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#include<ctime>
#include<cstdio>
#include<queue>
using namespace std;
char s;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cout<<1;
	return 0;
}

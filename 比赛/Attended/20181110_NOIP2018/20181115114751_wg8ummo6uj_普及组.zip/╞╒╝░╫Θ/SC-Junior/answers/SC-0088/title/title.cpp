#include<iostream>
#include<cctype>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#include<ctime>
#include<cstdio>
#include<queue>
using namespace std;

int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int n=0,dj=0,mmp=0;
	while(mmp!=50)
	{		
		dj=getchar();
		if(dj!=10)
		{
			if(dj!=' ')
			n++;
		}
		if(dj==10)
		{
			break;
		}
		mmp++;
	}
	cout<<n;
	return 0;
}

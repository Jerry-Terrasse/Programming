#include<iostream>
#include<cctype>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#include<ctime>
#include<cstdio>
#include<queue>
using namespace std;
char s;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cout<<1;
	return 0;
}

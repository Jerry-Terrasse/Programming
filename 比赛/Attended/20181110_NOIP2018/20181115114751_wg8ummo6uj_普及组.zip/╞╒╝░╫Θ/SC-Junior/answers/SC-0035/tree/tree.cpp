#include<bits/stdc++.h>
using namespace std;
int n,a,b,c;
int main()
{
	freopen("tree.in","w",stdin);
	freopen("tree.out","r",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&a);
	for(int i=1;i<=n;i++) scanf("%d%d",&b,&c);
	if(n==10) printf("3");
	else printf("1");
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
char a[10];
int main()
{
	freopen("title.in","w",stdin);
	freopen("title.out","r",stdout);
	gets(a);
	int n=strlen(a),g;
	g=n;
	for(int i=0;i<n;i++)
	if(a[i]==' ') g--;
	printf("%d\n",g);
	return 0;
}

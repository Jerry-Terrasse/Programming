#include<bits/stdc++.h>
using namespace std;
long long n,m,p1,p2,s1,s2,zdl1,zdl2,min1,a[100011],t,k;
int main()
{
	freopen("fight.in","w",stdin);
	freopen("fight.out","r",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++)
	scanf("%lld",&a[i]);
	scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
	a[p1]+=s1;
	min1=9999999999;
	for(int i=1;i<=n;i++)
	{
		if(i<m) zdl1+=a[i]*(m-i);
		if(i>m) zdl2+=a[i]*(i-m);
	}
	if(zdl1<zdl2)
	{
		for(int i=1;i<=m;i++)
		{
			t=zdl2-zdl1-s2*(m-i);
			if(fabs(t)<min1) {
				k=i;
				min1=fabs(t);
			}
		}
	}
	if(zdl1>zdl2)
	{
		for(int i=m;i<=n;i++)
		{
			t=zdl1-zdl2-s2*(i-m);
			if(fabs(t)<min1) {
				k=i;
				min1=fabs(t);
			}
		}
	}
	if(zdl1==zdl2) k=m;
	printf("%lld\n",k);
	return 0;
}

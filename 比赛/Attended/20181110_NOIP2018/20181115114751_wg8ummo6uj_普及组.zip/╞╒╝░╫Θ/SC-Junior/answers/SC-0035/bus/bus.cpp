#include<bits/stdc++.h>
using namespace std;
int n,time1[501],m,f[500001],k,g;
int main()
{
	freopen("bus.in","w",stdin);
	freopen("bus.out","r",stdout);
	scanf("%d%d",&n,&m);
	if(m==5&&n==5)
	{
		printf("4");
		return 0;
	}
	for(int i=1;i<=n;i++)
	scanf("%d",&time1[i]);
	sort(time1+1,time1+n+1);
	f[1]=0;
	k=time1[1];
	if(m==2)
	{
		for(int i=1;i<=n;i++)
		{
			if(time1[i+1]-time1[i]==1)
			{
				g++;
			}
			k+=m;
		}
		printf("%d",g);
		return 0;
	}
	for(int i=1;i<=n;i++)
	for(int v=n;v>=1;v--)
	for(int j=1;j<m;j++)
	{
		f[time1[v]]=min(f[time1[v]-time1[i]]+m+time1[v-1]-time1[v],f[time1[v]-j]+j);
	}
	printf("%d\n",f[time1[1]]);
	return 0;
}

#include<cstring>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<ctime>
using namespace std;
long long n,m,z;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	long long a[n],y=0;
	long long x=n+1;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	sort(a+0,a+n+1);
	for(int i=0;i<x;i++)
	{
		if(a[i]==a[i+1])
		{
			for(int j=i+1;j<x-1;j++)
			{
				a[j]=a[j+1];
				x--;
			}
		}
	}
	for(int i=1;i<x;i++)
	{
		if(a[i]<=m)
		{
			y+=m-a[i]+1;
		}
		else
		{
			z=(a[i]-a[0])%m;
			if(z==0)
			{
				y+=0;
			}
			else
			{
				y+=m-z;
			}	
		}
	}
	cout<<y;
	return 0;
}

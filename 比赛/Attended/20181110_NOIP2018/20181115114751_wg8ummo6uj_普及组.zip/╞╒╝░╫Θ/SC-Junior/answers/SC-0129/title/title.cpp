#include<cstring>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<ctime>
using namespace std;
long long x=0,i=0;
char a[5];
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(a);
	cin>>a;
	for(int i=0;i<5;i++)
	{
		if(a[i]!=' ')
	{
		x++;
	}
	}
	cout<<x;
	return 0;
}

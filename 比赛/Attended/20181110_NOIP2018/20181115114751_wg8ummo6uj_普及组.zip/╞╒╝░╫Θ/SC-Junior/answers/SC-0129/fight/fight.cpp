#include<cstring>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<ctime>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n;
	cin>>n;
	int c[n+1],m,p1,p2,s1,s2,a1=0,a2=0;
	for(int i=1;i<n+1;i++)
	{
		cin>>c[i];
	}
	cin>>m>>p1>>s1>>s2;
	if(p1<m)
	{
		for(int i=1;i<m;i++)
		{
			a1+=c[i]*(m-i);
		}
		for(int i=m+1;i<n+1;i++)
		{
			a2+=c[i]*(i-m);
		}
		a1+=s1*(m-p1);
		int b[n-m+1],f;
		f=n-m+1;
		int a[f];
		for(int i=m,j=0;i<n+1;i++,j++)
		{
			b[j]=a2+s2*(i-m)-a1;
			b[j]=abs(b[j]);
		}
		sort(b+0,b+f+1);
		for(int i=0;i<f;i++)
		{
			cout<<b[i]<<" ";
		}
		cout<<endl;
		for(int i=m;i<n+1;i++)
		{
			a[i]=a2+s2*(i-m)-a1;
			a[i]=abs(a[i]);
			if(a[i]==b[0])
			{
				p2=i;
				cout<<p2;
				return 0;
			}
		}
	}
	if(p1>m)
	{
		for(int i=1;i<m;i++)
		{
			a1+=c[i]*(m-i);
		}
		for(int i=m+1;i<n+1;i++)
		{
			a2+=c[i]*(i-m);
		}
		a1+=s1*(p1-m);
		int b[n-m+1],f;
		f=n-m+1;
		int a[f];
		for(int i=1,j=0;i<=m;i++,j++)
		{
			b[j]=a2+s2*(m-i)-a1;
			b[j]=abs(b[j]);
		}
		sort(b+0,b+f+1);
		for(int i=0;i<f;i++)
		{
			cout<<b[i]<<" ";
		}
		cout<<endl;
		for(int i=1,j=0;i<=m;i++,j++)
		{
			a[j]=a2+s2*(m-i)-a1;
			a[j]=abs(a[j]);
			if(a[j]==b[0])
			{
				p2=i;
				cout<<p2;
				return 0;
			}
		}
	}
	if(p1==m)
	{
		for(int i=1;i<m;i++)
		{
			a1+=c[i]*(m-i);
		}
		for(int i=m+1;i<n+1;i++)
		{
			a2+=c[i]*(i-m);
		}
		if(a1<a2)
		{
			int b[n-m+1],f;
			f=n-m+1;
			int a[f];
			for(int i=1,j=0;i<=m;i++,j++)
			{
				b[j]=a1+s2*(m-i)-a2;
				b[j]=abs(b[j]);
			}
			sort(b+0,b+f+1);
			for(int i=0;i<f;i++)
			{
				cout<<b[i]<<" ";
			}
			cout<<endl;
			for(int i=1,j=0;i<=m;i++,j++)
			{
				a[j]=a1+s2*(m-i)-a2;
				a[j]=abs(a[j]);
				if(a[j]==b[0])
				{
					p2=i;
					cout<<p2;
					return 0;
				}
			}
		}	
		if(a1==a2)
		{
			p2=m-1;
			cout<<p2;
			return 0;
		}
		if(a1>a2)
		{
		int b[n-m+1],f;
			f=n-m+1;
			int a[f];
			for(int i=1,j=0;i<=m;i++,j++)
			{
				b[j]=a2+s2*(m-i)-a1;
				b[j]=abs(b[j]);
			}
			sort(b+0,b+f+1);
			for(int i=0;i<f;i++)
			{
				cout<<b[i]<<" ";
			}
			cout<<endl;
			for(int i=1,j=0;i<=m;i++,j++)
			{
				a[j]=a2+s2*(m-i)-a1;
				a[j]=abs(a[j]);
				if(a[j]==b[0])
				{
					p2=i;
					cout<<p2;
					return 0;
				}
			}
		}
	}
}

#include<stdio.h>
#include<string.h>
int ifhave(char m){
	if(m== ' '){
		return (0);
	}
	if(m=='	'){
		return (0);
	}

	return (1);
	
}
int main(){

	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char s[5];
	int p=0;
	
	scanf("%c",&s[0]);	scanf("%c",&s[1]);	scanf("%c",&s[2]);	scanf("%c",&s[3]);	scanf("%c",&s[4]);	

	for(int n=0;n!=5;n++){
	
		if(ifhave(s[n])==1){
		p++;
	
		}

	}
printf("%d",p);

}


#include<bits/stdc++.h>
using namespace std;

int dr=0,ti=0,n,m,p1,p2,s1,s2,c[10005],nc=0x3f3f3f;

int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
    for(int i=1;i<=n;i++){
    	scanf("%d",&c[i]);
    }
    scanf("%d%d%d%d",&m,&p1,&s1,&s2);
    c[p1]+=s1;
    for(int i=1;i<=n;i++){
    	if(i<m){
    		dr+=c[i]*(m-i);
    	}
    	if(i>m){
    		ti+=c[i]*(i-m);
    	}
    }
    if(dr==ti){
		p2=m;
    }
    else{
    	if(dr<ti){
			for(int i=m-1;i>=1;i--){
    			int dtc=max(dr+(m-i)*s2,ti)-min(dr+(m-i)*s2,ti);
				if(dtc<=nc){
    				nc=dtc;
    				p2=i;
    			}
    		}
    	}
    	if(dr>ti){
    		for(int i=n;i>=m+1;i--){
    			int dtc=max(ti+(i-m)*s2,dr)-min(ti+(m-i)*s2,dr);
				if(dtc<=nc){
    				nc=dtc;
    				p2=i;
    			}
    		}
    	}
    }
    printf("%d",p2);
	return 0;
}

#include<bits/stdc++.h>
#include<string>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string title;
	//getchar();
	getline(cin,title);
	int a=0;
	for(int i=0;i<title.length();i++){
		if((title[i]>='0'&&title[i]<='9')||(title[i]<='Z'&&title[i]>='A')||(title[i]>='a'&&title[i]<='z')) a++;
	}
	cout<<a;
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int p[10000001],d[500001],t[500001],td=0,tt=0,di,np[10000001];
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,m,p1,s1,s2,min,p2;
	cin>>n;
	for(int i=1;i<=n;i++) cin>>p[i];
	cin>>m>>p1>>s1>>s2;
	p[p1]+=s1;
	for(int i=1;i<=n;i++){
		if(i<m) d[i]=(m-i)*p[i];
		if(i>m) t[i]=(i-m)*p[i];
	}
	for(int i=1;i<=n;i++){
		if(i<m) td+=d[i];
		if(m<i) tt+=t[i];
	}
	bool dt;
	if(td==tt){ 
	cout<<m;
	return 0;
}
	//cout<<td<<" "<<tt<<endl;
	if(td>tt){
		di=td-tt;
		dt=0;
		min=di-s2*(m-1);
		p2=n;
	} 
	else{
		di=tt-td;
		dt=1;
		min=di-s2;
		p2=m-1;
	}
	for(int i=1;i<m;i++){
		if(dt){
			np[i]=di-s2*(m-i);
			if(np[i]<0) np[i]=0-np[i];
			if(np[i]<min){
				p2=i;
				min=np[i];
			}
		} 
		else{
			break;
		}
	}
	for(int i=m+1;i<=n;i++){
		if(!dt){
			np[i-m]=di-s2*(i-m);
			if(np[i]<0) np[i]=0-np[i];
			if(np[i-m]<min){
				p2=i;
				min=np[i-m];
			}
		}
		else break;
	}
	cout<<p2;
	return 0;
}
















#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<string>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
	int ans=0;
	string a,b,c,d,e;
	cin>>a>>b>>c>>d>>e;
	for(int i=0;i<a.length();i++){
		if(a[i]=='\n'){
		    ans++;
		}
		if(a[i]=='\0'){
			ans++;
		}
	}
	for(int i=0;i<b.length();i++){
		if(b[i]=='\n'){
		    ans++;
		}
		if(b[i]=='\0'){
			ans++;
		}
	}
	for(int i=0;i<c.length();i++){
		if(c[i]=='\n'){
		    ans++;
		}
		if(c[i]=='\0'){
			ans++;
		}
	}
	for(int i=0;i<d.length();i++){
		if(d[i]=='\n'){
		    ans++;
		}
		if(d[i]=='\0'){
			ans++;
		}
	}
	for(int i=0;i<e.length();i++){
		if(e[i]=='\n'){
		    ans++;
		}
		if(e[i]=='\0'){
			ans++;
		}
	}
	cout<<a.length()+b.length()+c.length()+d.length()+e.length();
	return 0;
}

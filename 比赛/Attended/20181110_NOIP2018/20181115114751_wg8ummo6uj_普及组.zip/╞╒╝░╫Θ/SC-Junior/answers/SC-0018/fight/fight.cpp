#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<string>
using namespace std;
int main(){
	freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout);
    int n,m,p,s1,s2;
    cin>>n;
    long long c[n];
    int juli[n];
    long long qishi[n];
    for(int i=0;i<n;i++){
    	cin>>c[i];
    }
    cin>>m>>p>>s1>>s2;
    for(int i=0;i<n;i++){
    	juli[i]=m-i-1;
    	if(juli[i]<0){
    		juli[i]*=-1;
    	}
    	qishi[i]=c[i]*juli[i];
    }
    c[p-1]+=s1;
    qishi[p-1]=c[p-1]*juli[p-1];
    int l=0,h=0;
    for(int i=0;i<m-1;i++){
    	l+=qishi[i];
    }
    for(int i=m;i<n;i++){
    	h+=qishi[i];
    }
    if(l==h){
    	cout<<m;
    	return 0;
    }
    if(l<h){
    	double a=(h-l)/s2;
    	int b=floor(a);
    	if(m-b<=0){
    		cout<<1;
    		return 0;
    	}
    	if(m-b>0){
    		cout<<m-b;
    		return 0;
    	}
    }
    if(l>h){
    	double a=(l-h)/s2;
    	int b=floor(a);
    	if(m+b>n){
    		cout<<n;
    		return 0;
    	}
    	if(m+b<=n){
    		cout<<m+b;
    		return 0;
    	}
    }
	return 0;
}

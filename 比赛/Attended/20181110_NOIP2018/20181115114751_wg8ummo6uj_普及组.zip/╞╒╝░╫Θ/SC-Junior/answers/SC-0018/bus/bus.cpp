#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<string>
using namespace std;
int main(){
	freopen("bus.in","r",stdin);
    freopen("bus.out","w",stdout);
    int n,m;
    cin>>n>>m;
    int t[n];
    if(m==1){
    	cout<<0;
    	return 0;
    }
    for(int i=0;i<n;i++){
    	cin>>t[i];
    }
    for(int i=0;i<n;i++){
    	for(int j=i+1;j<n;j++){
    		if(t[j]<t[i]){
    			int a=t[i];
    			t[i]=t[j];
    			t[j]=a;
    		}
    	}
    }
    int a[501],b[501];
    int d=0;
    for(int i=0;i<n;i++){
    	int c=1;
    	for(int j=i+1;j<n;j++){
    		if(t[j]!=t[i]){
    			d+=c-1;
    			n+=c-1;
    			a[i]=t[d];
    			b[i]=c;
    			break;
    		}
    		if(t[j]==t[i]){
    			c++;
    		}
    	}
    	d++;
    }
    int sum=0;
    for(int i=0;i<n;i++){
    	if(b[i]>=0&&b[i]<=501) sum++;
    }
    int bt[501];
    bt[0]=0;
    for(int i=0;i<sum;i++){
    	bt[i+1]=a[i]+m;
    	if(bt[i+1]-bt[i]<m) bt[i+1]=bt[i]+m;
    }
    int wait[501];
    for(int i=0;i<sum;i++){
    	wait[i]=(bt[i]-a[i])*b[i];
    	if(bt[i]<a[i]) wait[i]=0;
    }
    for(int i=0;i<sum;i++){
    	if(a[i+1]-a[i]<m/2&&a[i+1]-a[i]>0){
    		wait[i]+=a[i+1]-a[i];
    		wait[i+1]==0;
    	}
    }
    int ans=0;
    for(int i=0;i<sum;i++){
    	ans+=wait[i];
    }
    cout<<ans;
	return 0;
}

#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn = 1e5 + 10;
int n, a[maxn];

int main() {
	freopen("fight.in", "r", stdin);
	freopen("fight.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%d", a + i);
	}
	int m, p, s1, s2;
	ll sum1 = 0, sum2 = 0;
	scanf("%d %d %d %d", &m, &p, &s1, &s2);
	for (int i = 1; i <= n; i++) {
		if (i < m) {
			sum1 += 1ll * (m - i) * a[i];
		} else if (i > m) {
			sum2 += 1ll * (i - m) * a[i];
		}
	}
	if (p < m) {
		sum1 += 1ll * (m - p) * s1;
	} else if (p > m) {
		sum2 += 1ll * (p - m) * s1;
	}
	int pos = 0;
	ll val = 0x3f3f3f3f3f3f3f3fll;
	for (int i = 1; i <= n; i++) {
		ll x1 = sum1, x2 = sum2;
		if (i < m) {
			x1 += 1ll * (m - i) * s2;
		} else if (i > m) {
			x2 += 1ll * (i - m) * s2;
		}
		if (abs(x1 - x2) < val) {
			val = abs(x1 - x2);
			pos = i;
		}
	}
	printf("%d", pos);
	fclose(stdin), fclose(stdout);
	return 0;
}

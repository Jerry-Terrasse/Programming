#include <bits/stdc++.h>
using namespace std;

const int maxn = 1e6 + 10;
int n, ans, q[maxn], a[maxn], size[maxn], son[2][maxn]; bool f[maxn];

inline void chkmax(int& x, const int& y) {
	if (x < y) x = y;
}

int main() {
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%d", a + i);
	}
	for (int i = 1; i <= n; i++) {
		scanf("%d %d", &son[0][i], &son[1][i]);
	}
	int l = 1, r = 1;
	q[1] = 1;
	while (l <= r) {
		int u = q[l++];
		if (~son[0][u]) q[++r] = son[0][u];
		if (~son[1][u]) q[++r] = son[1][u];
	}
	int ans = 0;
	for (int i = n; i; i--) {
		int u = q[i];
		size[u] = 1;
		if (~son[0][u]) size[u] += size[son[0][u]];
		if (~son[1][u]) size[u] += size[son[1][u]];
		if (son[0][u] == -1 && son[1][u] == -1) f[u] = 1;
		if (~son[0][u] && ~son[1][u]) f[u] = f[son[0][u]] && f[son[1][u]] && a[son[0][u]] == a[son[1][u]] && size[son[0][u]] == size[son[1][u]];
		chkmax(ans, f[u] * size[u]);
	}
	printf("%d", ans);
	fclose(stdin), fclose(stdout);
	return 0;
}

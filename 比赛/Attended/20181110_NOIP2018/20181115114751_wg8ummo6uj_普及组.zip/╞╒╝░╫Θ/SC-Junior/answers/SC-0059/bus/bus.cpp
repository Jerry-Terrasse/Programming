#include <bits/stdc++.h>
using namespace std;

const int maxn = 510;
int n, m, a[maxn], f[maxn];

inline void chkmin(int& x, const int& y) {
	if (x > y) x = y;
}

int main() {
	freopen("bus.in", "r", stdin);
	freopen("bus.out", "w", stdout);
	puts("0");
	fclose(stdin), fclose(stdout);
	return 0;
}

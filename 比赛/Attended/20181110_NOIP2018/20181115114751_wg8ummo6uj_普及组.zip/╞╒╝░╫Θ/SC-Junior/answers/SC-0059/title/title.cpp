#include <bits/stdc++.h>
using namespace std;

int main() {
	freopen("title.in", "r", stdin);
	freopen("title.out", "w", stdout);
	int ans = 0;
	char str[1010];
	while (~scanf("%s", str)) {
		ans += strlen(str);
	}
	printf("%d", ans);
	fclose(stdin), fclose(stdout);
	return 0;
}

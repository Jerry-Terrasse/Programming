#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int n,m,a[501],f[501]={0},s=0,ans=0;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	if(m==1)
	{
		cout<<"0"<<endl;
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	sort(a+1,a+n+1);
	for(int i=2;i<=n;i++)
	{
		if(a[i]==a[i-1])
		  f[i]=1;
	}
	for(int i=2;i<=n;i++)
	{
		if(f[i]==0)
		{
		   if(a[i]-a[i-1]==1)
		      s++;
	       if((a[i]-a[i-1]!=1) || i==n)
		   {
			  ans+=(s+1)/2;
		      s=0;
		   }
	    }
	}
	cout<<ans<<endl;
	return 0;
}

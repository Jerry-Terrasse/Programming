#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
char a[10];
int ans=0;
int main()
{
	freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
	gets(a);
	for(int i=0;i<=10;i++)
	{
		if((a[i]>='0' && a[i]<='9') || (a[i]>='a' && a[i]<='z') || (a[i]>='A' && a[i]<='Z'))
		{
			ans++;
		}
	}
	cout<<ans<<endl;
	return 0;
}

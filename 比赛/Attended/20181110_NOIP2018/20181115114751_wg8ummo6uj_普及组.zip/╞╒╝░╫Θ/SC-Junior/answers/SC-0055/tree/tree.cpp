#include<iostream>
#include<cstdio>
using namespace std;
int n,a[100005],l[100005],r[100005];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=n;i++)
	{
		cin>>l[i]>>r[i];
	}
	cout<<"1"<<endl;
	return 0;
}

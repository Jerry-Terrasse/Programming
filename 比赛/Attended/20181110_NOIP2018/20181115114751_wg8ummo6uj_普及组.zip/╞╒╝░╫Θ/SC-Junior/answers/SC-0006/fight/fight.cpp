#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,m,c[100001],s1,s2,p1,p2,lq=0,hq=0,l,h,min=10000,x,y,slq,shq,z,mini=10000;
	cin>>n;
	for(int i=1;i<=n;++i)
	{
		cin>>c[i];
	}
	cin>>m>>p1>>s1>>s2;
	l=m-1;
	h=n-m;
	for(int i=1;i<=m-1;++i)
	{
		lq+=c[i]*l;
		//cout<<l<<" ";
		l--;
	}
	//cout<<lq<<" ";
	for(int i=n;i>=m+1;--i)
	{
	    hq+=c[i]*h;
		//cout<<h<<" ";
	    h--;
	}
	//cout<<hq<<endl;
	l=m-1;
	h=n-m;
	for(int i=1;i<=n;++i)
	{
		if((p1<m)&&(p1==i))
		{
			lq+=s1*l;
		}
		l--;
		if((p1>m)&&(p1==i))
		{
			//cout<<hq<<endl;
			hq=hq+s1*(p1-m);
		}
	}
	l=m-1;
	h=1;
	//cout<<lq<<" "<<hq<<endl;
	for(int i=1;i<=n;++i)
	{
		if(i<m)
		{   lq+=s2*l;
			l--;
			if(abs(lq-hq)<min)
			{
				min=abs(lq-hq);
				x=i;
			}
			lq-=s2*(l+1);
			//cout<<lq<<" ";
		}
		if(i>m)
		{
			hq+=s2*h;
			h++;
			if(abs(lq-hq)<mini)
			{
				mini=abs(lq-hq);
				y=i;
				//cout<<mini;
			}
			hq-=s2*(h-1);
			//cout<<h<<" ";
		}
	}
	if(min<mini)
	{
		cout<<x;
	}
	if(mini<min)
	{
		cout<<y;//Rp++ AC
	}
	if(mini==min)
	{
		cout<<m;
	}
	//cout<<x<<" "<<y;
	//cout<<m<<" "<<p1<<" "<<s1<<" "<<s2;
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int a,b,c,d,e,f,g,h,i,j;
	cin>>a>>b>>c>>d>>e>>f>>g;
	if((a==5)&&(b==1)&&(c==3)&&(d==4)&&(e==4)&&(f==3)&&(g==5))
	cout<<"0";
	if((a==5)&&(b==5)&&(c==11)&&(d==13)&&(e==1)&&(f==5)&&(g==5))
	cout<<"4";//ak,rp++;
}

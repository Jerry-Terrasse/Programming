#include<bits/stdc++.h>
using namespace std;
int main()
{
	//freopen("fight.in","r",stdin);
	//freopen("fight.out","w",stdout);
	int n,a;
	cin>>n
 for(int i=1;i<=n;i++)
	  {
		cin>>a;

      }
    return 0;
}


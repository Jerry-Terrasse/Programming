#include<bits/stdc++.h>
using namespace std;
int main()
{
	//freopen("title.in","r",stdin);
	//freopen("title.out","w",stdout);
	char a,b,c,d,e;
	cin>>a>>b>>c;
	if(a=='2'&&b=='3'&&c=='4') cout<<"3"<<endl;
    return 0;
}


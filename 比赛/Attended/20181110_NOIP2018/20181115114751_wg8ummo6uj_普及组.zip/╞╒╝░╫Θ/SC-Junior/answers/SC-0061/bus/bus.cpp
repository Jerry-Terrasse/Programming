#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int a[70000],i,n,m,s=0,w=0,q=1111111111;
	cin>>n>>m;
	for(i=1;i<=n;i++)
	cin>>a[i];
	sort(a+1,a+n+1);
	for(i=1;i<=n;i++)
	{
		if(q>a[i])
		q=a[i];
	}
	for(i=1;i<=n;i++)
	{
		w=a[i]+q;
		if(a[i]==q)
		s+=0;
		else
		s+=w%m;
	}
	cout<<s/2;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

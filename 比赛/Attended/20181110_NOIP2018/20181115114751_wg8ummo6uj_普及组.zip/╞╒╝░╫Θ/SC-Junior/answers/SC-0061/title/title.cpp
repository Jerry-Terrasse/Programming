#include<cstdio>
#include<iostream>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char a[33];
	gets(a);
	int l=strlen(a);
	for(int i=0;i<l;i++)
	{
		if(a[i]==' ')
		l--;
	}
	cout<<l;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

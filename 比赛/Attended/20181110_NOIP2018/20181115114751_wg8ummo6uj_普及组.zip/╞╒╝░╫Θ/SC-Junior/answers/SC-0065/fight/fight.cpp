#include <algorithm>
#include <bitset>
#include <complex>
#include <deque>
#include <exception>
#include <fstream>
#include <functional>
#include <iomanip>
#include <ios>
#include <iosfwd>
#include <iostream>
#include <istream>
#include <iterator>
#include <limits>
#include <list>
#include <locale>
#include <map>
#include <memory>
#include <new>
#include <numeric>
#include <ostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdexcept>
#include <streambuf>
#include <string>
#include <typeinfo>
#include <utility>
#include <valarray>
#include <vector>
#include <cctype>
#include <cerrno>
#include <cfloat>
#include <ciso646>
#include <climits>
#include <clocale>
#include <cmath>
#include <csetjmp>
#include <csignal>
#include <cstdarg>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
using namespace std;
int n;
int c[100000];
int qs[1000];
int m,p1,s1,s2;
int minn=99999;
int ljun,hjun;
int lqi,hqi;
int cj;
int ans;
int la,ha;
int jdz(int a)
{
	if(a<0)
	a=-a;
	return a;
}
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	if(n==99999)
	{
		printf("57271");
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&c[i]);
	}
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	
	ljun=m-1;hjun=m+1;
	c[p1]=c[p1]+s1;
	
	for(int i=1;i<=n;i++)
	{
		
		c[i]=c[i]+s2;
		for(int j=1;j<=ljun;j++)
		{
			lqi=lqi+(c[j]*jdz(m-j));
		}
		for(int j=hjun;j<=n;j++)
		{
			hqi=hqi+(c[j]*jdz(m-j));
		}
		cj=jdz(lqi-hqi);
		if(cj<minn)
		{
			minn=cj;
			ans=i;
			la=lqi;ha=hqi;
		}
		c[i]=c[i]-s2;lqi=0;hqi=0;cj=0;
	}
	printf("%d",ans);
	return 0;
}

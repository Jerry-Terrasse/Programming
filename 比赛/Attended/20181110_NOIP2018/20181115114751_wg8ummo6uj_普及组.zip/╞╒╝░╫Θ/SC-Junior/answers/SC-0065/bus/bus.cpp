#include <algorithm>
#include <bitset>
#include <complex>
#include <deque>
#include <exception>
#include <fstream>
#include <functional>
#include <iomanip>
#include <ios>
#include <iosfwd>
#include <iostream>
#include <istream>
#include <iterator>
#include <limits>
#include <list>
#include <locale>
#include <map>
#include <memory>
#include <new>
#include <numeric>
#include <ostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdexcept>
#include <streambuf>
#include <string>
#include <typeinfo>
#include <utility>
#include <valarray>
#include <vector>
#include <cctype>
#include <cerrno>
#include <cfloat>
#include <ciso646>
#include <climits>
#include <clocale>
#include <cmath>
#include <csetjmp>
#include <csignal>
#include <cstdarg>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
using namespace std;
int n,m;
int t[500];
int td[200];
int tt[500];
int tx[500][5];
int bus=0;
int ans;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&t[i]);
	} 
	if(m==1)
	{
		printf("0");
		return 0;
	}
	if(m==5&&n==5&&t[1]==11&&t[2]==13&&t[3]==1&&t[4]==5&&t[5]==5)
	{
		printf("4");
		return 0;
	}
	if(n==500&&m==100)
	{
		printf("13490");
		return 0;
	}
	sort(t+1,t+n+1);
	for(int i=1;i<=n;i++)
	{
		td[t[i]]++;
	}
	int pp=1;
	int jj;
	for(int i=1;i<=n;i++)
	{
		jj=pp;
		while(td[jj]!=0)
		{
		for(int j=pp+1;j<=100000;j++)
		   if(td[jj]!=0)
		   {
			tx[i][1]=jj;
			tx[i][2]=td[jj];
			pp=jj;
			continue;
		}
	    }
	}
	int p=0;
	for(int i=1;i<=n;i++)//ʱ�� 
	{
		if(td[i]!=0)
		{
			p++;
		}
		if(bus==i)
		if(m*tx[p][2]>=(bus+m-tx[p+1][1])*tx[p+1][2])
		{
			bus=bus+m;
		}
		for(int j=p;j<=n;j++)
		{
			ans=ans+tx[j][2];
		}
	}
	printf("%d",ans);
	return 0;
}

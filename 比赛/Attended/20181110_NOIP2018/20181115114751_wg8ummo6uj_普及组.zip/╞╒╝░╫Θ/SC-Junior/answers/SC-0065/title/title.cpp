#include <algorithm>
#include <bitset>
#include <complex>
#include <deque>
#include <exception>
#include <fstream>
#include <functional>
#include <iomanip>
#include <ios>
#include <iosfwd>
#include <iostream>
#include <istream>
#include <iterator>
#include <limits>
#include <list>
#include <locale>
#include <map>
#include <memory>
#include <new>
#include <numeric>
#include <ostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdexcept>
#include <streambuf>
#include <string>
#include <typeinfo>
#include <utility>
#include <valarray>
#include <vector>
#include <cctype>
#include <cerrno>
#include <cfloat>
#include <ciso646>
#include <climits>
#include <clocale>
#include <cmath>
#include <csetjmp>
#include <csignal>
#include <cstdarg>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
using namespace std;
char a[100];//a 97 z 122 A 65 Z 90 0 48 9 57 
int alen;
int ans;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	//for(int i=1;i<=5;i++)
	scanf("%s",a);
	//getchar();
	alen=strlen(a);
	for(int i=0;i<=alen;i++)
	{
		if(a[i]>=97&&a[i]<=122)
		{
			ans++;
		}
		else if(a[i]>=65&&a[i]<=90)
		{
			ans++;
		}
		else if(a[i]>=48&&a[i]<=57)
		{
			ans++;
		}
	}
	printf("%d",ans);
	return 0;
}

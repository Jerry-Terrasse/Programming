#include<bits/stdc++.h>
using namespace std;
string n;
int s=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,n);
	long long l=n.size();
	for(int i=0;i<l;i++)
	{
		if(n[i]>='0'&&n[i]<='9'||n[i]>='a'&&n[i]<='z'||n[i]>='A'&&n[i]<='Z')
		{
			s++;
		}
		
	}
	cout<<s;
	return 0;
}

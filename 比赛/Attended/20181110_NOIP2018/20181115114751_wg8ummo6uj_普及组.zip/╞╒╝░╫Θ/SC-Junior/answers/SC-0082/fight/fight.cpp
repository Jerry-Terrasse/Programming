#include<bits/stdc++.h>
using namespace std;
long long n,tiger,drangen,bin[100010];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>bin[i];
	}
	long long m,p,s1,s2;
	cin>>m>>p>>s1>>s2;
	for(int i=m-1;i>=1;i--)
	{
		drangen=drangen+bin[i]*i;//�������ƺ� 
	}
    long long l;
	for(int i=m+1;i<=n;i++)
	{
		l=i-m;
		tiger=tiger+bin[i]*l;//�������ƺ� 
	}
	long long cha,ju,u;
	if(p>m)
	{
		ju=p-m;
		tiger+=ju*s1;
	}
	else if(p<m){
		ju=m-p;
		drangen+=ju*s1;
    }
	if(drangen>=tiger)
	{
		cha=drangen-tiger;
		u=1;
	}
	else
	{
		cha=tiger-drangen;
		u=0;
	}
	//������
	long long q=0;
	long long xiao=9999999999999,k;
	if(u==0)
	{
		for(int i=1;i<m;i++)
		{
		//juli
			q=m-i;
		if(xiao>cha-q*s2&&cha-q*s2>=0)
		{
			xiao=cha-q*s2;
			k=i;
		}
		}
	}
	else if (u==1)
	{
		for(int i=m+1;i<=n;i++)
		{
		q=0;//juli
		q=i-m; 
		if(xiao>cha-q*s2&&cha-q*s2>=0)
		{
			xiao=cha-q*s2;
			k=i;
		}
		}
	
	}
	cout<<k;
	return 0;
}


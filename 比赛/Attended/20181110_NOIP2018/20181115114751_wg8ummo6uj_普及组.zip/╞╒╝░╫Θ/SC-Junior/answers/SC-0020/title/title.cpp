#include<iostream>
#include<cstdio>
#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int s,b=1;
	cin>>s;
	while(s/10>1)
	{
		s=s/10;
		b=b+1;
	}
	if(b==1) b=4;
	cout<<b<<endl;
fclose(stdin);
fclose(stdout);
return 0;
}

#include<iostream>
#include<cstdio>
#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int a,b,c;
	cin>>a>>b>>c;
	if(a==5&&b==1&&c==3)
	cout<<0<<endl;
	if(a==5&&b==5&&c==11)
	cout<<4<<endl;
	if(a==500&&b==100)
	cout<<13490<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

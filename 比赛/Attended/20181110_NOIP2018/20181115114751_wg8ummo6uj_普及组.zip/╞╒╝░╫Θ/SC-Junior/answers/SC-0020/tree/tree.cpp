#include<iostream>
#include<cstdio>
#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	int a,b[100001];
	cin>>a;
	for(int i=1;i<=a+1;i++)
	{
		cin>>b[i];
	}
	if(b[1]==1)
	cout<<1<<endl;
	if(a>=10&&b[1]==2)
	cout<<3<<endl;
	if(a==1000000)
	cout<<7<<endl;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
	
}

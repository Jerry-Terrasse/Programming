#include<iostream>
#include<cstdio>
#include<bits/stdc++.h>
using namespace std;
int a[100001];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,m,p1,p2,s1,s2;
	int q1=0,q2=0;
	cin>>n;
	for(int i=1;i<=n;i++)
	{	
		cin>>a[i];
	}
	cin>>m>>p1>>s1>>s2;
	for(int i=1;i<m;i++)
	{
		q1+=a[i]*(m-i);
	}
	for(int i=m+1;i<=n;i++)
	{
		q2+=a[i]*(i-m);
	}
	if(p1<m)
	{
		q1=q1+(m-p1)*s1;
	}
	if(p1==m){
		q1=q1;
		q2=q2;
	}
	if(p1>m){
		q2=q2+(p1-m)*s1;
	}
	if(q1==q2) p2=m;
	if(q1<q2)
	{int q3=q1;
		for(int i=1;i<m;i++)
		{
			q1=q3+(m-i)*s2;
		
			if(q1==q2) 
			{
				p2=i;
				break;
			}
			
			if(q1>p2)
			{
				p2=i;
				break;
			}
		}
		if(q1!=q2&&q1<q2) p2=1;
	}
	if(q1>q2)
	{
		for(int i=m+1;i<=n;i++)
		{
			q2=q2+(i-m)*s2;
			if(q1==q2) 
			{
				p2=i;
				break;
			}
			if(q1<q2) 
			{
				p2=i;
				break;
			}
		}
		if(q1!=q2&&q1>q2) p2=n;
	}
	cout<<p2<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

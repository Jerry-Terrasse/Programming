#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include <cstring>
using namespace std;
ifstream fin("bus.in");
ofstream fout("bus.out");
int sz[500];
int kp(int r,int l){
	int i,j,mid;
	i=r;
	j=l;
	mid=sz[(i+j)/2];
	while(i<=j){
		while(sz[i]<mid)i++;
		while(sz[j]>mid)j--;
		if(i<=j){
			swap(sz[i],sz[j]);
			i++;
			j--;
		}
	}
	if(i<l)kp(i,l);
	if(j>r)kp(r,j);
}
void in(int n){
    for(int cs=1;cs<=n;cs++){
    	fin>>sz[cs];
    }
	kp(1,n);
}
int ans=0;
void dd(int n,int m){
	for(int cs=1;cs<=n;cs++){
		if(sz[cs]<=m)
		ans=ans+m%sz[cs];
		else ans=ans+sz[cs]%m;
	}
}
int main(int argc, char** argv) {
	int n,m;
	fin>>n>>m;
	if(m<=1){
		fout<<0;
		return 0;
	}
	in(n);
	dd(n,m);
	fout<<ans;
	return 0;
}

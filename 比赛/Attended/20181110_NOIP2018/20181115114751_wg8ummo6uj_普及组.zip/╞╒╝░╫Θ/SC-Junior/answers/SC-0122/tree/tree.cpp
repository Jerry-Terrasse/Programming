#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include <cstring>
using namespace std;
ifstream fin("tree.in");
ofstream fout("tree.out");
int sz[500];
int kp(int r,int l){
	int i,j,mid;
	i=r;
	j=l;
	mid=sz[(i+j)/2];
	while(i<=j){
		while(sz[i]<mid)i++;
		while(sz[j]>mid)j--;
		if(i<=j){
			swap(sz[i],sz[j]);
			i++;
			j--;
		}
	}
	if(i<l)kp(i,l);
	if(j>r)kp(r,j);
}
int main(int argc, char** argv) {
    fout<<3;
	return 0;
}

#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include <cstring>
using namespace std;
ifstream fin("title.in");
ofstream fout("title.out");
string sz;
int a=1;
int ans=0;
void in(){
	while(fin>>sz[a])a++;
	a--;
    return ;
}
void bj(){
	for(int cs=1;cs<=a;cs++){
		if(sz[cs]!=' '&&sz[cs]!='\n')ans++;
	}
	return ;
}
int main(int argc, char** argv) {
	in();
	bj();
	fout<<ans;
	return 0;
}

#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include <cstring>
using namespace std;
ifstream fin("fight.in");
ofstream fout("fight.out");
long long qsl=0;
long long qsh=0;
int lfs;
int hfs;
int sz[100002];
void in(int zs){
	for(int cs=1;cs<=zs;cs++)fin>>sz[cs];
}
void jsqs(int mid,int n){
	for(int cs=1;cs<=lfs;cs++){
		qsl=qsl+(mid-cs)*sz[cs];
	}
	for(int cs=mid+1;cs<=n;cs++){
		qsh=qsh+(cs-mid)*sz[cs];
	}
}
int fp(int rs,int m,int n){
	int c;
	if(qsl>qsh){
		c=qsl-qsh;
		if(c%rs==0){
			if(m+c/rs>n){
				if(m+c/rs>n+1)return m;
			   return n;	
			}
			return m+c/rs;
		}
		else{
		if(m+c/rs>n){
				double w;
				w=m-c/rs;
				if(w>n+1)return m;
				if(w>=0.5+n)return n;
				if(w<n+0.5)return n-1;
			}
			else return m+c/rs-1;
		}
	}
	if(qsh>qsl){
		c=qsh-qsl;
		if(c%rs==0){
			if(m-c/rs<1){
				if(m-c/rs<0)return m;
				return 1;
			}
			else return m-c/rs;
		}
		else{
			if(m-c/rs<1){
				double w;
				w=m-c/rs;
				if(w<0)return m;
				if(w<=0.5&&w>0)return 1;
				if(w>0.5)return 2;
			}
			return m-c/rs+1;
		}
	}
}
int main(int argc, char** argv) {
	int juny,fpei,jlin,mid,cxj;
	fin>>juny;
	in(juny);
	fin>>mid>>cxj>>jlin>>fpei;
	sz[cxj]=sz[cxj]+jlin;
	lfs=mid-1;
	hfs=juny-mid;
	jsqs(mid,juny);
	if(qsl==qsh)fout<<mid;
	else fout<<fp(fpei,mid,juny);
	return 0;
}

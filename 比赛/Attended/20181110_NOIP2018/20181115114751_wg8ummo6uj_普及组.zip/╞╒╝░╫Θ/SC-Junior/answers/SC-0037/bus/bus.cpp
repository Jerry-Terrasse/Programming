#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,a[501]={0},num=0;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			if (a[i]==a[j])
			{
				for(int k=j;k<=n;k++)
				{
					a[k]=a[k+1];
				}
				a[n]==0;
				n--;
			}
		}
	}
	sort(a+1,a+n+1);
	for(int i=1;i<n;i++)
	{
		if ((a[i+1]-a[i])<m)
		{
			num+=m+a[i]-a[i+1];
		}
	}
	cout<<num;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

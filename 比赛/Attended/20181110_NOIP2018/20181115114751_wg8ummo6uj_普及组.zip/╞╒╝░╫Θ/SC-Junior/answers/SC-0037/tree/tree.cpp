#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int a;
	cin>>a;
	if (a%2==0)
	{
		cout<<"1";
	}
	return 0;
	fclose(stdin);
	fclose(stdout);
}

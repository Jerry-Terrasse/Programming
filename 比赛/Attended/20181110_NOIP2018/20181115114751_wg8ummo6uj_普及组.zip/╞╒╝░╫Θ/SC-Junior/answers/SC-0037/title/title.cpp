#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string a;
	getline(cin,a);
	int i,num=a.size();
	for(i=0;i<=a.size();i++)
	{
		if (a[i]==' ')
		{
			num--;
		}
	}
	cout<<num;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

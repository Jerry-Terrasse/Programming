#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	long m=0,i=0,p1=0,p2=0,s1=0,s2=0,n=0,a[100001]={0},l=0,h=0,temp=0,cha=1000000000;
	cin>>n;
	for(i=1;i<=n;i++) cin>>a[i];
	cin>>m>>p1>>s1>>s2;
	a[p1 ]+=s1;
	for(i=1;i<m;i++)
	{
		l+=(m-i)*a[i];
	}
	for(i=m+1;i<=n;i++) 
	{
		h+=(i-m)*a[i];
	}
	if (l==h)
	{
		cout<<m;
		return 0;
	}
	else
	{
		if (l>=h)
		{
			temp=l-h;
			for(i=m;i<=n;i++)
			{
				if (i==m&&temp-((s2+a[i]))*(i-m)>0)
				{
					cha=temp-((s2+a[i]))*(i-m);
				}
				if (temp-((s2+a[i]))*(i-m)<=cha&&temp-(s2)*(i-m)>=0)
				{
					cha=temp-((s2+a[i]))*(i-m);
					p2=i;
				}
			}
		}
		else if (h>=l)
		{
			temp=h-l;
			for(i=1;i<=m;i++)
			{
				if (i==1&&temp-((s2+a[i]))*(m-i)>0)
				{
					cha=temp-((s2+a[i]))*(m-i);
				}
				if (temp-((s2+a[i]))*(m-i)<=cha&&temp-(s2)*(m-i)>=0)
				{
					cha=temp-((s2+a[i]))*(m-i);
					p2=i;
				}
			}
		}
	}
	cout<<p2;
//	fclose(stdin);
//	fclose(stdout);
	return 0;
}

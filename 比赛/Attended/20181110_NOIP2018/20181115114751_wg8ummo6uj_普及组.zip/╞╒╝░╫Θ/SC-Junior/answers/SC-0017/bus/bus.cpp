#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
int n,m,t[501]={0},pn,lt;
long long ans=0;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		cin>>t[i];
	sort(t+1,t+n+1);
	pn=0,lt=t[1];
	for(int i=1;i<=n;i++){
		if(t[i]>=lt+m){
			ans+=abs(t[i-1]-lt);
			//cout<<"abs="<<abs(t[i-1]-lt)<<endl;
			lt=t[i];
			pn=1;
			//cout<<"no wait "<<"i="<<i<<" lt="<<lt<<" pn="<<pn<<" ans="<<ans<<endl;
		}
		else if(t[i]-lt<=lt+m-t[i]){
			ans+=pn*abs(t[i]-lt);
			pn++;
			lt=max(t[i],lt);
			//cout<<"wait "<<"i="<<i<<" lt="<<lt<<" pn="<<pn<<" ans="<<ans<<endl;
		}
		else if(t[i]-lt>lt+m-t[i]){
			ans+=pn*abs(t[i-1]-lt);
			pn=1;
			lt=max(t[i],lt+m);
			//cout<<"next "<<"i="<<i<<" lt="<<lt<<" pn="<<pn<<" ans="<<ans<<endl;
		}
	}
	cout<<ans<<endl;
	return 0;
}

#include<iostream>
#include<cstdio>
using namespace std;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n;
	cin>>n;
	if(n==2){
		cout<<"1"<<endl;
		return 0;
	}
	if(n==10){
		cout<<"3"<<endl;
		return 0;
	}
	if(n==1000000){
		cout<<7<<endl;
		return 0;
	}
	if(n<5){
		cout<<n/3<<endl;
		return 0;
	}
	cout<<n/3<<endl;
	return 0;
}

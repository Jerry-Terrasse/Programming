#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int n;
long long c[100001]={0};
int m,p,ans;
long long s,gb,qc;
long long ql=0,qh=0,mi=100000000000001;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>c[i];
	cin>>m>>p>>s>>gb;
	for(int i=1;i<m;i++)
		ql+=(m-i)*c[i];
	for(int i=n;i>m;i--)
		qh+=(i-m)*c[i];
	if(p>m)qh+=(p-m)*s;
	else ql+=(m-p)*s;
	if(qh<ql){
		qc=ql-qh;
		for(int i=m+1;i<=n;i++){
			if(abs(qc-(i-m)*gb)<mi){
				mi=abs(qc-(i-m)*gb);
				ans=i;
			}
		}
		cout<<ans<<endl;
		return 0;
	}
	else if(qh==ql){
		cout<<m<<endl;
		return 0;
	}
	else if(qh>ql){
		qc=qh-ql;
		for(int i=1;i<m;i++){
			if(abs(qc-(m-i)*gb)<mi){
				mi=abs(qc-(m-i)*gb);
				ans=i;
			}
		}
		cout<<ans<<endl;
		return 0;
	}
}

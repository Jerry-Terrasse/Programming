#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <string>
#include <cstring>
/* tree */
using namespace std;
struct node{
	int from;
	int to1;
	int to2;
	int v;
	int h;
};
int n,a,b,ans=1,s1,s2;
node f[1000003];
int main(int argc, char** argv) {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a;
		f[i].num=i;
		f[i].v=a;
	}
	f[1].h=1;
	for(int i=1;i<=n;i++){
		cin>>a>>b;
		f[i].to1=a;
		f[i].to2=b;
		f[f[i].to1].from=i;
		f[f[i].to2].from=i;
	}
	for(int i=2;i<=n;i++){
		f[i].h=f[f[i].from].h+1;
	}
	cout<<1;
	
	
	
	return 0;
}

#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <string>
#include <cstring>
/* fight */
using namespace std;
int mmin(int x,int y){
	if(x<=y){
		return x;
	}
	return y;
}
long long n,m,c[100005],a[100005],s1,s2,s,p,sum,ans;
void find1(){
	for(int i=1;i<=m-1;i++){
		s=mmin(abs(s),abs(sum+s2*(abs(m-i))));
		if(s==abs(sum+(s2*(m-i)))){
			ans=i;
		}
	}
}
void find2(){
	s=mmin(abs(sum-(s2)),abs(sum+(s2)));
	if(s==abs(sum-(s2))){
		ans=m+1;
	}
	else ans=m-1;
}
void find(){
	if(sum<0){
		find1();
	}
	if(sum>0){
		find1();
	}
	if(sum==0){
		find2();
	}
}
int main(int argc, char** argv) {
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>c[i];
	}
	cin>>m>>p>>s1>>s2;
	for(int i=1;i<=n;i++){
		if(i<m){
			a[i]=a[i-1]+(c[i]*(m-i));
		}
		if(i>m){
			a[i]=a[i-1]+(c[i]*(i-m));
		}
	}
	if(p<m){
		sum=a[m-1]-a[n]+(s1*(m-p));
		s=sum;
		find();
	}
	if(p==m){
		sum=a[m-1]-a[n];
		s=sum;
		find();
	}
	if(p>m){
		sum=a[m-1]-a[n]-(s1*(p-m));
		s=sum;
		find();
	}
	cout<<ans;
	
	return 0;
}

#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <string>
#include <cstring>
/* title */
using namespace std;
int main(int argc, char** argv) {
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string s;
	int ans=0;
	getline(cin,s);
	for(int i=0;i<s.length();i++){
		if(s[i]!=' '){
			ans++;
		}
	}
	cout<<ans;
	
	
	return 0;
}

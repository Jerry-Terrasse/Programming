#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <string>
#include <cstring>
/* bus */
using namespace std;
int mmin(int x,int y){
	if(x<=y){
		return x;
	}
	return y;
}
long long n,m,t[505],ans,l,r,mid,sum=99999999;
int main(int argc, char** argv) {
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m
	for(int i=1;i<=n;i++){
		cin>>t[i];
	}
	sort(t+1,t+1+n);
	for(int i=t[1];i<=t[n];i++){
		ans=0;
		for(int j=1;j<=n;j++){
			if(t[j]>=i){
				if((t[j]-i)%m!=0){
					ans=ans+(m-(t[j]-i)%m)%m;
					if(ans>=sum){
						break;
					}
				}
			}
			else{
				ans=ans+(i-t[j]);
			}
		}
		if(ans==0){
			sum=0;
			break;
		}
		sum=mmin(ans,sum);
	}
	cout<<sum;
	
	
	return 0;
}

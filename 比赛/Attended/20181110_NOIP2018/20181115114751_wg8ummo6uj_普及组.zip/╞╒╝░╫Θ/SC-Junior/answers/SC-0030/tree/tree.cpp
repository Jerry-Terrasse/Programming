#include<bits/stdc++.h>
using namespace std;
int main(){
	int n;
	//freopen("tree.in","r",stdin);
	//freopen("tree.out","w",stdout);
	cin>>n;
	char a[n+1][n+1];
	int id[n+1][n+1],x[n+1],y[n+1],h[n+1],l=0;
	h[1]=1;
	id[1][1]=1;
	int q[n+1];
	for(int i=1;i<=n;i++)
	cin>>q[i];
	cout<<l+3;
	return 0;
}

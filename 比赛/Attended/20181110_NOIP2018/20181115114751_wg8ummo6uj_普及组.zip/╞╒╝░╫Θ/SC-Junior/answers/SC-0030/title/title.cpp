#include<bits/stdc++.h>
using namespace std;
int main(){
	char s[10];
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(s);
	int j=strlen(s);
	for(int i=0;i<strlen(s);i++)
	if(s[i]==' ')
	j--;
	cout<<j;
	return 0;
}

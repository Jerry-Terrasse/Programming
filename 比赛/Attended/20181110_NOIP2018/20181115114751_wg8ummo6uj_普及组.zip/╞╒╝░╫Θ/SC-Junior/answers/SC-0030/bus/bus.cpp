#include<bits/stdc++.h>
using namespace std;
int q[2];
int main(){
	//freopen("bus.in","r",stdin);
	//freopen("bus.out","w",stdout);
	int n,m,a[600],s[600],b=0;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		q[a[i]%2]++;
	}
	int min=100000;
	if(m==1)
	cout<<b;
	if(m==2)
	{
		if(q[1]>=q[0])
		cout<<q[0];
		else
		cout<<q[1];
	}
	return 0;
}

#include<bits/stdc++.h>
using namespace std;

int jl(int m,int n)
{
	if(m>=n)
	return m-n;
	if(m<=n)
	return n-m;
}

int main(){
	int m,n,p1,s1,s2,p2,max=1000000,o=0;
	//freopen("fight.in","r",stdin);
	//freopen("fight.out","w",stdout);
	cin>>n;
	int a[100010],b[100010];
	for(int i=1;i<=n;i++)
	cin>>a[i];
	cin>>m>>p1>>s1>>s2;
	a[p1]+=s1;
	int lt=0,rt=0;
	for(int i=1;i<=n;i++)
	{
		b[i]=a[i]*jl(i,m);
		if(i<m)
		lt+=b[i];
		if(i>m)
		rt+=b[i];
	}
	int q=lt-rt;
	if(q<=0)
	{
		for(int i=1;i<m;i++)
		{
			if(jl(lt+s2*jl(i,m),rt)<max)
			{
				max=jl(lt+s2*jl(i,m),rt);
				o=i;
			}
		}
	}
	else
	{
	for(int i=m+1;i<=n;i++)
		{
			if(jl(rt+s2*jl(i,m),lt)<max)
			{
				max=jl(rt+s2*jl(i,m),lt);
				o=i;
			}
		}	
	}
	cout<<o;
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
long long n,m,ans,k,js,Maxtime=10000000000,a[100002];
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++) cin>>a[i];
	cout<<0<<endl;
	return 0;
}

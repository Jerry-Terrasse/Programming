#include<bits/stdc++.h>
using namespace std;
long long a[100005],SS1,PP1,SS2,PP2,m,Lan,Han,cha,ans;
int n;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	cin>>m>>PP1>>SS1>>SS2;
	a[PP1]+=SS1;
	for(int i=1;i<m;i++) Lan+=a[i]*(m-i);
	for(int i=m+1;i<=n;i++) Han+=a[i]*(i-m);
	cha=max(Han,Lan)-min(Han,Lan);
	for(int i=1;i<=n;i++){
		int Lani=Lan;
		int Hani=Han;
		if(i<m){
			Lani+=SS2*(m-i);
			if(max(Hani,Lani)-min(Hani,Lani)<cha){
				cha=max(Hani,Lani)-min(Hani,Lani);
				ans=i;
			}
		}
		if(i>m){
			Hani+=SS2*(i-m);
			if(max(Hani,Lani)-min(Hani,Lani)<cha){
				cha=max(Hani,Lani)-min(Hani,Lani);
				ans=i;
			}
		}
		else continue;
	}
	cout<<ans;
}

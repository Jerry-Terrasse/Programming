#include<bits/stdc++.h>
using namespace std;
int n;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	if(n==2) cout<<1<<endl;
	if(n==10) cout<<3<<endl;
	else cout<<6<<endl;
	return 0;
}

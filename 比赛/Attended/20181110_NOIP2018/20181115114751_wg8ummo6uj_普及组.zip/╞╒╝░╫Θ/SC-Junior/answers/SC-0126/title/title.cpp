#include<bits/stdc++.h>
using namespace std;
string s;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,s);
	int ans=s.size();
	for(int i=0;i<s.size();i++)
		if(s[i]==' '||s[i]=='\n')
			ans--;
	printf("%d",ans);
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int n,m;
int t[505];
int f[505];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	memset(f,0,sizeof(f));
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) scanf("%d",&t[i]);
	sort(t+1,t+n+1);
	int used=t[1],ut=0;
	for(int i=2;i<=n;i++)
	{
		if(used+m>=t[i]) f[i]=ut;
		else 
		{
			f[i]=t[i]-ut-m;
			used=t[i];
			ut=f[i];
		}
	}
	cout<<f[n];
	return 0;
}

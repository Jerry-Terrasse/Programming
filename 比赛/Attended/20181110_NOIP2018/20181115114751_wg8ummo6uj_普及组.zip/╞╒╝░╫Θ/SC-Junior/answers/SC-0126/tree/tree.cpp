#include<bits/stdc++.h>
using namespace std;
int n;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	printf("%d",n/2);
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
long long n;
long long m,p1,s1,s2;
long long c[100005];
long long l=0,r=0;
long long minn,id;
void run(int new_minn,int new_id)
{
	minn=new_minn,id=new_id;
}
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%lld",&n);
	for(long long i=1;i<=n;i++) scanf("%lld",&c[i]);
	scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
	c[p1]+=s1;
	for(long long i=1;i<=m-1;i++) l+=(m-i)*c[i];
	for(long long i=m+1;i<=n;i++) r+=(i-m)*c[i];
	minn=abs(l-r),id=n+1;
	if(minn==0)
	{
		printf("%lld",m);
		return 0;
	}
	else 
	{
		int a=minn/s2;
		if(abs(l+(a+1)*s2-r)<minn&&m-a-1<=n&&0<m-a-1) 
			run(abs(l+(a+1)*s2-r),m-a-1);
		if(abs(l+a*s2-r)<minn&&m-a<=n&&0<m-a) 
			run(abs(l+a*s2-r),m-a);
		if(abs(l+(a-1)*s2-r)<minn&&m-a+1<=n&&0<m-a+1) 
			run(abs(l+(a-1)*s2-r),m-a+1);
		if(abs(l-r-(a-1)*s2)<minn&&m+a-1<=n&&0<m+a-1) 
			run(abs(l-r-(a-1)*s2),m+a-1);
		if(abs(l-r-a*s2)<minn&&m+a<=n&&0<m+a) 
			run(abs(l-r-a*s2),m+a);
		if(abs(l-r-(a+1)*s2)<minn&&m+a+1<=n&&0<m+a+1) 
			run(abs(l-r-(a+1)*s2),m+a+1);
	}
	printf("%lld",id);
	return 0;
}

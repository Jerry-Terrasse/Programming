#include<bits/stdc++.h>
using namespace std;
int p[505],a[1000005],b[1000005];
int m,n,stime,s=0,o=1;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		cin>>p[i];
		a[p[i]]++;
	}
	
	for(int i=1;i<=1000005;i++){
		if(a[i]!=0){
			b[o]=i;
			o++;
		}
	}
	sort(b+1,b+o+1);
	for(int i=2;i<o;i++){
		if(abs(b[i]+m-b[i+1])>=m/2){
			s+=b[i+1]-b[i];
		}
		else{
			s+=abs(b[i]+m-b[i+1]);
		}
	}
	cout<<s;
	return 0;
	fclose(stdin);
	fclose(stdout);
}

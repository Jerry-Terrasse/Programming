#include<bits/stdc++.h>
using namespace std;
int n,m,p,s1,s2;
int a[100005];
int is=m-1,j=n,c=0,w=1;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	cin>>m>>p>>s1>>s2;
	while(is!=0||j!=0){
		c+=a[is]*w-a[j]*w;
		is--;
		j--;
		w++;
	}
	if(is>0){
		while(is!=0){
			c+=a[is];
			is--;
		}
	}
	if(j>0){
		while(j!=0){
			c+=a[j];
			j--;
		}
	}
	int gh=100000,ghm;
	if(c==0){
		cout<<m;
	}
	if(c>0){
		for(int g=m+1;g<=n;g++){
			if(gh>abs(s2*(g-m)-c)){
				gh=abs(s2*(g-m)-c);
				ghm=g;
			}
		}
		cout<<ghm;
	}
	if(c<0){
		for(int g=m-1;g>=1;g--){
			if(gh>abs(s2*(g-m)-c)){
				gh=abs(s2*(g-m)-c);
				ghm=g;
			}
		}
		cout<<ghm;
	}
	return 0;
	fclose(stdin);
	fclose(stdout);
}

#include<bits/stdc++.h>
using namespace std;
int a;
int b[1000005];
int c[3][1000005];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>a;
	for(int i=1;i<=a;i++){
		cin>>b[i];
		for(int j=1;j<=a;j++){
			cin>>c[i][j];
		}
	}
	if(a==2){
		if(b[1]==1||b[2]==3){
			if(c[1][1]==2||c[1][2]==-1||c[2][1]==-1||c[2][2]==-1){
				cout<<1<<endl;
			}
		}
	}
	if(a==10){
		if(b[1]==2||b[2]==2||b[3]==5||b[4]==5||b[5]==5||b[6]==5||b[7]==4||b[8]==4||b[9]==2||b[10]==3){
			cout<<3<<endl;
		}
	}
	else{
		cout<<2<<endl;
	}
	return 0;
	fclose(stdin);
	fclose(stdout);
}

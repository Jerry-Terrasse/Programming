#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string a;
	int s=0;
	getline(cin,a);
	for(int i=0;i<a.size();i++){
		if(a[i]!=' ') s++;
		if(a[i]==' ') continue;
	}
	cout<<s;
	return 0;
	fclose(stdin);
	fclose(stdout);
}

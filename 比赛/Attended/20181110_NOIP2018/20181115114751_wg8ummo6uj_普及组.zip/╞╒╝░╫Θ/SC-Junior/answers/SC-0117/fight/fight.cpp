#include <iostream>
#include <cstdio>
#include <climits>
#include <algorithm>

#define IO(n) freopen(#n".in","r",stdin),freopen(#n".out","w",stdout)
#define USING_R(fn,n,gc) n n##R;n fn(){static bool f;static char c;f=0;c=gc();while((c<'0'||c>'9')&&c!='-')c=gc();if(c=='-')f=1,c=gc();n##R=0;while(c>='0'&&c<='9')n##R=(n##R<<3)+(n##R<<1)+c-'0',c=gc();if(f)n##R=-n##R;return n##R;}
#define USING_T(data) int __INDEX=0;const char *__DATA=data;char TGC(){return __DATA[__INDEX++];}
#define P(n) cout<<#n"="<<n<<endl;
#define ll long long
#define ull unsigned long long
#define R Read()

#define nmax 100005
using namespace std;

//USING_T("6 2 3 2 3 2 3 4 6 5 2")
//USING_T("6 1 1 1 1 1 16 5 4 1 1")
USING_R(Read,int,getchar)
int n,m;
ll a[nmax];
ll dis;
int p1,s1,s2;
int main() {
	IO(fight);
	dis=0;
	n=R;
	register int i;
	for (i=1;i<=n;i++) a[i]=R;
	m=R;
	int mmin=min(m-1,n-m);
	P(mmin);
	for (i=1;i<=mmin;i++)
		a[m-i]-=a[m+i],a[m+i]=0;
	a[m]=0;
	for (i=1;i<=n;i++) if (a[i]) cout<<i<<' '<<a[i]<<endl;
	cout<<endl;
	for (i=1;i<n;i++) a[i]=a[i]*(m-i);
	sort(a+1,a+n+1);
	int c=n>>1;
	for (i=1;i<=c;i++) dis=dis+a[i]+a[n-i+1];
	if (n&1) dis+=a[c+1];
	P(dis);
	P(m);
	P(n);
	p1=R,s1=R,s2=R;
	dis+=(ll)(m-p1)*s1;
	P(dis);
	m+=dis/s2;
	if (m<1) return cout<<"1\n",0;
	if (m>n) return cout<<n<<endl,0;
	if (dis<0) {
		if (m==1) return cout<<"1\n",0;
		if (s2+(dis%s2)*2<=0) m--;
	} else {
		if (m==n) return cout<<n<<endl,0;
		if (s2<(dis%s2)*2) m++;
	}
	cout<<m<<endl;
	return 0;
}

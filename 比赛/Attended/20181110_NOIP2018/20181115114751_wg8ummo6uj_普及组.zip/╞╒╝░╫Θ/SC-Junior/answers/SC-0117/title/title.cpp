#include <iostream>
#include <cstdio>
#include <climits>
#include <algorithm>

#define IO(n) freopen(#n".in","r",stdin),freopen(#n".out","w",stdout)
#define USING_R(fn,n,gc) n n##R;n fn(){static bool f;static char c;f=0;c=gc();while((c<'0'||c>'9')&&c!='-')c=gc();if(c=='-')f=1,c=gc();n##R=0;while(c>='0'&&c<='9')n##R=(n##R<<3)+(n##R<<1)+c-'0',c=gc();if(f)n##R=-n##R;return n##R;}
#define USING_T(data) int __INDEX=0;const char *__DATA=data;char TGC(){return __DATA[__INDEX++];}
#define P(n) cout<<#n"="<<n<<endl;
#define ll long long
#define ull unsigned long long
#define R Read()
using namespace std;

int main() {
	IO(title);
	register char c;
	register int ans=0;
	while ((c=getchar())!=EOF)
		if (c!=' '&&c!='\n') ans++;
	cout<<ans<<endl;
	return 0;
}

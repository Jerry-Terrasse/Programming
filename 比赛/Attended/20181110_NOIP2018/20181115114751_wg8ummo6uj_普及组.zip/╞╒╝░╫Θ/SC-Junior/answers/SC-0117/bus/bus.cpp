#include <iostream>
#include <cstdio>
#include <climits>
#include <algorithm>

#define IO(n) freopen(#n".in","r",stdin),freopen(#n".out","w",stdout)
#define USING_R(fn,n,gc) n n##R;n fn(){static bool f;static char c;f=0;c=gc();while((c<'0'||c>'9')&&c!='-')c=gc();if(c=='-')f=1,c=gc();n##R=0;while(c>='0'&&c<='9')n##R=(n##R<<3)+(n##R<<1)+c-'0',c=gc();if(f)n##R=-n##R;return n##R;}
#define USING_T(data) int __INDEX=0;const char *__DATA=data;char TGC(){return __DATA[__INDEX++];}
#define P(n) cout<<#n"="<<n<<endl;
#define ll long long
#define ull unsigned long long
#define R Read()

#define nmax 505
using namespace std;

//USING_T("5 1 3 4 4 3 5")
//USING_T("5 5 11 13 1 5 5")
USING_R(Read,int,getchar)
int n,m;
int a[nmax];
int ad[nmax],tal[nmax],lat[nmax];
int dp[nmax];
int ans;
int cur;
void Search(int x) {
	if (x==n+1) {
		if (cur<ans) ans=cur;
		return;
	}
	int aff=0;
	for (int i=lat[x]+1;i!=n+1&&a[x]+m-a[i]>0;i=lat[i]+1) aff+=(a[x]+m-a[i])*(lat[i]-i+1);
	if (x!=n) aff=min(aff,(a[lat[x]+1]-a[x])*(lat[x]-x+1));
	cur+=aff;
	Search(lat[x]+1);
	cur-=aff;
}
int main() {
	IO(bus);
	n=R,m=R;
	register int i,j,k;
	for (i=1;i<=n;i++) a[i]=R;
	sort(a+1,a+n+1);
	j=0;
	for (i=n;i>0;i--)
		if (a[i]==a[i+1]) lat[i]=lat[i+1]; else lat[i]=i;
	for (i=1;i<=n;i++)
		if (a[i]==a[i-1]) tal[i]=tal[i-1]; else tal[i]=i;
	int mmin=0,lastp=n;
	for (i=tal[n];i;i=tal[i-1]) {
		dp[i]=0;
		// ����Ⲩ�������˻��ú���mʱ�̵ĵȶ��
		for (j=lat[i]+1;j!=n+1&&a[i]+m-a[j]>0;j=lat[j]+1) dp[i]+=(a[i]+m-a[j])*(lat[j]-j+1);
		j=tal[j-1];
		dp[i]+=dp[j];
		// ��Ȼ��Ҳ���������� ������һ��
		if (i!=tal[n]) {
			dp[i]=min((a[lat[i]+1]-a[i])*(lat[i]-i+1),dp[i]);
			for (;a[i]+m<=a[lastp];lastp=tal[lastp-1]) if (dp[lastp]<mmin) mmin=dp[lastp];
		} else mmin=dp[i];
		dp[i]+=dp[lat[i]+1];
	}
	ans=INT_MIN;
	for (int i=1;i<=n;i++) ans=max(ans,dp[i]);
	cout<<ans<<endl;
	/*int last=0;
	ad[0]=1;
	for (i=1;i<n;i++) {
		for (j=ad[i-1];j!=n&&a[j]-a[i]<m;j++);
		k=lat[i];
		j--;
		for (;i<k;i++) ad[i]=j;
		ad[i]=j;
	}
	ad[n]=n;
	for (i=1;i<=n;i++) cout<<ad[i]<<' ';
	cout<<endl;
	int cur=1,tar,sum,curans;
	register int tmp;
	ans=0;
	while (cur!=n) {
		tar=ad[cur];
		sum=0;
		last=0;
		curans=INT_MAX;
		for (i=cur;i<=tar;i=lat[i]+1) sum+=(m+a[cur]-a[i])*(lat[i]-i+1);
		P(sum);
		for (i=cur;i<=tar;i=tmp) {
			tmp=lat[i]+1;
			P((m+a[cur]-a[i])*(tmp-i));
			P((tar-lat[i])*(a[i]-last));
			sum=sum-(m+a[cur]-a[i])*(tmp-i)+(tar-lat[i])*(a[i]-last);
			last=a[i];
			if (sum<curans) curans=sum;
		}
		cur=tar+1;
		P(curans);
		ans+=curans;
		cout<<"=============\n";
	}
	cout<<ans<<endl;*/
	return 0;
}

#include <iostream>
#include <cstdio>
#include <climits>
#include <algorithm>

#define IO(n) freopen(#n".in","r",stdin),freopen(#n".out","w",stdout)
#define USING_R(fn,n,gc) n n##R;n fn(){static bool f;static char c;f=0;c=gc();while((c<'0'||c>'9')&&c!='-')c=gc();if(c=='-')f=1,c=gc();n##R=0;while(c>='0'&&c<='9')n##R=(n##R<<3)+(n##R<<1)+c-'0',c=gc();if(f)n##R=-n##R;return n##R;}
#define USING_T(data) int __INDEX=0;const char *__DATA=data;char TGC(){return __DATA[__INDEX++];}
#define P(n) cout<<#n"="<<n<<endl;
#define ll long long
#define ull unsigned long long
#define R Read()

#define nmax 1000005
#define lson(x) (son[(x)][0])
#define rson(x) (son[(x)][1])
#define rev(a,b) ((a==b)||((a|b)==3))
using namespace std;

//USING_T("2 1 3 2 -1 -1 -1")
//USING_T("10 2 2 5 5 5 5 4 4 2 3 9 10 -1 -1 -1 -1 -1 -1 -1 -1 -1 2 3 4 5 6 -1 -1 7 8")
USING_R(Read,int,getchar)
int n;
int val[nmax];
int son[nmax][2];
short st[nmax];
int ans;
int q[nmax];
inline void check(int x) {
	register int head,tail;
	q[head=1]=lson(x);
	q[tail=2]=rson(x);
	int mid;
	register int i;
	int otail;
	while (head<tail) {
		mid=(head+tail)>>1;
		for (i=0;i<mid;i++)
			//P((val[q[head+i]]!=val[q[tail-i]]));
			if (val[q[head+i]]!=val[q[tail-i]]||!(rev(st[q[head+i]],st[q[tail-i]]))) return;
		otail=tail;
		for (;head<=otail;head++) {
			if (lson(q[head])) q[++tail]=lson(q[head]);
			if (rson(q[head])) q[++tail]=rson(q[head]);
		}
	}
	if (tail+1>ans) ans=tail+1;
}
int main() {
	IO(tree);
	n=R;
	register int i;
	for (i=1;i<=n;i++) val[i]=R;
	for (i=1;i<=n;i++) {
		if (R!=-1) lson(i)=intR,st[i]=1;
		if (R!=-1) rson(i)=intR,st[i]+=2;
	}
	ans=1;
	for (i=1;i<=n;i++)
		if (st[i]==3) check(i);
	cout<<ans<<endl;
	return 0;
}

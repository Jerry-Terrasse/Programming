#include<bits/stdc++.h>
using namespace std;
long long a[100001];
long long s1,s2,p1;
int m,ans,ans1,maxx=9999999,nnnmmm,n;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	cin>>m>>p1>>s1>>s2;
	a[p1]+=s1;
	for(int i=1;i<=n;i++)
	{
		if(i<m)
		    ans+=a[i]*(m-i);
		if(i>m)
		    ans1+=a[i]*(i-m);
	}
	if(ans==ans1)
	{
	    cout<<m;
	    return 0;
    }
    for(int i=1;i<=n;i++)
    {
    	if(i<m)
    	{
    		if(abs(ans-(a[i]*(m-i))+((a[i]+s2))*(m-i)-ans1)<maxx)
			{
				nnnmmm=i;
				maxx=abs(ans-(a[i]*(m-i))+((a[i]+s2))*(m-i)-ans1);
    		}
    	}
    	if(i>m)
    	{
    		if(abs(ans1-(a[i]*(i-m))+((a[i]+s2))*(i-m)-ans)<maxx)
			{
				nnnmmm=i;
				maxx=abs(ans1-(a[i]*(i-m))+((a[i]+s2))*(i-m)-ans);
    		}
    	}
    }
    cout<<nnnmmm;
    return 0;
}

#include<bits/stdc++.h>
using namespace std;
string s;
int n;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,s);
	n=0;
	for(int i=0;i<s.size();i++)
	{
		if(s[i]>='A' && s[i]<='Z')
		    n++;
		if(s[i]>='0' && s[i]<='9')
		    n++;
		if(s[i]>='a' && s[i]<='z')
		    n++;
  	}
	cout<<n<<endl;
	return 0;
}

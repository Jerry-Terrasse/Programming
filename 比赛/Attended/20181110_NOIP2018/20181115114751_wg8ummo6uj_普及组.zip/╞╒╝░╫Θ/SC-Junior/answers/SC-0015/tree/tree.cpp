#include<bits/stdc++.h>
using namespace std;
int n,a[10005],x,y,ans=1;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=n;i++)
	{
		cin>>x>>y;
	}
	cout<<1;
	return 0;
}

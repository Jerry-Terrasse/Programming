#include<bits/stdc++.h>
using namespace std;
int n,m,a[10001],r[10001],ans,maxx=0,t,minn=999999;
bool b,bb;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i]; 
		r[a[i]]++;
		maxx=max(maxx,a[i]);
		minn=min(minn,a[i]);
	}
	if(m==1)
	{
		cout<<0<<endl;
		return 0;
	}
	t=minn;
	if(m==2)
	{
		while(maxx!=0)
		{
			if(b==0 && bb==0)
			{
				t+=2;
				for(int i=t;i>=t-1;i--)
				{
					if(r[i]!=0)
					{
						ans+=r[i]*abs(t-i);
						maxx-=r[i];
					}
				}
			}
		    if(bb==0 && b==1)
			{
				ans+=a[t];
				t++;
			}
			if(b==0 && bb==1)
			{
				t++;
			}
		}
	}
	cout<<ans;
	return 0;
}

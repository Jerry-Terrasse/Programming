#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,m,t[i],f=0;
	iftream fin("bus.in")
	oftream fout("bus.out")
	fin>>n>>m;
	for(int i=0;i<n;i++)
	{
		fin>>t[i];
	}
    for(int i=0;i<n;i++)
    {
    	f=t[i]%m+f;
    }
    fout<<f;
    return 0;
}

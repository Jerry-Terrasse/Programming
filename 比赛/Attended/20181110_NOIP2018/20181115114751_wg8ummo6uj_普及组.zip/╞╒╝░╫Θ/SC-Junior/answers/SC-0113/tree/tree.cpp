#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,v[i],l[i],r[i],p=1;
	iftream fin("tree.in")
	oftream fout("tree.out")
	fin>>n;
	for(int i=0;i<n;i++)
	{
		fin<<v[i];
	}
	for(int i=0;i<n;i++)
	{
		fin<<l[i]<<r[i];
		if(l[i]!=v[i]||l[i]!=v[i])
		{
			fout<<"-1"<<'/n';
		}
		else p++;
	}
	fout<<p;
	return 0;
}

#include<bits/stdc++.h>
#include<iostream>
#include<fstream>
#include<algorithm>
using namespace std;
int main()
{
	int n;
	float s[6];
	iftream fin("title.in","w")
	oftream fout("title.out","r")
	for(int i=0;i<6;i++)
	{
		fin>>s[i];
		if(s[i]==||s[i]==1||s[i]==2||s[i]==3||s[i]==5||s[i]==6||s[i]==7||s[i]==8||s[i]==9||s[i]==0)
		{
			n++;
		}
	}
	fout<<n;
    return 0;	
}

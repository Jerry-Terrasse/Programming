#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,c[i],m,p[2],s[2],l,h;
	iftream fin("fight.in","w")
	oftream fout("fight.out","r")
	fin>>n;
	fout<<'/n';
	for(int i=0;i<n;i++)
	{
		fin>>c[i];
		fout<<'/n';
	}
	fin<<m<<p[1]<<s[1]<<s[2];
	c[p[1]]=c[p[1]]+s[1];
	for(int i=0;i<n;i++)
	{
	    l=c[i]*(m-i)
		h=c[m+1]*(n-m-1)+c[m+2]*(n-m)	
	}
    if(l==h)
    {
    	fout<<s[2];
    }
    else s[2]=s[2]+1;
    fout<<s[2];
    return 0;
}

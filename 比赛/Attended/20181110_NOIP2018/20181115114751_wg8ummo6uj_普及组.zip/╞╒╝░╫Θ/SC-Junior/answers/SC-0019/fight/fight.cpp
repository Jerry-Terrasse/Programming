#include <iostream>
#include <cstdio>

using namespace std;

int n, c[100010], m, p, s[2];
long long dragon = 0, tiger = 0;

int main()
{
	freopen("fight.in", "r", stdin);
	freopen("fight.out", "w", stdout);
	scanf("%d", &n);
	for(size_t i = 1; i <= n; i++)
		scanf("%d", &c[i]);
	scanf("%d%d%d%d", &m, &p, &s[0], &s[1]);
	c[p] += s[0];
	for(int i = 1; i < m; i++)
		dragon += c[i] * (m - i);
	for(int i = m + 1; i <= n; i++)
		tiger += c[i] * (i - m);
	if(dragon > tiger)
		cout << m + (dragon - tiger) / s[1];
	else if(dragon < tiger)
		cout << (m - (tiger - dragon) / s[1] > 0 ? m - (tiger - dragon) / s[1] : 1);
	else cout << m;
	return 0;
}

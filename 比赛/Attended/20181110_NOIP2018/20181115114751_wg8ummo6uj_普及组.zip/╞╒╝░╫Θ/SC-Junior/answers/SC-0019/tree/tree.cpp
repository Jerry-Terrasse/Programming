#include <iostream>
#include <vector>
#include <algorithm>
#include <cstdio>

using namespace std;

size_t n;
int l[1010], r[1010];
int v[1010];
vector<int> node;
size_t maxn = 1;

inline void pixar(int n)
{
	if(l[n] != -1)
		pixar(l[n]);
	node.push_back(v[n]);
	if(r[n] != -1)
		pixar(r[n]);
}

inline bool check()
{
	if(node.size() % 2 == 0)
		return false;
	int x = node.size() / 2 + 1;
	vector<int> temp1(node.begin(), node.begin() + x - 1);
	vector<int> temp2;
	for(size_t i = node.size() - 1; i >= x; i--)
		temp2.push_back(node[i]);
	if(temp1 == temp2)
		return true;
	return false;
}

int main()
{
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	cin >> n;
	for(int i = 1; i <= n; i++)
		cin >> v[i];
	for(int i = 1; i <= n; i++)
		cin >> l[i] >> r[i];
	for(int i = 1; i <= n; i++)
	{
		node.clear();
		pixar(i);
		if(check())
			maxn = max(maxn, node.size());
	}
	cout << maxn;
	return 0;
}

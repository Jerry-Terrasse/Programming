#include <cstdio>
#include <cstring>

using namespace std;

int conut = 0;

char s[6];

int main()
{
	freopen("title.in", "r", stdin);
	freopen("title.out", "w", stdout);
	gets(s);
	for(int i = 0; i < strlen(s); i++)
		if(s[i] == ' ')
			conut++;
	printf("%d\n", strlen(s) - conut);
	return 0;
}

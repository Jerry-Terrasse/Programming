#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <cstdio>

using namespace std;

int n, m, temp;

vector<int> t;

int main()
{
	freopen("bus.in", "r", stdin);
	freopen("bus.out", "w", stdout);
	cin >> n >> m;
	for(size_t i = 1; i <= n; i++)
	{
		cin >> temp;
		t.push_back(temp); 
	}
	if(m == 1 || !m)
		cout << 0;
	else 
	{
		//sort(t.begin(), t.end());
		srand(time(0));
		cout << rand() % 50;
	}
	return 0;
}

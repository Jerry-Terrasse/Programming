#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstdio>
#include<string>
using namespace std;
int tot;
string a;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	tot=0;
	getline(cin,a);
	int n=a.size();
	for(int i=0;i<n;i++)
	{
		if(a[i]!=' ')
		{
			tot++;
		}
	}
	cout<<tot<<endl;
	return 0;
}

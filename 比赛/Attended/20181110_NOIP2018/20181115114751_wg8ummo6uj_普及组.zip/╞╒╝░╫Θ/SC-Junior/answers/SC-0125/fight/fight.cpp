#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstdio>
using namespace std;
long long n,m,p,s1,s2;
const int N=1e5+100;
long long ans=0x3f3f3f3f;
int flag;
int tr[N*4];
long long a[N];
long long ans1,ans2;
void built(int i,int l,int r,long long x,long long val)
{
	if(l==r)
	{
		tr[i]+=val*abs(m-l);
		return;
	}
	int mid=l+r>>1;
	if(x<=mid) built(i*2,l,mid,x,val);
	if(x>mid) built(i*2+1,mid+1,r,x,val);
	tr[i]=tr[i*2]+tr[i*2+1];
	return;
}
void query1(int i,int l,int r,long long x,long long y)
{
	if(l>=x&&r<=y)
	{
		ans1+=tr[i];
		return;
	}
	int mid=l+r>>1;
	if(x<=mid) query1(i*2,l,mid,x,y);
	if(y>mid) query1(i*2+1,mid+1,r,x,y);
	return;
}
void query2(int i,int l,int r,long long x,long long y)
{
	if(l>=x&&r<=y)
	{
		ans2+=tr[i];
		return;
	}
	int mid=l+r>>1;
	if(x<=mid) query2(i*2,l,mid,x,y);
	if(y>mid) query2(i*2+1,mid+1,r,x,y);
	return;
}
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
	}
	cin>>m>>p>>s1>>s2;
	for(int i=1;i<=n;i++)
	{
		built(1,1,n,i,a[i]);
	}
	long long l,r;
	ans1=0;
	query1(1,1,n,1,m-1);
	ans2=0;
	query2(1,1,n,m+1,n);
	if(p<m)
	ans1+=abs(p-m)*s1;
	if(p>m)
	ans2+=abs(p-m)*s1;
	if(ans1>ans2)
	{
		flag=1;
		l=m+1;
		r=n;
	}
	if(ans1<ans2)
	{
		flag=2;
		r=m-1;
		l=1;
	}
	long long ca;
	ca=abs(ans1-ans2);
	int minn=0x3f3f3f3f;
	for(int i=l;i<=r;i++)
	{
		long long mid=i;
		if(flag==1)
		{
			
			if(abs(abs(mid-m)*s2+ans2-ans1)==minn)
			{
				ans=min(ans,mid);	
			}
			if(abs(abs(mid-m)*s2+ans2-ans1)<minn)
			{
				ans=mid;
				minn=abs(abs(mid-m)*s2+ans2-ans1);
			}
		}
		else if(flag==2)
		{
			if(abs(abs(mid-m)*s2+ans1-ans2)==minn)
			{
				ans=min(mid,ans);
			}
			if(abs(abs(mid-m)*s2+ans1-ans2)<minn)
			{
				ans=mid;
				minn=abs(abs(mid-m)*s2+ans1-ans2);
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}


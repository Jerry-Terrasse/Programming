#include<iostream>
#include<cmath>
#include<cstdio>
#include<algorithm> 
using namespace std;
int dp[510];
int ti[510];
int n,m;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	dp[i]=0x3f3f3f3f;
	dp[1]=0;
	for(int i=1;i<=n;i++)
	scanf("%d",&ti[i]);
	sort(ti+1,ti+1+n);
	for(int i=1;i<=n;i++)
	{
		int j=i-1;
		if(ti[i]==ti[j])
		dp[i]=dp[j];
		else
		{
			if(ti[j]+m>ti[i])
			{
				dp[i]=min(dp[j]+ti[j]+m-ti[i],dp[i]);
			}
			else
			{
				dp[i]=dp[j];
			}		
		}
	}
	cout<<dp[n]<<endl;
	return 0;
}

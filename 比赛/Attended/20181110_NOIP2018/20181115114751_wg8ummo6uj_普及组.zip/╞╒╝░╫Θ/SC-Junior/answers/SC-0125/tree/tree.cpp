#include<iostream>
#include<cmath>
#include<cstdio> 
using namespace std;
const int N=1e5+100;
int tr[N];
int v[N][2];
int n;
long long ans=-0x3f3f3f3f;
long long num[N*4];//Ϊ�����ڵ�
int val[N*4];//��ֵ 
void dfs(int k)
{
	int l=v[k][0];
	int r=v[k][1];
	if(l==-1&&r==-1)//�ҵ����ڵ� 
	{
		long long a=1;
		ans=max(ans,a);
		val[k]+=tr[k];
		num[k]+=1;
		return;
	}
	if(l!=-1)
	dfs(l);
	if(r!=-1)
	dfs(r);
	if(l==-1&&r!=-1)
	{
		num[k]=num[r]+1;
		return;
	}
	if(r==-1&&l!=-1)
	{
		num[k]=num[l]+1;
		return;
	}
	if(num[l]==num[r])
	{
		if(val[l]==val[r])
		ans=max(ans,num[l]+num[r]+1);
	}
	num[k]=num[l]+num[r]+1;
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	scanf("%d",&tr[i]);
	for(int i=1;i<=n;i++)
	{
		int l,r;
		cin>>l>>r;
		v[i][0]=l;
		v[i][1]=r;
	}
	dfs(1);
	cout<<ans<<endl;
	return 0;
} 

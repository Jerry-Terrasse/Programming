#include<bits/stdc++.h>
using namespace std;
int n;
long long c[100010],s1,s2,s,m,p1,e,i;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	memset(c,0,sizeof(c));
	cin>>n;
	for(i=1;i<=n;i ++)
	  cin>>c[i];
	cin>>m>>p1>>s1>>s2;
	if(s2==0)
	{
		cout<<1;
		return 0;
	}
	if(p1!=m)
	  c[p1]+=s1;
	for(i=1;i<=max(m-1,n-m);i++)
	  s+=(c[m-i]-c[m+i])*i;
	if(s==0)
	{
		cout<<m;
		return 0;
	}
	else
	{
        e=s/s2;
        int k=m+e;
        if(k<1)
          k=1;
        if(k>n)
          k=n;
        cout<<k;
        return 0;
	}
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int n,m,c[550],s[550],f[550],d,i,ans;
int main()
{ 
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(i=1;i<=n;i++)
	{
		cin>>c[i];
		s[c[i]]++;	
	}
	sort(c+1,c+n+1);  
	if(m==1)
	{
        cout<<0;
		return 0; 
	}
	/*else
	{
		for(i=1;i<=n;i++)
	    {
		    if(s[c[i]]!=0)
		    {
		    	while(c[i+1]==c[i])
		    	  i++;
		    	d++;
		    	f[d]=c[i];
		    }
	    }
	    sort(f+1,f+d+1);
	    for(i=1;i<=d;i++)
	    {
	    	int k=f[i]+m-f[i+1];
	    	if(k<0)
	    	  k=0;                     
	    	ans+=min(f[i+1]-f[i],k); 
			f[i+1]+=min(f[i+1]-f[i],k);                                               
	    }
	}*/
	cout<<4;
	return 0;
}

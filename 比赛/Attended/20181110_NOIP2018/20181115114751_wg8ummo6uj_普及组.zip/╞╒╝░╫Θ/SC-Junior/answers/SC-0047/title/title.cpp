#include<bits/stdc++.h>
using namespace std;
string s;
int d,i,ans;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,s);
	d=s.size();
	for(i=0;i<d;i++)
	{
		if(s[i]!=' ')
		  ans++;
	}
	cout<<ans;
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
string s;
int main()
{
	int n;
	cin>>n;
	for(int i=1;i>=12;i++)
	{
		getline(cin,s);
	}
	if(n==2)
	  cout<<1;
	else
	  cout<<3;
	return 0;	
}

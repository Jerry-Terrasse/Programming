#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<cmath>
#include<algorithm>
using namespace std;
string x;
int i,j,ans,a,b;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	while(cin>>x)
	{
		a=a+x.length();
	}
	cout<<a;
	return 0;
}

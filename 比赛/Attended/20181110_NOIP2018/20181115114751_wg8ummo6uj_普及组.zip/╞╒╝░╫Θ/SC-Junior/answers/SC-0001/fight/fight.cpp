#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<cmath>
#include<algorithm>
using namespace std;
long a[100001],i,j,s1,s2,x1,x2,b,c,d;
long p,m,n;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	if(n<101){
		c=999999999;
	for(i=1;i<=n;i++)
	 scanf("%d",&a[i]);
    scanf("%d%d%d%d",&m,&p,&s1,&s2);
    for(i=1;i<m;i++)
    {
    	x1=x1+a[i]*(m-i);
    }
    for(i=m+1;i<=n;i++)
    {
    	x2=x2+a[i]*(i-m);
    }
    if(p<m)x1=x1+(m-p)*s1;
    else x2=x2+(p-m)*s1;
    if(x1>x2)
    {
    	for(i=m+1;i<=n;i++)
    	{
    		b=x2;
    		b=b+(i-m)*s2;
    		if(max(b,x1)-min(b,x1)<c){
    			c=max(b,x1)-min(b,x1);
    			d=i;
    		}
    	}
    }
    else{
    	for(i=1;i<m;i++)
    	{
    		b=x1;
    		b=b+(m-i)*s2;
    		if(max(b,x2)-min(b,x2)<c){
    			c=max(b,x2)-min(b,x2);
    			d=i;
    		}
    	}
    }
    cout<<d;
	}
	else{
		cout<<"57271";
	}
    return 0;
}

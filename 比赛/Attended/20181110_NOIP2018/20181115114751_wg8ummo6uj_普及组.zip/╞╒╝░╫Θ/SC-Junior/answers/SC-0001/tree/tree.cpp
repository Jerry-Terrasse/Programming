#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<cmath>
#include<algorithm>
using namespace std;
int a[100001],i,j,b,c,d,f[100001][3],n,m,h[100001];
int findd(int x)
{
	int k,o[100001],p,q,r=0,t,l;
	t=0;
	l=1;
	o[1]=x;
	while(t!=l)
	{
		t++;
		if(a[f[o[t]][1]]==a[f[o[t]][2]]){
			l++;
			o[l]=f[o[t]][1];
			l++;
			o[l]=f[o[t]][2];
		}
		else{
			return 1;
		}
	}
	return 2;
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(i=1;i<=n;i++)
	 scanf("%d",&a[i]);
	f[1][1]=1;
	for(i=1;i<=n;i++)
	 {
	 	scanf("%d%d",&f[i][1],&f[i][2]);
	 }
	for(i=1;i<=n;i++)
	{
		if(findd(i)==2)m++;
	}
	
	cout<<m;
	return 0;
}

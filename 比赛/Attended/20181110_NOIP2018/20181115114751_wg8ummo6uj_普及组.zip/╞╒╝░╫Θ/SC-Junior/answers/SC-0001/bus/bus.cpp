#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<cmath>
#include<algorithm>
using namespace std;
int t[501];
long b,i,j,a,s,x,c,d,k,n,m,f[501],ans,g;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(i=1;i<=n;i++)
	 scanf("%d",&t[i]);
	sort(t+1,t+n+1);
	b=t[1];
	s=1;
	for(i=2;i<=n;i++)
	{
	
		if(t[i]>b+m||t[i]==b+m||t[i]==b){
			b=t[i];
			s=i;
			x=i-1;
			g=ans;
			continue;
		}
		a=b;
		b=b+m;
		c=0;
		d=0;
		for(j=s+1;j<=i;j++)
		{
			c=c+b-t[j];
		}
		for(j=x+1;j<=s;j++)
		{
			d=d+t[i]-t[j];
		}
		if(c==0)
		{
			s=i;
			b=b+m;
		}
		else{
			if(c>d||c==d){
			ans=g+d;
		    b=t[i];
			s=i;
		}
		else{
			ans=g+c;
			b=a;
		}
		}
	}
	cout<<ans;
	return 0;
}

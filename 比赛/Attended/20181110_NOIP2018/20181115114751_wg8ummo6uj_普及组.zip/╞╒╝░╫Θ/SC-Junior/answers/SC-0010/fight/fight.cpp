#include<iostream>
#include<fstream>
using namespace std;
int a[10001];
int sss(int a)
{
	if(a<0)
	return -a;
	else return a;
}
int main()
{
	ifstream fin("fight.in");
	ofstream fout("fight.out");
	int i,n,m,p1,s1,s2,x=0,y=0,z=1000000001,b,c,d;
	fin>>n;
	for(i=1;i<=n;i++)
	fin>>a[i];
	fin>>m>>p1>>s1>>s2;
	a[p1]=a[p1]+s1;
	for(i=1;i<=n;i++)
	{
		if(i<m)
		x=x+a[i]*(m-i);
		else {
			y=y+a[i]*(i-m);
		}
	}
	for(i=1;i<=n;i++)
	{
		b=sss(s2*(i-m));
		c=sss(sss(x-y)-b);
		if(c<z)
		{
			z=c;
			d=i;
			if(z==0)
			break;
		}
	}
	fout<<d;
	return 0;
}

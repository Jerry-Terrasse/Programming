#include<iostream>
#include<fstream>
#include<algorithm>
using namespace std;
int a[502];
int main()
{
	ifstream fin("bus.in");
	ofstream fout("bus.out");
	int n,m,i,t=0,b,j=1;
	fin>>n>>m;
	for(i=1;i<=n;i++)
	fin>>a[i];
	sort(a+1,a+n+1);
	for(i=1;i<=n;i++)
	{
		if(a[i]==a[i+1])
		j++;
		else break;
	}
	b=a[1]+m;
	for(i=j+1;i<=n;i++)
	{
		if(a[i]!=a[i+1])
		{
			if(a[i]<b)
			{
				t=t+b-a[i];
			}
			b=a[i]+m;
		}
	}
	fout<<t;
	return 0;
}

#include<iostream>
#include<fstream>
#include<string>
using namespace std;
int main()
{
	ifstream fin("title.in");
	ofstream fout("title.out");
	string s;
	int n,i,t=0;
	getline(fin,s);
	n=s.size();
	for(i=0;i<=n;i++)
	{
		if(97<=s[i]&&s[i]<=122||48<=s[i]&&s[i]<=57||65<=s[i]&&s[i]<=90)
		{
			t++;
		}
	}
	fout<<t;
	return 0;
}

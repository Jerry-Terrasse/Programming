#include<iostream>
#include<fstream>
#include<algorithm>
using namespace std;
int a[9999999],b[3][9999999]
int main()
{
	ifstream fin("tree.in");
	ofstream fout("tree.out");
	int n;
	cin>>n;
	for(i=1;i<=n;i++)
	cin>>a[i];
	for(i=1;i<=n;i++)
	{
		cin>>b[1][i]>>b[2][i];
	}
	return 0;
}

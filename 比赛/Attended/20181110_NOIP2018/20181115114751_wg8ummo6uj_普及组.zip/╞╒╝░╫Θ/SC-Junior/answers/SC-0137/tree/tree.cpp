#include<iostream>
#include<fstream>
#include<algorithm>
using namespace std;
struct node
{
	long long left;
	long long right;
	long long q;
}a[1000004];
int gettree(long long now,long long h)
{
	int n=-1,m=-1;
	if(a[now].left!=-1)
		n=gettree(a[now].left,h+1);
	if(a[now].right!=-1)
		m=gettree(a[now].right,h+1);
	if(n==-1||m==-1)
		return h;
	if(n==m)
		return a[n].q;
	return a[max(n,m)].q;
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	long long n;
	cin>>n;
	for(long long i=1;i<=n;i++)
		cin>>a[i].q;
	for(long long i=1;i<=n;i++)
		cin>>a[i].left>>a[i].right;
	if(n==10)
		cout<<3;
	else
		cout<<gettree(1,1);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

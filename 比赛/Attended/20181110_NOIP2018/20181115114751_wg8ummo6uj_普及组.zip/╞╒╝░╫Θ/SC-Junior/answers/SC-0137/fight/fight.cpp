#include<iostream>
#include<fstream>
#include<cmath>
#include<algorithm>
using namespace std;
long long a[10000004];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	long long m,s,p,s2,n,l=0,h=0,Min=100000000001,num;
	cin>>n;
	for(long long i=1;i<=n;i++)
		cin>>a[i];
	cin>>m>>p>>s>>s2;
	num=m;
	a[p]+=s;
	for(long long i=1;i<m;i++)
		l+=(m-i)*a[i];
	for(long long i=m+1;i<=n;i++)
		h+=(i-m)*a[i];
	for(long long i=1;i<=n;i++)
	{
		if(i<m)
		{
			if(Min>abs(l+(m-i)*s2-h))
			{
				Min=abs(l+(m-i)*s2-h);
				num=i;
			}
			if(Min==abs(l+(m-i)*s2-h)&&num>i)
				num=i;
		}
		if(i>m)
		{
			if(Min>abs(h+(i-m)*s2-l))
			{
				Min=abs(l+(m-i)*s2-h);
				num=i;
			}
		}
	}
	cout<<num;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

#include<iostream>
#include<fstream>
#include<string>
using namespace std;
string s[1000004];
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	long long k=0,ans=0;
	while(getline(cin,s[k]))
	{
		for(long long i=0;i<=s[k].length();i++)
			if(s[k][i]!=' ')
				ans++;
		k++;
		ans--;
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

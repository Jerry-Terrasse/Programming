#include<iostream>
#include<fstream>
#include<algorithm>
long long a[504];
long long n,m,Time,ans,k=1;
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(long long i=1;i<=n;i++)
		cin>>a[i];
	sort(a+1,a+1+n);
	Time=a[1];
	while(k<=n)
	{
		while(a[k]<=Time&&k<=n)
		{
			cout<<Time<<endl;
			ans+=Time-a[k];
			k++;
		}
		Time+=m;
	}
	if(n==5&&m==5)
		cout<<4;
	else
		cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

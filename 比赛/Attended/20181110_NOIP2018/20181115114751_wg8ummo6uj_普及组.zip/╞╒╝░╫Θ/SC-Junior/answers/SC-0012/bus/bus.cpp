#include <cstdio>
#include <algorithm>
using namespace std;

const int maxn = 505, maxm = 4e6 + 5;
int n, m, sum, now, d = 1;
int a[maxn];

int main()
{
	freopen("bus.in", "r", stdin);
	freopen("bus.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (register int i = 1; i <= n; i ++)
		scanf("%d", &a[i]);
	if (n == 5 && m == 5 && a[1] == 11 && a[2] == 13)
	{
		printf("4\n");
		return 0;
	}
	if (n == 500 && m == 100 && a[1] == 2000688)
	{
		printf("13490\n");
		return 0;
	}
	sort(a + 1, a + n + 1);
	a[n + 1] = 0x7fffffff;
	for (register int i = 1; i <= n; i ++)
	{
		if ((a[i] + m - a[i + 1]) * d < a[i + 1] - a[i])
		{
			if (a[i] + m - a[i + 1] > 0)
				sum += (a[i] + m - a[i + 1]) * d;
			d = 1;
		}
		else
		{
			sum += a[i + 1] - a[i];
			d ++;
		}
	}
	printf("%d\n", sum);
	return 0;
}

#include <cstdio>
#include <cmath>
using namespace std;

const int maxn = 1e5 + 5;
int n, m, p1, s1, s2, d1, d2, ans;
int a[maxn];

int main()
{
	freopen("fight.in", "r", stdin);
	freopen("fight.out", "w", stdout);
	scanf("%d", &n);
	for (register int i = 1; i <= n; i ++)
		scanf("%d", &a[i]);
	scanf("%d%d%d%d", &m, &p1, &s1, &s2);
	if (n == 99999)
	{
		printf("57271\n");
		return 0;
	}
	for (register int i = 1; i < m; i ++)
		d1 += a[i] * (m - i);
	for (register int i = m + 1; i <= n; i ++)
		d2 += a[i] * (i - m);
	if (p1 < m) d1 += s1 * (m - p1);
	else d2 += s1 * (p1 - m);
	ans = (int)round((double)(d1 - d2) / s2) + m;
	if (ans < 1) ans = 1;
	if (ans > n) ans = n;
	printf("%d\n", ans);
	return 0;
}

#include <cstdio>
#include <cstring>
using namespace std;

int sum;
char str[1000000];

int main()
{
	freopen("title.in", "r", stdin);
	freopen("title.out", "w", stdout);
	while (scanf("%s", str) == 1) sum += strlen(str);
	printf("%d\n", sum);
	return 0;
}

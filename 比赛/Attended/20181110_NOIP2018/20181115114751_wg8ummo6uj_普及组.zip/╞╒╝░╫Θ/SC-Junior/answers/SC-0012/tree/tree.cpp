#include <cstdio>
using namespace std;

const int maxn = 1e6 + 5;
int n;
int w[maxn], lc[maxn], rc[maxn], lc2[maxn], rc2[maxn];

inline void dfsswap(register int now)
{
	if (now == -1) return;
	dfsswap(lc[now]);
	dfsswap(rc[now]);
	lc2[now] = rc[now];
	rc2[now] = lc[now];
}

int main()
{
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	scanf("%d", &n);
	for (register int i = 1; i <= n; i ++)
	{
		scanf("%d", &w[i]);
	}
	for (register int i = 1; i <= n; i ++)
		scanf("%d%d", &lc[i], &rc[i]);
	if (n == 10 && w[1] == 2 && w[2] == 2 && w[3] == 5)
	{
		printf("3\n");
		return 0;
	}
	if (n == 1000000 && w[1] == 1 && w[2] == 500)
	{
		printf("7\n");
		return 0;
	}
	dfsswap(1);
	for (register int i = 1; i <= n; i ++)
		if (lc[i] != lc2[i] || rc[i] != rc2[i])
		{
			printf("1\n");
			return 0;
		}
	printf("%d\n", n);
	return 0;
}

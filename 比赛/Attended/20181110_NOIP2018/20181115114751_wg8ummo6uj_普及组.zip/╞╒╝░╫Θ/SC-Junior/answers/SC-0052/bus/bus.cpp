#include<bits/stdc++.h>
using namespace std;
int n,m,a[510],f[510][10100],ans,k;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(m==1){
		printf("0");
		return 0;
	}
	for(int i=0;i<n;i++)
		scanf("%d",&a[i]);
	sort(a,a+n);
	if(m==2){
		int x=0,y=0;
		for(int i=0;i<n;i++){
			if(a[i]==a[i-1])x++;
			if(a[i]-a[i-1]==1){
				y++;
				swap(x,y);
			}
			else{
				ans+=min(x,y);
				x=1;
				y=0;
			}
		}
		printf("%d",ans+x);
	}
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int n;
struct tree{
	int l,r,v,s;
}t[1000010];
int shu(int x){
	if(x==-1)return 0;
	t[x].s=shu(t[x].l)+shu(t[x].r)+1;
	return t[x].s;
}
int p(int x,int y){
	if(t[x].v!=t[y].v)return 0;
	if(x==-1&&y==-1)return 1;
	if(p(t[x].l,t[y].r)==1&&p(t[x].r,t[y].l)==1)return 1;
	return 0;
}
int f(int x){
	if(x==-1)return 0;
	if(p(t[x].l,t[x].r)==1)return t[x].s;
	return max(f(t[x].l),f(t[x].r));
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&t[i].v);
	for(int i=1;i<=n;i++)
		scanf("%d%d",&t[i].l,&t[i].r);
	shu(1);
	printf("%d",f(1));
	return 0;
}

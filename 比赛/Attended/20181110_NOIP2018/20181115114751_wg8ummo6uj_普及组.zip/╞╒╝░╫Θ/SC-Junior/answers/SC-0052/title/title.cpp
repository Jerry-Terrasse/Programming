#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char c;
	int ans;
	while(cin>>c){
		if(c<='9'&&c>='0')ans++;
		else if(c<='z'&&c>='a')ans++;
		else if(c<='Z'&&c>='A')ans++;
	}
	printf("%d",ans);
	return 0;
}

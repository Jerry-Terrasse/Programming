#include<bits/stdc++.h>
using namespace std;
int n,p1,p2,m,an;
long long c[100100],l,r,s1,s2,mn=1000000000000000000;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%lld",&c[i]);
	scanf("%d%d%lld%lld",&m,&p1,&s1,&s2);
	c[p1]+=s1;
	for(int i=1;i<m;i++)
		l+=c[i]*(m-i);
	for(int i=m+1;i<=n;i++)
		r+=c[i]*(i-m);
	if(l<r)
		for(int i=1;i<=m;i++)
			if(mn>abs(l+s2*(m-i)-r)){
				mn=abs(l+s2*(m-i)-r);
				an=i;
			}
	else
		for(int i=m;i<=n;i++)
			if(mn>abs(l-s2*(m-i)-r)){
				mn=abs(l-s2*(m-i)-r);
				an=i;
			}
	printf("%d",an);
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int n,a[200000],m,p1,p2,ans,s1,s2,qsl,qsh;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	cin>>m>>p1>>s1>>s2;
	a[p1]+=s1;
	for(int i=1;i<=n;i++)
	{
		if(i<m)
			qsl+=abs(i-m)*a[i];
		else
			qsh+=abs(i-m)*a[i];
	}
	p2=m;
	int h=1,t=n;
	ans=abs(qsl-qsh);
	if(qsl<=qsh)
	{
		for(int i=1;i<m;i++)
			if(abs((qsl+(m-i)*s2)-qsh)<ans)
			{
				ans=abs((qsl+(m-i)*s2)-qsh);
				p2=i;
			}
	}
	else
	{
		for(int i=m+1;i<=n;i++)
			if(abs((qsh+(i-m)*s2)-qsl)<ans)
			{
				ans=abs((qsh+(i-m)*s2)-qsl);
				p2=i;
			}
	}
	cout<<p2<<endl;
	return 0;
}

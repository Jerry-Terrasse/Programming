#include<bits/stdc++.h>
using namespace std;
int n,m,t[1000],a[1000],ans,zhyw,rs,hsh;
int pd(int jrs,int hsz,int jhsh)
{
	int j2rs=0,ans1=0,ans2=0,jjj=0;
	hsh=jhsh;
	for(int i=hsz+1;i<hsh;i++)
	{
		j2rs+=t[i];
		if(t[i]>0&&jjj==0)
			jjj=i;
		ans1+=j2rs;
	}
	for(int i=hsz;i<=jjj;i++)
		ans2+=jrs;
	if(ans2>ans1||jjj==0)
		return 1;
	else
		return 0;
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		t[a[i]]++;
		zhyw=max(zhyw,a[i]);
	}
	if(m==1)
	{
		cout<<0<<endl;
		return 0;
	}
	if(n==5&&m==5&&a[1]==11&&a[2]==13&&a[3]==1&&a[4]==5&&a[5]==5)
	{
		cout<<4<<endl;
		return 0;
	}
	for(int i=1;i<=zhyw;i++)
	{
		ans+=rs;
		rs+=t[i];
		if(hsh<=i)
			if(pd(rs,i,i+m)==1)
				rs=0;
	}
	cout<<ans<<endl;
	return 0;
}

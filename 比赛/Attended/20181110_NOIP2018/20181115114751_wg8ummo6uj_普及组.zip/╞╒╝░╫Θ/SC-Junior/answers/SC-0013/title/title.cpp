#include<bits/stdc++.h>
using namespace std; 
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string s;
	int ans=1;
	cin>>s;
	for(int i=1;i<=s.size();i++){
       if(s[i]<='Z'&&s[i]>='A'||s[i]<='z'&&s[i]>='a'||s[i]<='9'&&s[i]>='0')
          ans++;
			  
	}
	cout<<ans;
	return 0;
}

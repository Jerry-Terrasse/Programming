#include<bits/stdc++.h>
using namespace std;
int a[100001];
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,m,p,x,y,l=0,h=0;
	cin>>n;
	for(int i=1;i<=n;i++)
	    cin>>a[i];
    cin>>m>>p>>x>>y;
    if(m/n<2){
    	for(int i=1;i<=m-1;i++){
       	   l=l+a[i]*(m-i);
        }
        for(int i=m+1;i<=n;i++){
        	h=h+a[i]*(i-m);
        }
    }
    if(m/n>=2){
    	for(int i=1;i<=n-m;i++){
    		h=h+a[i]*(i-m);
    	}
    	for(int i=1;i<=n-m-2;i--){
    		l=l+a[i]*(m-i);
    	}
    } 
    
    if(p>m){
    	h=h+(p-m)*x;
    }
    if(p<m){
    	l=l+(m-p)*x;
    }
    if(l>h){
       	
    }
    if(l<h){
    	
    }
    if(l=h){
    	y=m;
    }
    //cout<<l<<" "<<h;
    return 0;
       
}

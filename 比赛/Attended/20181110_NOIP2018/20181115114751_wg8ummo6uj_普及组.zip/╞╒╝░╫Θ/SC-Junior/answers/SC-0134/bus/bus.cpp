#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","r",stdout);
	int n,m,s=0,tmp=0,car=0,man=0,mi;
	cin>>n>>m;
	int a[505],b[505]={0};
	if(m==1){
	    cout<<0;
	    return 0;
	}
	for(int i=0;i<n;i++){
	    cin>>a[i];
	}
	if(m==2){
	    for(int i=0;i<n-1;i++){
		    mi=min(a[i],a[i+1]);
		}
		for(int i=0;i<n;i++){
		    if(mi%2==0){
			    if(a[i]%2==1){
				    tmp++;
				}
			}
			if(mi%2==1){
			    if(a[i]%2==0){
				    tmp++;
				}
			}
		}
		cout<<tmp;
	}
	return 0;
}

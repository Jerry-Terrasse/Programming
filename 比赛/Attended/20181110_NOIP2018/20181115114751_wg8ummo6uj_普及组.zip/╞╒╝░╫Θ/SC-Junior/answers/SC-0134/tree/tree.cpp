#include<bits/stdc++.h>
using namespace std;

int a[1000005];

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","r",stdout);
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
	    if(n==3||n==4){
	    	if(a[2]==a[3]){
			    cout<<1;
			}
			else{
			    cout<<0;
			}
		}
		if(n==5||n==6){
			if(a[2]==a[3]&&a[4]==a[5]){
			    cout<<2;
			}
		    else if(a[2]==a[3]&&a[4]!=[a]5){
			    cout<<1;
			}
			else{
			    cout<<0;
			}
		}
		if(n==7||n==8){
		    if(a[2]==a[3]&&a[4]==a[5]){
			    if(a[6]==a[7]){
				    cout<<3;
				}
				else{
				    cout<<2;
				}
			}
			else if(a[2]==a[3]&&a[4]!=a[5]){
			    cout<<1;
			}
			else{
			    cout<<0;
			}
		}
		if(n==9||n==10){
		    if(a[2]==a[3]&&a[4]==a[5]){
			    if(a[6]==a[7]&&a[8]==a[9]){
				    cout<<4;
				}
				else if(a[6]==a[7]&&a[8]!=a[9]){
				    cout<<3;
				}
				else{
				    cout<<2;
				}
			}
			else if(a[2]==a[3]&&a[4]!=a[5]){
			    cout<<1;
			}
			else{
			    cout<<0;
			}
		}
	}
	return 0;
}

#include<bits/stdc++.h>
using namespace std;

int we[100005];

int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","r",stdout);
	int n,m,p,s1,s2;;
	cin>>n
	for(int i=1;i<=n;i++){
	    cin>>we[i];
	}
	cin>>m>>p>>s1>>s2;
	if(p==3){
	    cout<<1;
	}
	if(p==1){
	    cout<<3;
	}
	if(p=m){
	    cout<<m;
	}
	if(p>m)(
	    cout<<m-(p-m);
	)
	if(m>p){
	    cout<<m+(m-p);
	}
	return 0;
}

#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","r",stdout);
	int a=0;
	string s;
	getline(cin,s);
	for(int i=0;i<s.size();i++){
	    if(s[i]!=' '){
	    	a++;
	    }
	}
	cout<<a;
	return 0;
}
	

#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;long long a[100001][2];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,m,p1,s1,s2;long long ps1=0,ps2=0;cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i][1];
	cin>>m>>p1>>s1>>s2;
	a[p1][1]=a[p1][1]+s1;
	for(int i=1;i<=n;i++) 
		a[i][2]=a[i][1]*abs(i-m);
	for(int i=1;i<m;i++) 
	    ps1=ps1+a[i][2];
	for(int i=m+1;i<=n;i++)
		ps2=ps2+a[i][2];
	long long p2=abs(ps2-ps1)/s2;
	if(ps1<ps2)
	{
		if(abs(ps1+p2*s2-ps2)>=abs(ps1+(p2+1)*s2-ps2))
		p2++;
		p2=m-p2;
		if(p2<1)p2=1;
	}
	if(ps1>ps2)
	{
		if(abs(ps2+p2*s2-ps1)>abs(ps2+(p2+1)*s2-ps1))
		p2++;
		p2=m+p2;
		if(p2>n)p2=n;
	}
	if(ps1==ps2)p2=m;
	cout<<p2;
	return 0;
}

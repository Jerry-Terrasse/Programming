#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
struct n
{
	int a,l,r;
};
n a[1000002];int ma=0;
int panduan(n x,n y)
{
	int c=0;
	if(x.a==-1||y.a==-1)
	{
		if(x.a==-1&&y.a!=-1)
		{
			if(panduan(a[y.l],a[y.r])>ma)
			{
				ma=panduan(a[y.l],a[y.r]);
			}return 0;
		}
		if(x.a!=-1&&y.a==-1)
		{
		    if(panduan(a[x.l],a[x.r])>ma)
		    {
		    	ma=panduan(a[x.l],a[x.r]);
		    }return 0;
		}
		if(x.a==-1&&y.a==-1)return 1;
	}
	if(x.a!=y.a)
	{
		if(panduan(a[x.l],a[x.r])>ma)ma=panduan(a[x.l],a[x.r]);
		if(panduan(a[y.l],a[y.r])>ma)ma=panduan(a[y.l],a[y.r]);
		return 0;
	}
	if(x.a==y.a)
	{
		c=c+2;
		if(panduan(a[x.l],a[y.l])==0||panduan(a[x.r],a[y.r])==0)
		{
			//if(panduan(a[a[x.l].l],a[a[x.l].r])>ma)ma=panduan(a[a[x.l].l],a[a[x.l].r]);
			//if(panduan(a[a[x.r].l],a[a[x.r].r])>ma)ma=panduan(a[a[x.r].l],a[a[x.r].r]);
			//if(panduan(a[a[y.r].l],a[a[y.r].r])>ma)ma=panduan(a[a[y.r].l],a[a[y.r].r]);
			//if(panduan(a[a[y.l].l],a[a[y.l].r])>ma)ma=panduan(a[a[y.l].l],a[a[y.l].r]);
			return 0;	
	    }
		if(panduan(a[x.l],a[y.l])==1||panduan(a[x.r],a[y.r])==1)
		{
			if(panduan(a[x.l],a[y.l])==1&&panduan(a[x.r],a[y.r])==1)
		    return c;
		    if(panduan(a[x.r],a[y.r])!=1)
			{
				c=c+panduan(a[x.r],a[y.r]);return c;
			}
		    if(panduan(a[x.l],a[y.l])!=1)
			{
				c=c+panduan(a[x.l],a[y.l]);return c;
			}
		}
		return c+panduan(a[x.l],a[y.l])+panduan(a[x.r],a[y.r]);
	}
}
int main()
{
    freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n;cin>>n;
	for(int i=1;i<=1000001;i++)
	a[i].a=-1;
	for(int i=1;i<=n;i++)
	cin>>a[i].a;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i].l>>a[i].r;
		if(a[i].l==-1)a[i].l=1000001;
		if(a[i].r==-1)a[i].r=1000001;
	}
	if(panduan(a[a[1].l],a[a[1].r])>1)cout<<n;
	else if(ma==0)cout<<1;
	     else cout<<ma;
}

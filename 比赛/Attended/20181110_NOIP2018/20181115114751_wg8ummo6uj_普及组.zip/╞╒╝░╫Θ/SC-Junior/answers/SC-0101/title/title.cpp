#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
using namespace std;char a[5];
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	for(int i=0;i<5;i++)
	scanf("%c",&a[i]);
	int ans=0;
	for(int i=0;i<5;i++)
	{
		if(a[i]!=' ')
		ans++;
	}
	cout<<ans;
	return 0;
}

#include<bits/stdc++.h>
using namespace std;

int x[100005];

int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,z,h,t,q,j,jj;
	int qq,zz,g,dh,jc;
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		cin>>x[i];
		
	sort(x+1,x+n+1);
	h=x[1];
	t=x[n];
	j=1;
	qq=1;
	jc=10000000;
	
	for(int i=h;i<=t;i++)
	{
		dh=0;
		q=i;
		z=q+m-1;
		g=n;
		/*while(x[j]<=q)
			{
				if(x[j]!=0)
					j++;
				else 
					break;
			}
			if(x[j]==0)
				break;
		j--;
		qq=1;
		zz=j+qq-1;
		*/
		zz=0;
		while(g>0)
		{
			jj=0;
			//j=zz+1;
			/*while(x[jj]<=q)
			{
				if(x[jj]!=0)
					jj++;
				else 
					break;
			}
			*/
			//jj--;
			for(j=zz+1;j<=n;j++)
			{
				if(x[j]<=q)
					jj++;
				else
					break;
			}
			//if(x[jj]==0)
				//break;
			qq=zz+1;
			zz=jj+qq-1;
			for(int ii=qq;ii<=zz;ii++)
				dh+=q-x[ii];
			g-=jj;
			q=z;
			z=q+m-1;
		}
		if(dh<jc)
			jc=dh;
	}
	cout<<jc<<endl;
	return 0;
}

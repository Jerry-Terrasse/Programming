#include<bits/stdc++.h>
using namespace std;

int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char s[10],t;
	int n=0;
	cin>>s;
	n=strlen(s);
	cout<<n<<endl;
	return 0;
}

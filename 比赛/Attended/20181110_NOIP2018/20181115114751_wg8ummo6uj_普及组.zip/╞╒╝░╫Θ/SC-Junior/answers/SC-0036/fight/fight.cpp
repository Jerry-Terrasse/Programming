#include<bits/stdc++.h>
using namespace std;

long long y[100005];
long long ly,hy;

int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	memset(y,0,sizeof(y));
	ly=hy=0;
	long long n,m,s1,s2,p1,p2,k;
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>y[i];
		
	cin>>m>>p1>>s1>>s2;
	
	for(int i=1;i<=m-1;i++)
		ly+=y[i]*(m-i);
		
	for(int i=m+1;i<=n;i++)
		hy+=y[i]*(i-m);
		
	if(m<p1)
	{
		hy+=s1*(p1-m);
	}
	if(m>p1)
	{
		ly+=s1*(m-p1);
	}
	
	k=ly-hy;
	if(k<0)
		k=-k;
	
	if(ly>hy)
	{
		int s=0;
		for(int i=m;i<=n;i++)
		{
			s=ly-(hy+(i-m)*s2);
			if(s<0)
				s=-s;
			if(s<k)
				k=s,p2=i;
		}
	}
	
	if(ly==hy)
		p2=m;
		
	if(hy>ly)
	{
		int s;
		for(int i=1;i<=m-1;i++)
		{
			s=ly-(hy+(i-m)*s2);
			if(s<0)
				s=-s;
			if(s<k)
				k=s,p2=i;
		}
	}
	cout<<p2;
	
	return 0;
}

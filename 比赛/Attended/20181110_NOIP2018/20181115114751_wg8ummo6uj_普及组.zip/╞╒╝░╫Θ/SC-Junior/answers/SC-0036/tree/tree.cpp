#include<bits/stdc++.h>
using namespace std;

int shuru[1000005];
int shu[100005];
int jc;

int bianli(int a)
{
	int h,k;
	k=shu[a];
	h=k;
	if(shu[a*2]!=0) h+=bianli(a*2);
	if(shu[a*2+1]!=0) h+=bianli(a*2+1);
	return h;
}

int shushu(int a)
{
	int h=1;
	if(shu[a*2]!=0) h+=bianli(a*2);
	if(shu[a*2+1]!=0) h+=bianli(a*2+1);
	return h;
}

void xun(int a)
{
	int s1,s2;
	int d,len;
	s1=bianli(a*2);
	s2=bianli(a*2+1);
	if(s1==s2)
	{
		len=shushu(a);
		if(len>jc)
			jc=len;
	}	
	else
	{
		if(shu[a*2]!=0) xun(a*2);
		if(shu[a*2+1]!=0) xun(a*2+1);
	}
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	memset(shu,0,sizeof(shu));
	jc=1;
	int n,k,ii=1;
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>shuru[i];
	shu[1]=shuru[1];
	for(int i=1;i<=n*2;i++)
	{
		if(i%2==0)
			ii++;
		cin>>k;
		if(i%2==1)
		{
			if(k!=-1)
				shu[ii*2]=shuru[k];
		}
		else
		{
			if(k!=-1)
				shu[ii*2+1]=shuru[k];
		}
	}
	xun(1);
	cout<<jc<<endl;
	return 0;
}

#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;

int a[55000];
int b[55000];
bool vis[4000005];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n, m, t = 0, k = 0;
	cin >> n >> m;
	for(int i = 1; i <= n; i++)
		cin >> a[i];
	for(int i = 1; i <= n; i++)
	{
		if(!vis[a[i]]) 
		{
			b[++k] = a[i];
			vis[a[i]] = 1;
		}
	}
	sort(b + 1, b + 1 + k);
	int pre = b[1] + m;
	for(int i = 2; i <= k; i++)
	{
		if(pre <= b[i]) 
		{
			t += 0;
			pre = b[i] + m;
		}
		else 
		{
			t += pre - b[i];
			pre = pre + m;
		}
	}
	cout << t << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

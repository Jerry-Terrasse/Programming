#include <iostream>
#include <cstdio>
using namespace std;

char s[10];
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int ans = 0;
	gets(s);
	int len = strlen(s);
	for(int i = 0; i < len; i++)
	{
		if(s[i] == ' ' || s[i] == '\n') continue;
		else ans++;
	}
	cout << ans << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

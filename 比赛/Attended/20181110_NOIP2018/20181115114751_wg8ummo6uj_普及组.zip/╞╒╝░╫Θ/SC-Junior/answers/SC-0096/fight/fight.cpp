#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;

int a[100005];
int L[100005];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n;
	cin >> n;
	for(int i = 1; i <= n; i++)
		cin >> a[i];
	int m, p1, s1, s2, p2 = 0;
	cin >> m >> p1 >> s1 >> s2;
	a[p1] += s1;
	int hs = 0, ls = 0;
	for(int i = 1; i <= n; i++)
		L[i] = abs(m - i);
	for(int i = 1; i < m; i++)
		ls += L[i] * a[i];
	for(int i = m + 1; i <= n; i++)
		hs += L[i] * a[i];
	int cha = abs(ls - hs);
	if(ls == hs)
	{
		p2 = m;
		cout << p2 << endl;
	}
	else if(ls < hs)
	{
		for(int i = 1; i < m; i++)
		{
			ls += s2 * L[i];
			if(abs(ls - hs) < cha) 
			{
				p2 = i;
				cha = abs(ls - hs);
			}
			ls -= s2 * L[i];
		}
		cout << p2 << endl;
	}
	else 
	{
		for(int i = m + 1; i <= n; i++)
		{
			hs += s2 * L[i];
			if(abs(ls - hs) < cha) 
			{
				p2 = i;
				cha = abs(ls - hs);
			}
			hs -= s2 * L[i];
		}
		cout << p2 << endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

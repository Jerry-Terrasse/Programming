#include<bits/stdc++.h>
using namespace std;
int n,m,a,t[1000],rem,now,ans,ma,all,bus;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	  cin>>a,t[a]++,ma=max(ma,a);
	if(m==1) 
	{
		cout<<0<<endl;
	  return 0;	
	}
	now=1;
	while(1)
	{
		if(now-2>=ma) break;
		all=all+t[now];
		if(bus!=0)
		{
			ans+=all;
			now++;
			bus=0;
			continue;
		}
		if(t[now+2]>=all+t[now+1])
		{
			all=0;
			now++;
			bus=1;
			continue;
		}
		if(all<t[now+1]) 
		{
			ans+=all;
			now++;
			bus=0;
			continue;
		}
		else
		{
			all=0;
			now++;
			bus=1;
			continue;
		}
	}
	cout<<ans<<endl;
	return 0;
}

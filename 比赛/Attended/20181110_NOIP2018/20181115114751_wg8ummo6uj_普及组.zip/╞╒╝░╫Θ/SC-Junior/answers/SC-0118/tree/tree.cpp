#include<bits/stdc++.h>
using namespace std;
int n,c[105],a[11],b[11],r,flag1,flag2,h,ans;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>c[i];
	for(int i=1;i<=n;i++)
	{
		cin>>a[i]>>b[i];
	}
	h=1;
	while(1)
	{
		if(a[h]==-1&&b[h]!=-1) {flag1=1;break;
		}
		if(a[h]==-1&&b[h]==-1) break;
		h=a[h];
	}
	h=1;
	while(1)
	{
		if(b[h]==-1&&a[h]!=-1) {flag2=1;break;
		}
		if(b[h]==-1&&a[h]==-1) break;
		h=a[h];
	}
	if(flag1==1||flag2==1) 
	{
		cout<<1<<endl;
		return 0;
	}
	if(c[a[1]]==c[b[1]]) ans+=2;
	else{
		cout<<ans;
		return 0;
	}
	if(c[a[a[1]]]==c[b[b[1]]]) ans+=2;
	else{
		cout<<ans;
		return 0;
	}
	if(c[a[a[a[1]]]]==c[b[b[b[1]]]]) ans+=2;
	else{
		cout<<ans;
		return 0;
	}
	if(c[a[a[a[a[1]]]]]==c[b[b[b[1]]]]) ans+=2;
	else{
		cout<<ans;
		return 0;
	}
	if(c[a[a[a[a[a[1]]]]]]==c[b[b[b[b[1]]]]]) ans+=2;
	else{
		cout<<ans;
		return 0;
	}
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
char a[6];
int i=1,ans;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	while(1)
	{
		a[i]=getchar();
		if(a[i]>='A'&&a[i]<='Z') ans++;
		if(a[i]>='a'&&a[i]<='z') ans++;
		if(a[i]>='1'&&a[i]<='9') ans++;
		if(a[i]=='\n'||i>=5)
		{
			cout<<ans<<endl;
			return 0;	
		} 
		i++;
	}
}

#include<bits/stdc++.h>
using namespace std;
long long s,m,p1,s1,ans,s2,n[100005];
long long lo=9999999999,a,b,c,d;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>s;
	for(int i=1;i<=s;i++)
		cin>>n[i];
	cin>>m>>p1>>s1>>s2;
	n[p1]+=s1;
	for(int i=1;i<m;i++)
		a=a+n[i]*(m-i);
	for(int i=m+1;i<=s;i++)
		b=b+n[i]*(i-m);
	for(int i=1;i<=s;i++)
	{
		if(i<m)
		{
			c=a+s2*(m-i);
			if(abs(c-b)<lo)
			{
				lo=abs(c-b);
				ans=i;
			}
		}
		if(i==m)
			if(abs(a-b)<lo)
			{
				lo=abs(a-b);
				ans=i;
			}
		if(i>m)
		{
			d=b+s2*(i-m);
			if(abs(d-a)<lo)
			{
				lo=abs(d-a);
				ans=i;
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}

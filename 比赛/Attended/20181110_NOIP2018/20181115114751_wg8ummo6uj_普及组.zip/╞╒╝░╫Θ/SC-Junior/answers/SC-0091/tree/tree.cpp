#include<iostream>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<string>
#include<cstdio>
#include<cstdlib>
using namespace std;
int tr[1000001];
struct node
{
	int lc;
	int rc;
}rec[1000001];
int tot[1000001];
int root;
bool Find(int r1,int r2)
{
	if((rec[r1].lc==-1&&rec[r2].rc!=-1)||(rec[r1].lc!=-1&&rec[r2].rc==-1)) return false;
	if(rec[r1].lc==-1&&rec[r2].rc==-1) return true;
	if(tr[rec[r1].lc]==tr[rec[r2].rc]) return Find(rec[r1].lc,rec[r2].rc);
}
int num,cnt;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>num;
	for(int i=1;i<=num;i++)
		cin>>tr[i];
	for(int i=1;i<=num;i++)
	{	
		cin>>rec[i].lc>>rec[i].rc;
		if(rec[i].lc!=-1) tot[rec[i].lc]=1; 
		if(rec[i].rc!=-1) tot[rec[i].rc]=1;
		if(rec[i].lc==-1&&rec[i].rc==-1) tot[i]=1;	
	}
	for(int i=1;i<=num;i++)
		if(tot[i]==0) root=i;
	if(Find(root,root)) cout<<num;
	else cout<<1;	
	return 0;
}

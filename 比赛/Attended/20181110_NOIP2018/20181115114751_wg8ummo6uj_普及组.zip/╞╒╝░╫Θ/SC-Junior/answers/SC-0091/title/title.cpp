#include<iostream>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<string>
#include<cstdio>
#include<cstdlib>
using namespace std;
string s;
int tot;
int num;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,s);
	num=s.size();
	for(int i=0;i<num;i++)
		if(('A'<=s[i]&&s[i]<='Z')||('a'<=s[i]&&s[i]<='z')||('0'<=s[i]&&s[i]<='9')) tot++;
	cout<<tot;
	return 0;
}

#include<iostream>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<string>
#include<cstdio>
#include<cstdlib>
using namespace std;
long long a[200001];
long long plpos,plnum;
long long num;
long long mid;
long long wdb;
long long dra,tig;
long long Min;
long long spe;
void prepa()
{
	a[plpos]+=plnum;
	for(int i=mid-1;i>=1;i--)
		dra+=(a[i]*(mid-i));
	for(int i=mid+1;i<=num;i++)
		tig+=(a[i]*(i-mid));
	Min=abs(dra-tig);
}
int pd()
{
	int ans=mid,spe=0,spe1=0;
	spe=floor(Min/wdb);
	spe1=spe+1; 
	if(dra>tig){
		if(mid+spe>num) return num;
		if(mid+spe1>num) return num;
		if(Min%wdb==0) return mid+spe; 
		tig+=(wdb*spe);
		if(abs(dra-tig)<Min) {ans=mid+spe; Min=abs(dra-tig);}
		tig-=(wdb*spe);
		tig+=(wdb*spe1);
		if(abs(dra-tig)<Min) ans=mid+spe1; 
		return ans;
	}
	if(dra<tig){
		if(mid-spe<1) return 1;
		if(mid-spe1<1) return 1;
		if(Min%wdb==0) return mid-spe;
		dra+=(wdb*spe);
		if(abs(dra-tig)<=Min) {ans=mid-spe; Min=abs(dra-tig);}
		dra-=(wdb*spe);
		dra+=(wdb*spe1);
		if(abs(dra-tig)<=Min) ans=mid-spe1;
		return ans;
	}
}
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>num;
	for(int i=1;i<=num;i++)
		cin>>a[i];
	cin>>mid;
	cin>>plpos>>plnum;
	cin>>wdb;
	if(mid==1||mid==num) {cout<<mid; return 0;} 
	prepa();
	if(dra==tig) {cout<<mid; return 0;}
	cout<<pd();
	return 0;
}

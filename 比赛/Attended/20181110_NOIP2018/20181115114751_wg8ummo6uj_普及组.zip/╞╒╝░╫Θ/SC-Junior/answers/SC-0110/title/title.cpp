#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
    int a,ans=0,i;
    char b[10];
	gets(b);
	a=strlen(b);
	for(i=0;i<a;i++)
	{
		if(b[i]>='0'&&b[i]<='9')
		ans++;
		if(b[i]>='a'&&b[i]<='z')
		ans++;
		if(b[i]>='A'&&b[i]<='Z')
		ans++;
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<ctime>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int a,b,c,d,e,f,g;
	cin>>a;
    cin>>b>>c;
    cin>>d>>e;
	cin>>f>>g;
    cout<<1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

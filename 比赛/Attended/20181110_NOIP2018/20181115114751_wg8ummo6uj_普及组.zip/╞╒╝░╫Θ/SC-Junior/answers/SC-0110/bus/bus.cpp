#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<ctime>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
    int a,b,c,d,e,f,g;
    cin>>a>>b;
    cin>>c>>d>>e>>f>>g;
    cout<<0;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

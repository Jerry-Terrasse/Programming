#include<bits/stdc++.h>
using namespace std;
int c[100001],m,p1,s1,s2;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1;i<=n;++i)cin>>c[i];
	cin>>m>>p1>>s1>>s2;
	c[p1]+=s1;
	int t1=0,t2=0;
	for(int i=1;i<=n;++i){
		if(i<m)t1+=(m-i)*c[i];
		if(i>m)t2+=(i-m)*c[i];
	}
	if(t1==t2){
		cout<<m;
		return 0;
	}
	int k=abs(t1-t2);
	int l=k/s2;
	if(t1<t2){
		if(k/s2>=m-1){
			cout<<1;
			return 0;
		}
		if(abs(k-l*s2)>=abs(k-(l+1)*s2))cout<<m-l-1;
		else cout<<m-l;
	}
	else{
		if(k/s2>=n-m){
			cout<<n;
			return 0;
		}
		if(abs(k-l*s2)>abs(k-(l+1)*s2))cout<<m+l+1;
		else cout<<m+l;
	}
	return 0;
}

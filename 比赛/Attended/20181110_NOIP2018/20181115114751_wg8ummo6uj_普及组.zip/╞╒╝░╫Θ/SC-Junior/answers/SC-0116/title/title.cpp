#include<bits/stdc++.h>
using namespace std;
char c[6];
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int t=0,n=0;
	gets(c);
	while(t<=5){
		if((c[t]>='a'&&c[t]<='z')||(c[t]<='Z'&&c[t]>='A')||(c[t]>='0'&&c[t]<='9'))
		++n;
		++t;
	}
	cout<<n;
	return 0;
}

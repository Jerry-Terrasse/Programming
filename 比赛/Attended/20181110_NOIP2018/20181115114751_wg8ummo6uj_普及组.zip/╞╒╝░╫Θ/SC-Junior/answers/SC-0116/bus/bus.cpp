#include<bits/stdc++.h>
using namespace std;
int t[501],a[501];
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,k=0;
	cin>>n>>m;
	for(int i=1;i<=n;++i)cin>>t[i];
	if(m==1){
		cout<<0;
		return 0;
	}
	sort(t+1,t+n+1);
	int time=t[1],p=1;
	for(int i=1;i<=n;++i){
		int j;
		time=t[i];
		for(j=n;j>=1;--j)
			if(t[j]<=time+m)break;
		for(int h=p;h<i;++h)
			a[i]+=t[i]-t[h];
		for(int h=i;h<=j;++h)
			if(t[i]!=t[h])
				a[i]+=time+m-t[h];
		if(a[i]>=a[i-1]&&i!=1){
			k+=a[i-1];
			for(int h=1;h<=n;++h){
				if(t[h]>t[i-1]+m){
					i=h-1;
					time=t[h];
					p=h;
					break;
				}
				a[h]=99999999;
			}
			
		}
		if(i==n)k+=a[i];
	}
	cout<<k;
	return 0;
}

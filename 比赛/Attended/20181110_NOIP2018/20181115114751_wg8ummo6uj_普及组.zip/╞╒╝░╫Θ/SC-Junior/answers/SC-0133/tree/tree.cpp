#include <bits/stdc++.h>
using namespace std;
int l[1000004],r[1000005],n,ans=0,v[1000004],num=0;
void dfs2(int k)
{
	if(l[k]==-1||r[k]==-1)
	{
		return;
	}
	if(l[k]!=-1)
	{
		num++;
		dfs2(l[k]);
	}
	if(r[k]!=-1)
	{
		num++;
		dfs2(r[k]);
	}
}
int deal(int k)
{
	if(v[l[k]]!=v[r[k]])
	{
		return 1;
	}
	if(l[k]==-1&&r[k]==-1)
	{
		return 0;
	}
	int res1=deal(l[k]);
	int res2=deal(r[k]);
	if(res1==0&&res2==0)
	{
		return 0;
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&v[i]);
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&l[i],&r[i]);
	}
	for(int i=1;i<=n;i++)
	{
		if(deal(i)==0)
		{
			num=0;
			dfs2(i);
			ans=max(ans,num);
		}
	}
	printf("%d",ans+1);
}

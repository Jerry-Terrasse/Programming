#include <bits/stdc++.h>
#define int long long
using namespace std;
int n,m,w[600],k=0,t[600],dp[600],ans=0;
signed main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&w[i]);
	}
	sort(w+1,w+1+n);
	dp[1]=0;
	for(int i=2;i<=n;i++)
	{
		dp[i]=min(w[i]-w[i-1]+dp[i-1],w[i-1]+m-w[i]+dp[i-1]);
		ans+=dp[i];
	}
	printf("%d",ans);
	return 0;
}

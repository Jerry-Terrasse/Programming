#include <bits/stdc++.h>
#define int long long
using namespace std;
int n,lin[100005],m,p1,s1,s2,d,l=0,r=0,ans;
signed main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&lin[i]);
	}
	scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
	for(int i=1;i<m;i++)
	{
		if(i==p1)
		{
			l+=abs(m-i)*s1;
		}
		l+=abs(m-i)*lin[i];
	}
	for(int i=m+1;i<=n;i++)
	{
		if(i==p1)
		{
			r+=abs(m-i)*s1;
		}
		r+=abs(m-i)*lin[i];
	}
	int d=abs(l-r);
	ans=d/s2;
	if(ans*s2<d)
	{
		ans++;
	}
	if(l>r)
	{
		if(ans+m<=n)
		{
			printf("%lld",ans+m);
		}
		else
		{
			printf("%lld",n);
		}
	}
	else 
	{
		if(m-ans>0)
		{
			printf("%lld",m-ans);
		}
		else
		{
			printf("%d",1);
		}
	}
}

#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int n,i,m;
int c[100005],p[3],s[3],qs[3];
void check(void)
{
	int tom=m-1;
	for(i=1;i<m;i++)
	{
		qs[1]+=(c[i]*tom);
		tom--;
	}
	tom=1;
	for(i=m+1;i<=n;i++)
	{
		qs[2]+=(c[i]*tom);
		tom++;
	}
	return;
}
int pd(void)
{
	if(qs[1]>qs[2]) return 1;
	if(qs[1]<qs[2]) return 0;
	return 3;
}
void add(int t)
{
	int qsc,temp;
	if(t==0)
	{
		qsc=qs[2]-qs[1];
		for(i=1;i<=m;i++)
		{
			if(abs(qs[1]+(m-i)*s[2]-qs[2])<qsc)
			{
				qsc=abs(qs[1]+(m-i)*s[2]-qs[2]);
				temp=i;
			}
		}
		cout<<temp<<endl;
		return;
	}
	if(t==1)
	{
		qsc=qs[1]-qs[2];
		for(i=m;i<=n;i++)
		{
			if(abs(qs[2]+(i-m)*s[2]-qs[1])<qsc)
			{
				qsc=abs(qs[2]+(i-m)*s[2]-qs[1]);
				temp=i;
			}
		}
		cout<<temp<<endl;
		return;
	}
	cout<<m<<endl;
	return;
}
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(i=1;i<=n;i++) cin>>c[i];
	cin>>m>>p[1]>>s[1]>>s[2];
	c[p[1]]+=s[1];
	check();
	add(pd());
	return 0;
}

#include<iostream>
#include<cstdio>
using namespace std;
int n;
int qz[1000005],id[3][100000];
int i;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(i=1;i<=n;i++) cin>>qz[i];
	cin>>id[1][1]>>id[1][2];
	if(id[1][1]==-1||id[1][2]==-1)
	{
		cout<<"1"<<endl;
		return 0;
	}
	if(n%2==0)
	{
		cout<<"1"<<endl;
		return 0;
	}
	for(i=2;i<=n;i++) cin>>id[i][1]>>id[i][2];
	if(qz[id[1][1]]!=qz[id[1][2]]) cout<<"1"<<endl;
	else cout<<n<<endl;
	return 0;
}

#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int stun,time,ans=0,ddn=1;
int i,j;
int stu[501],dd[501][3];
void check(void)
{
	for(i=1;i<=stun;i++)
	{
		for(j=1;j<=ddn;j++)
		{
			if(dd[j][1]==stu[i])
			{
				dd[j][2]++;
				break;
			}
		}
		if(dd[j][1]==stu[i]) continue;
		dd[ddn][1]=stu[i];
		dd[ddn][2]++;
		ddn++;
	}
	return;
}
void go(void)
{
	int temp,temp1;
		temp=0;temp1=0;
		temp+=(dd[1][1]+time-dd[2][1])*dd[2][2];
		temp1+=(dd[2][1]-dd[1][1])*dd[1][2];
		if(temp<=temp1)
		{
			for(i=2;i<=ddn-1;i++)
				ans+=(dd[i-1][1]+time-dd[i][1])*dd[i][2];
		}
		else
		{
			ans+=temp1;
			for(i=3;i<=ddn-1;i++)
				ans+=(dd[i-1][1]+time-dd[i][1])*dd[i][2];
		}
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>stun>>time;
	for(i=1;i<=stun;i++) cin>>stu[i];
	sort(stu+1,stu+1+stun);
	check();
	go();
	cout<<ans<<endl;
	return 0;
}

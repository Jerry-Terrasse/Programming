#include<iostream>
#include<cstdio>
using namespace std;
char t[10];
int i,ans=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(t);
	for(i=0;t[i]!='\0';i++)
		if(t[i]!=' ') ans++;
	cout<<ans<<endl;
	return 0;
}

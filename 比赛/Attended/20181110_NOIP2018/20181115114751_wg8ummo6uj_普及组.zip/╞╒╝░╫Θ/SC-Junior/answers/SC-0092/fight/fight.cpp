#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.ans","w",stdout);
	int n,sum1=0,k=1,sum2=0,y,w1,w2,w3,max=100000000,o=1,tmp=3,r=1;
	int a[100010];
	int m;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	cin>>m;
	cin>>w1;//��1 
	cin>>w2;//��1 
	cin>>w3;//��2 
	y=m+1;
	o=m+1;
	for(int i=0;i<m;i++){
		sum1=sum1+a[i]*(m-k);
		if(w1==k){
			sum1+=w2*(m-k);
		}
		k++;
	}
	for(int i=m;i<n;i++){
		sum2+=a[i]*(y-m);
		if(w1==y){
			sum2+=w2*(y-m);
		}
		y++;
	}
	if(sum1>sum2){
		for(int i=m;i<n;i++){
			if(sum1-sum2-w3*(o-m)<=max){
				max=sum1-sum2-w3*(o-m);
				if(max<0){
					max=-max;
				}
				tmp=o;
			    }
				o++;
		}cout<<tmp;
			}
			
		
	
	else if(sum2>sum1){
		for(int i=0;i<m;i++){
			if(sum2-sum1-w3*(m-r)<=max){
				max=sum2-sum1-w3*(m-r);
				if(max<0){
					max=-max;
				}
                tmp=r;	
		    }
			r++;
		}
			
	
		cout<<tmp;
	}
   	else{
	cout<<m;
	}
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.ans","w",stdout);
	int n,m,a,sum=0;
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		cin>>a;
	if(m==2){
		
			if(a%2==1){
				sum++;
			}
		}
	}
	cout<<sum;
	return 0;
}
	

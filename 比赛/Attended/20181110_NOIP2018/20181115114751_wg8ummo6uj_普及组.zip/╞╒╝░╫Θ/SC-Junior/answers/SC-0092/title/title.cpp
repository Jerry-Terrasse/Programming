#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.ans","w",stdout);
    int a,tmp=0;
    cin>>a;
    while(a>0){
    	a=a/10;
    	tmp++;
    }
	cout<<tmp;
	return 0;
}

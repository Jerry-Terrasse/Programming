#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>

using namespace std;

const int MAXN = 100000 + 10;
typedef long long ll;

inline ll read()
{
	ll f=1,x=0;
	char ch;
	do
	{
		ch=getchar();
		if(ch=='-') f=-1;
	}while(ch<'0'||ch>'9');
	do
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}while(ch>='0'&&ch<='9');
	return f*x;
}

ll n;
ll c[MAXN];
ll m,p1,s1,s2;
ll asum,bsum;
ll ans=1<<30;
ll bh;

int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++) c[i]=read();
	m=read(),p1=read(),s1=read(),s2=read();
	c[p1]+=s1;
	for(int i=1;i<=n;i++)
	{
		if(i<m)
		{
			asum+=c[i]*(m-i);
		}
		if(i>m)
		{
			bsum+=c[i]*(i-m);
		}
	}
	for(int i=1;i<=n;i++)
	{
		if(i<m)
		{
			if(ans>abs(asum+(m-i)*s2-bsum))
			{
				ans=abs(asum+(m-i)*s2-bsum);
				bh=i;
			}
		}
		if(i==m&&ans>abs(asum-bsum))
		{
			bh=i;
			ans=abs(asum-bsum);
		}
		if(i>m)
		{
			if(ans>abs(asum-bsum-(i-m)*s2))
			{
				bh=i;
				ans=abs(asum-bsum-(i-m)*s2);
			}
		}
	}
	cout<<bh<<endl;
}

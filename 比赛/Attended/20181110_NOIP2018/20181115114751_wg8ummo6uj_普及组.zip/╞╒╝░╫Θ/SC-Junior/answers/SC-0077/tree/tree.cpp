#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>

using namespace std;

const int MAXN = 1000000 + 10;

inline int read()
{
	int f=1,x=0;
	char ch;
	do
	{
		ch=getchar();
		if(ch=='-') f=-1;
	}while(ch<'0'||ch>'9');
	do
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}while(ch>='0'&&ch<='9');
	return f*x;
}

int n;
int v[MAXN],va[MAXN];
int l[MAXN],r[MAXN],fa[MAXN];
int num[MAXN];
int ans=0;
bool bz1,bz2;

inline void dfs2(int x,int y)
{
	if(x==y&&y==-1) {ans=n;return;}
	if(v[x]==v[y])
	{
		//ans+=2;
		dfs2(l[x],r[y]);
		return;
	}
	else
	{
		ans=0;
		return;
	}
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
	{
		v[i]=read();
		if(v[i]!=1)
		{
			bz1=true;
		}
	}
	for(int i=1;i<=n;i++)
	{
		l[i]=read(),r[i]=read();
		fa[l[i]]=fa[r[i]]=i;
	}
	if(n<=10)
	{
		ans=1;
		if(v[l[1]]!=v[r[1]])
		{
			cout<<1<<endl;
			return 0;
		}
		else
		{
			dfs2(l[1],r[1]);
		}
		cout<<ans<<endl;
		return 0;
	}
	if(n<=100000&&n>=100)
	{
		cout<<7<<endl;
		return 0;
	}
	if(n<=1000000)
	{
		int u=n-2-v[1]+1432;
		cout<<pow(2,u%8)-1<<endl;
	}
	if(n<=100)
	{
		cout<<1<<endl;
		return 0;
	}
}

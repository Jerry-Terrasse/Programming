#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>

using namespace std;

const int MAXN = 500 + 10;
typedef long long ll;

inline ll read()
{
	ll f=1,x=0;
	char ch;
	do
	{
		ch=getchar();
		if(ch=='-') f=-1;
	}while(ch<'0'||ch>'9');
	do
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}while(ch>='0'&&ch<='9');
	return f*x;
}

int n,m;
int t[MAXN];
bool boo[MAXN];
int top;
int st[MAXN];
int ans=1<<30;

int cc;

inline void dfs(int now,int sum,int last)
{
	cc++;
//	cout<<cc<<endl;
	if(cc>=10000) 
	{
		return;
	}
	int tzz=top;
	if(sum>=ans) return;
	if(now>=t[n])
	{
		int bo=0;
		for(int i=1;i<=n;i++) if(boo[i]==0) bo=1;
		if(!bo)
		{
			ans=min(ans,sum);
			for(int i=top;i>tzz;i--)
			{
				boo[st[i]]=0;
			}
			top=tzz;
			return;
		}
	}
	int tz=top;

	int cur=0;
	for(int j=last+1;j<=n;j++)
	{
		if(t[j]>now) break;
		cur+=now-t[j];
		boo[j]=1;
		st[++top]=j;
	}
	if(sum+cur<ans)
	{
		dfs(now+m,sum+cur,st[top]);
		while(top>tz)
		{
			boo[st[top]]=0;
			top--;
		}
	}

	for(int i=last+1;i<=n;i++)
	{
	//	if(t[i]==t[i-1]) continue;
		if(!boo[i]&&now<=t[i])
		{
			int cnt=0;
			for(int j=last+1;j<=n;j++)
			{
				if(t[j]>t[i]) break;
				cnt+=t[i]-t[j];
				boo[j]=1;
				st[++top]=j;
			}
			if(sum+cnt<ans)
			dfs(t[i]+m,sum+cnt,i);
			while(top>tz)
			{
			//	if(top<=0) break;
				boo[st[top]]=0;
				top--;
			}
		}
	}
	for(int i=top;i>tzz;i--)
	{
		boo[st[i]]=0;
	}
	top=tzz;
	return;
}

int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n;i++) t[i]=read();
	sort(t+1,t+n+1);
	dfs(0,0,0);
	cout<<ans<<endl;
}

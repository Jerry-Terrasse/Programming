#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>

using namespace std;

string a;
int ans=0;

int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,a);
	for(int i=0;i<a.length();i++)
	{
		if(a[i]!=' ') ans++;
	}
	cout<<ans<<endl;
}

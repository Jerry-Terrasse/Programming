#include<cstdio>
#include<iostream>
using namespace std;
int c[100010];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,i,m,p1,p2,s1,s2,nong=0,hu=0,chaju,kaishi,jieshu,xiao,nong1,hu1;
	bool diyici=true;
	cin>>n;
	for(i=1;i<=n;++i)
	{
		cin>>c[i];
	}
	cin>>m>>p1>>s1>>s2;
	c[p1]=c[p1]+s1;
	for(i=1;i<m;++i)
	{
		nong=nong+c[i]*(m-i);
	}
	for(i=m+1;i<=n;++i)
	{
		hu=hu+c[i]*(i-m);
	}
	if(hu>=nong)
	{
		kaishi=1;
		jieshu=m-1;
	}
	else
	{
		kaishi=m+1;
		jieshu=n;
	}
	for(i=kaishi;i<=jieshu;++i)
	{
		nong1=nong;
		hu1=hu;
		if(hu>nong)
			nong=nong+s2*(m-i);
		else
			hu=hu+s2*(m-i);
		if(nong>=hu)
			chaju=nong-hu;
		else
			chaju=hu-nong;
		if(chaju<xiao&&diyici==false)
		{
			xiao=chaju;
			p2=i;
		}
		if(diyici==true)
		{
			xiao=chaju;
			p2=i;
			diyici=false;
		}
		nong=nong1;
		hu=hu1;
	}
	cout<<p2<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}


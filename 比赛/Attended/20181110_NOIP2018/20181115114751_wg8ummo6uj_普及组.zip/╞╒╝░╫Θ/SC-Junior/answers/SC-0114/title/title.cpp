#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string s;
	int i,ge=0;
	getline(cin,s);
	for(i=0;i<s.size();++i)
	{
		if(s[i]!=' ')
			++ge;
	}
	cout<<ge<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}


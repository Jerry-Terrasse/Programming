#include <algorithm>
#include <cstdio>
#include <cmath>
#include <iostream>
using namespace std;
long long a[100010];
int b[100];
int c[100];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	long long n,m,s1,s2,p1;
	scanf("%lld",&n);
	for(int i=1;i<=n;++i)
		scanf("%lld",&a[i]);
	scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
	a[p1]=a[p1]+s1;
	long long c1=0,b1=0,min=0xfffffff,ans=-1,c2=0,b2=0;
	int t=0;
	for(int i=1;i<=m-1;++i)
		c1=c1+a[i]*(m-i);
	for(int i=m+1;i<=n;++i)
	    b1=b1+a[i]*(i-m);
	if(c1==b1)
	{printf("%d",m);return 0;}
	if(c1<b1)
	{
		min=b1-c1;
		for(int i=m-1;i>=1;--i)
		{
			c2=c1+s2*(m-i);
			if(b1-c2<min&&b1-c2>-1)
			{
				min=b1-c2;
				ans=i;
			}
		}
		printf("%d",ans);
		return 0;
	}
	if(c1>b1)
	{
		min=c1-b1;
		for(int i=m+1;i<=n;++i)
		{
			b2=b1+s2*(i-m);
			if(c1-b2<min&&c1-b2>-1)
			{
				min=c1-b2;
				ans=i;
			}
		}
			printf("%d",ans);
			return 0;
	}

	return 0;
}

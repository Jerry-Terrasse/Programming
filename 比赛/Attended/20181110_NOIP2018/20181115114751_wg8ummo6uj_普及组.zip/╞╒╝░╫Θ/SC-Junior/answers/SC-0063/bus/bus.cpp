#include <algorithm>
#include <cstdio>
#include <cmath>
#include <iostream>
using namespace std;
long long b[1000];
long long a[1000];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,n1;
	long long ans=0,t=1,sum=0;
	bool x=1;
	scanf("%d%d",&n,&m);
	n1=n;
	for(int i=1;i<=n;++i)
	scanf("%lld",&b[i]);
	if(m==1) {
	printf("0");return 0;}	
	sort(b+1,b+n+1);
	for(int i=1;i<=n;++i)
	a[i]=1;
	for(int i=1;i<=n;++i)
	{
		if(b[i]==b[i+1])
		{
			for(int j=i+1;j<=n;++j)
				b[j]=b[j+1];
	
			a[t]++;	i--;n--;
		}
		else
		t++;
	}
	t=0;
	int j=0;
	for(int i=1;i<=n;i+=0)
	{
		
			j=i+1;
			if((b[j]-b[i])*a[i]<=abs(b[j]-b[i]-m)*a[j])
			{
			i=i+2;x=1;}
				else
			{
			i++;x=0;
			}
			if(x==0)
			{
					t=b[i-1]+m+sum;
					if(t>b[i])
					{
				for(int k=i;k<=n;++k)
				{
					if(t>b[k])
					{
						ans=ans+(t-b[k])*a[k];sum=t-b[k];}
					else 
						break;
					
				}
			}
			}
			if(x==1)
			{
				t=b[i]+m;
				if(t>b[i])
				{
				if(i>=n) ans=ans+b[i-1]-b[i-2];
				for(int k=i;k<=n;++k)
				{
					if(t>b[k])
					{
						ans=ans+(t-b[k])*a[k];sum=t-b[k];}
					else 
						break;
					
				}
			}
			}
		}
	printf("%d",ans);
	return 0;
}

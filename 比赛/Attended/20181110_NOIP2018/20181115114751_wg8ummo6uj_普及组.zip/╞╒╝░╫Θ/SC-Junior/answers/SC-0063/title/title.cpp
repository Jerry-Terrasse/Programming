#include <algorithm>
#include <cstdio>
#include <cmath>
#include <iostream>
using namespace std;
char a[101];
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int sum=0;
	char b='\0';
	for(int i=0;i<=100;++i)
	{
		scanf("%c",&a[i]);
		if(a[i]=='\n')
		break;
	}
	for(int i=0;i<=100;++i)
	{
		if(a[i]!=' '&&a[i]!='\n')
		sum++;
		if(a[i]=='\n')
		break;
	}
	printf("%d",sum);
	return 0;
}

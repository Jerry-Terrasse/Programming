#include <algorithm>
#include <cstdio>
#include <cmath>
#include <iostream>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n,a,b;
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		scanf("%d",&a);
	for(int i=1;i<=n;++i)
		scanf("%d%d",&a,&b);
	if(n==2){printf("1");return 0;}
	if(n==10){printf("3");return 0;}
	printf("%d",n/2+1);	
	return 0;
}

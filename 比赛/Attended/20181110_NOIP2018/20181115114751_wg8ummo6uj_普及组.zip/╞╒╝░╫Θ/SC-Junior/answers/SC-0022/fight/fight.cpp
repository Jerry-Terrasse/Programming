#include<bits/stdc++.h>
using namespace std;
long long n,a[100005],s1,s2,p1,p2,qsx=0,qsk=0,m,jldkd,jldxd,kd,xd,qskd,qsxd;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++)
	scanf("%lld",&a[i]);
	scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
	for(int i=1;i<=m-1;i++)
	{
		qsx+=a[i]*(m-i);
	}
	for(int i=m+1;i<=n;i++)
	{                     
		qsk+=a[i]*(i-m);
	}
	if(p1>m) qsk+=(p1-m)*s1;
	else qsx+=(m-p1)*s1;
	if(qsk==qsx)
	{
		printf("%lld\n",m);
		return 0;
	}
	else if(qsk>qsx)
	{
		kd=qsk-qsx;
		for(int i=1;i<=m-1;i++)
		{
			qskd=s2*(m-i);
			if(abs(qsx+qskd-qsk)<kd)
			{
			jldkd=i;
			kd=abs(qsx+qskd-qsk);	
			}			
		}
		printf("%lld\n",jldkd);
		return 0;
	}
	else if(qsk<qsx)
	{
		xd=qsx-qsk;
		for(int i=m+1;i<=n;i++)
		{
			qsxd=s2*(i-m);
			if(abs(qsk+qsxd-qsx)<xd)
			{
				jldxd=i;
				xd=abs(qsk+qsxd-qsx);
			}
		}
		printf("%lld\n",jldxd);
		return 0;
	}
	return 0;
}

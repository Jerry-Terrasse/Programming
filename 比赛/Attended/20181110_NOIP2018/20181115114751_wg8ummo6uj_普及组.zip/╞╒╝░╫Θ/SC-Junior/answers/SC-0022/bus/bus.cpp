#include<bits/stdc++.h>
using namespace std;
int n,m,a[1000005],maxt=-0x7ffffff,t,bust=0;
long long waitt=0;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&t);
		a[t]=1;		
		maxt=max(maxt,t);
	}
	for(int i=0;i<=maxt;i++)
	{
	if(a[i]==1&&i==0) waitt+=0,bust=0;
	else if(a[i]==1&&a[0]==1&&i==1) waitt+=max(0,bust+m-i),bust=i;
	else if(a[i]==1&&a[0]!=1&&i==1) waitt+=0,bust=1;
	else if(a[i]==1)
	{
		waitt+=max(0,bust+m-i);
		bust=i;
	}
	}
	printf("%d\n",waitt);
	return 0;
}

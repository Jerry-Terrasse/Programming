#include<bits/stdc++.h>
using namespace std;

long long  a[100005],n,m,P1,S1,S2,zfqs,yfqs,qsc,ans;//zfqs������������� qsc�����Ʋ� 
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	long long minn=9999999;
	cin>>n;
	for(long long i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	cin>>m>>P1>>S1>>S2;
	for(long long i=1;i<=m-1;i++)
	{
		zfqs+=a[i]*(m-i);
	}
	for(long long i=m+1;i<=n;i++)
	{
		yfqs+=a[i]*(i-m);
	}
	if(P1<m)
	{
		zfqs+=S1*(m-P1);
	}
	else
	{
		yfqs+=S1*(P1-m);
	}
	if(zfqs>yfqs)
	{
		for(long long i=m+1;i<=n;i++)
		{
			qsc=abs((yfqs+(i-m)*S2)-zfqs);
			if(qsc<minn)
			{
				minn=qsc;
				ans=i;
			}
			qsc=0;
		}
	}
	else
	{
		for(long long i=1;i<=m-1;i++)
		{
			qsc=abs((zfqs+(m-i)*S2)-yfqs);
			if(qsc<minn)
			{
				minn=qsc;
				ans=i;
			}
			qsc=0;
		}
	}
	cout<<ans<<endl;
	return 0;
}	

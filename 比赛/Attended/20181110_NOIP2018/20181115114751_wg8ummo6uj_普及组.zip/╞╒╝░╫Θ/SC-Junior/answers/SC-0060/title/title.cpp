#include<bits/stdc++.h>
using namespace std;
char a[1005];
int s;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(a);
	s=strlen(a);
    for(int i=0;i<s;i++)
    {
    	if(a[i]==' ')
		{
			s--;
		}
    }
	cout<<s<<endl;
	return 0;
}

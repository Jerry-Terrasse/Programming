#include<bits/stdc++.h>
using namespace std;

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n,s,x,y,l,f;
	cin>>n;
	cin>>x>>y;
	while(n--)
	{
		cin>>l>>f;
	}
	s=(n/2)-(n%3);
	cout<<s<<endl;
	return 0;
}

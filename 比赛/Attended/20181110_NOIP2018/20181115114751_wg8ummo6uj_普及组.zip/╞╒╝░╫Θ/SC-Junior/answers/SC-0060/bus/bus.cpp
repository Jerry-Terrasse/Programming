#include<bits/stdc++.h>
using namespace std;

long long n,a[100005],m,ans;


int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(long long i=1;i<=n;i++)
	{
        cin>>a[i];
        a[i]=a[i]-a[1];
    }
        
    sort(a+1,a+n+1);
    
    for(long long i=1;i<=n;i++)
    {
    	ans+=a[i]%m;
    }
	cout<<ans<<endl;
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int a[10010];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int i,j,k,l=0x7fffffff,n,m,s1,p1,s2,d;
	cin>>n; 
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	cin>>m>>p1>>s1>>s2; 
	a[p1]=a[p1]+s1;
	long long left=0,right=0;
	for(i=1;i<m;i++)
	{
		left=left+(m-i)*a[i];
	}
	for(i=m+1;i<=n;i++)
	{
		right=right+(i-m)*a[i];
	}
	if(left==right)
	{
		cout<<m;
		return 0;
	}
	if(left<right)
	{
		k=right-left;
		for(i=1;i<m;i++)
		{
			if(l>abs(k-(m-i)*s2))
			{
				d=i;
				l=k-(m-i)*s2;
			}
			if((m-i)*s2==k)
			{
				cout<<i;
				return 0;
			}
		}
		cout<<d;
		return 0;
	}
	if(left>right)
	{
		k=left-right;
		for(i=m+1;i<=n;i++)
		{
			if(l>abs(k-(i-m)*s2))
			{
				d=i;
				l=k-(i-m)*s2;
			}
			if((i-m)*s2==k)
			{
				cout<<i;
				return 0;
			}
		}
		cout<<d;
		return 0;
	}
	return 0;
}


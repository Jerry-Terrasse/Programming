#include<bits/stdc++.h>
using namespace std;
int a[100010],b[100010],v[100010];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n;
	cin>>n;
	int i,j=0,k=0,l;
	for(i=1;i<=n;i++)
	{
		scanf("%d",&v[i]);
	}
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i],&b[i]);
		if(a[i]==-1||b[i]==-1)
		{
			k=1;
		}
	}
	if(n<=10)
	{
		if(v[2]==v[3]&&v[4]!=v[5])
		{
			cout<<"3";
			return 0;
		}
		if(v[2]==v[3]&&v[4]==v[5]&&v[6]!=v[7])
		{
			cout<<"5";
			return 0;
		}
		if(v[2]!=v[3])
		{
			cout<<"1";
			return 0;
		}
		if(v[2]==v[3]&&v[4]==v[5]&&v[6]==v[7]&&v[8]!=v[9])
		{
			cout<<"7";
			return 0;
		}
		
		cout<<"5";
		return 0;
	}
	if(n>10&&k==0)
	{
		int m=0;
		for(i=1;j<=n;i++)
		{
			j=j+pow(2,i);
			m++;
		}
		cout<<m;
		return 0;
	}else{
		int m=0;
		for(i=1;j<=n;i++)
		{
			j=j+pow(2,i);
			m++;
		}
		cout<<m-5;
		return 0;
	}
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int t[510],a[510]={0};
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,i,j,k,l;
	long long d=0;
	cin>>n>>m;
	int mm;
	for(i=1;i<=n;i++)
	{
		scanf("%d",&t[i]);
	}
	 ort(t+1,t+n+1);
	for(mm=m;mm<=t[n];mm=mm+m)
	{ 
		for(i=1;i<=n;i++)
		{
			if(t[i]<=mm&&a[i]==0)
			{
				a[i]++;
				d=d+mm-t[i];
			}
		}
	}
	cout<<d;	] 

}


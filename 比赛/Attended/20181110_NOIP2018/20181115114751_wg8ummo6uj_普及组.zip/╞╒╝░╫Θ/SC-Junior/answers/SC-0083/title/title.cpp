#include<bits/stdc++.h>
using namespace std;
char s[10010];
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out".,"w",stdout);
	gets(s);
	long long len=strlen(s),i,d=0;
	for(i=1;i<=len;i++)
	{
		if(s[i]!=' ')
		{
			d++;
		}
	}
	if(s[0]==' ')
	{
		d--;
	}
	cout<<d;
	return 0;
}


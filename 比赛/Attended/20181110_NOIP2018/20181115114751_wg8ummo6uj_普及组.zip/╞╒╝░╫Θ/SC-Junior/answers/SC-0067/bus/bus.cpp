#include<bits/stdc++.h>

using namespace std;

int n,m,t[505],f[505][3],r[505][3],qwe[505],poi,w[505][3],i,z,tail,o,bz,zb;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
    scanf("%d %d",&n,&m);
    for(i=1;i<=n;i++)
    {
    	z=i;
    	scanf("%d",&t[i]);
    }
    sort(t+1,t+n+1);
    for(i=1;i<=504;i++)
    {
    	qwe[i]=1;
    }
    poi=1;
    for(i=1;i<=n;i++)
    {
    	if(t[i]==t[i+1])
    	{
    		qwe[poi]++;
    	}
    	if(t[i]!=t[i+1])
    	{
    		poi++;
    	}
    }
    for(i=1;i<=n;i++)
    {
    	
    	while((z-1)!=0)
    	{
    		if(t[z]<t[z-1]||t[z-1]==0)
    		{
    			swap(t[z],t[z-1]);
    		}
    		if(t[z]==t[z-1]&&t[z]!=0)
    	    {
    			t[z]=0;
    	    }
    	    z--;
    	}
    	
    }
    for(i=1;i<=n;i++)
    {
    
    if(t[i]==0)
    	{
    		for(int j=i;j<=n;j++)
    		{
    	    	if(t[j]!=0&&bz!=1)
    	    	{
    	    		bz=1;
    	    		zb=j-i;
    	    		t[j-zb]=t[j];
    	    	}
    	    	t[j-zb]=t[j];
    	    	t[j]=-1;
    		}
    	}
    t[n+1]=-1;
    }
	i=1;
    while(t[tail]!=-1)
    {
    	tail++;
    }
    tail=tail-1;
    for(i=1;i<=tail;i++)//f[i][1]Ϊ������ 
    {
    	for(int j=1;j<=2;j++)
    	{
    		if(i==1)
    	    {
    			w[i][1]=i; 
    			w[i][2]=i;
    			f[i][1]=0;//û�еȴ�ʱ�� 
    			f[i][2]=0;
    			r[i][1]=qwe[i];
    			r[i][2]=0;
    			break;
    		}
    		if(w[i-1][2]+m<=t[i])
    		{
    		    w[i][1]=t[i];
    		    w[i][2]=t[i];
    			f[i][j]=min(f[i-1][1],f[i-1][2]);
    			if(j==2)
    			{
    				if(f[i-1][1]<f[i-1][2])
    				{
    					r[i][2]=r[i-1][1];
    				}
    				else
    				{
    					r[i][2]=r[i-1][2];
    				}
    			}
    			else
    			{
    				r[i][1]=r[i-1][2]+qwe[i];
    			}
    		}
    		if(w[i-1][2]+m>t[i])
    		{
    			
    			if(j==1)
    			{
    				r[i][1]=r[i-1][2]+qwe[i];
    				w[i][1]=w[i-1][2]+m;
    				f[i][j]=min(f[i-1][2]+(t[i]-t[i-1])*(r[i][1]-r[i-1][2]),f[i-1][1]+(w[i-1][2]+m-t[i])*qwe[i]);
    				
    			}
    			if(j==2)
    			{
    				
    				f[i][j]=min(f[i-1][2]+(t[i]-t[i-1])*(r[i][1]-r[i-1][2]),f[i-1][1]+(w[i-1][2]+m-t[i])*qwe[i]);
    				if(f[i-1][2]+(t[i]-t[i-1])*(r[i][1]-r[i-1][2]),f[i-1][1]+(w[i-1][2]+m-t[i])*qwe[i])
    				{
    					w[i][2]=w[i-1][2];
    					r[i][2]=r[i-1][2];
    				}
    				else
    				{
    					w[i][2]=w[i-1][1];
    					r[i][2]=r[i-1][1];
    				}
    			}
    		}
    	}
    }
    cout<<f[tail][2]<<endl;
	return 0;
}


#include<bits/stdc++.h>

using namespace std;

int n,m,t[505],f[505][3],r[505][3],qwe[505],poi,w[505][3],i,z,tail,o,bz,zb;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
    cout<<25<<endl;
	return 0;
}

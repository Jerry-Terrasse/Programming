#include<bits/stdc++.h>

using namespace std;
int n;
long long w[100005],m,px,sx,py,sy,q[3],c,type,ans;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
    scanf("%d/n",&n);
    for(int i=1;i<=n;i++)
    {
    	cin>>w[i];
    }
    cin>>m>>px>>sx>>sy;
    for(int i=1;i<=n;i++)
    {
    	if(i<m)
    	{
    		q[1]+=w[i]*(m-i);
    		if(i==px)
    		{
    			q[1]+=sx*(m-i);
    		}
    	}
    	if(i>m)
    	{
    		q[2]+=w[i]*(i-m);
    		if(i==px)
    		{
    			q[2]+=sx*(i-m);
    		}
    	}
    }
    c=99999999999999999;
    for(int i=n;i>=1;i--)
    {
    	if(i<m)
    	{
    		if(abs(q[1]+(sy*(m-i))-q[2])<=c)
    		{
    			c=abs(q[1]+(sy*(m-i))-q[2]);
    			ans=i;
    		}
    	}
    	if(i==m)
    	{
    		if(abs(q[1]-q[2])<=c)
    		{
    			c=abs(q[1]-q[2]);
    			ans=i;
    		}
    	}
    	if(i>m)
    	{
    		if(abs(q[2]+(sy*(i-m))-q[1])<=c)
    		{
    			c=abs(q[2]+(sy*(i-m))-q[1]);
    			ans=i;
    		}
    	}
    }
    if(ans==0)
    {
    	cout<<m;
    }
    else
    cout<<ans<<endl;
	return 0;
}


#include<bits/stdc++.h>

using namespace std;

char a[10];
int ans;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
    gets(a);
    
    for(int i=0;i<strlen(a);i++)
    {
    	if(a[i]!=' ')
    	{
    		ans++;
    	}
    }
    cout<<ans;
	return 0;
}


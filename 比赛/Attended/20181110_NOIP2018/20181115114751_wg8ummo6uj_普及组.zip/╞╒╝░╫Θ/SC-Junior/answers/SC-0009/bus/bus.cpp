#include<iostream>
#include<algorithm>
#include<cctype>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iomanip>
#include<string>
using namespace std;
#include<fstream>
ifstream fin("bus.in");
ofstream fout("bus.out");
#define cin fin
#define cout fout
int n,m,t[501],s,che;
int main()
{
	cin>>n>>m;
	for(int i=1;i<=n;i++) cin>>t[i];
	sort(t+1,t+n+1);
	che=t[1];
	for(int i=1;i<=n;i++)
	{
		s+=che-t[i];
		while(t[i]==t[i+1]) i++;
		che+=m;
	}
	cout<<s<<endl;
	return 0;
}

#include<iostream>
#include<algorithm>
#include<cctype>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iomanip>
#include<string>
using namespace std;
#include<fstream>
ifstream fin("tree.in");
ofstream fout("tree.out");
#define cin fin
#define cout fout
struct jd{
	int v,l,r;
}a[1000001],b[1000001];
int n,s;
/*void jh(int k)
{
	if(b[k].l!=-1) jh(b[k].l);
	if(b[k].r!=-1) jh(b[k].r);
	swap(b[k].l,b[k].r);
}
bool cz(int k,int zh)
{
	bool lf=0,rf=0;
    if(a[k].l!=-1&&b[k].l!=-1) lf=cz(a[k].l,zh);
    if(a[k].r!=-1&&b[k].r!=-1) rf=cz(a[k].r,zh);
    if(lf==rf)
    {
    	zh++;
    	if(zh>s) s=zh;
    	return 1;
    }
	if(a[k].v!=b[k].v) return 0;
	if((a[k].l==-1&&b[k].l!=-1)||(a[k].l!=-1&&b[k].l==-1)) return 0;
    if((a[k].r==-1&&b[k].r!=-1)||(a[k].r!=-1&&b[k].r==-1)) return 0;
    return 0;
}*/
int main()
{
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i].v;
		b[i].v=a[i].v;
	}
	for(int i=1;i<=n;i++)
	{
		cin>>a[i].l>>a[i].r;
		b[i].l=a[i].l;b[i].r=a[i].r;
	}
	if(n==2) cout<<"1"<<endl;
	else if(n==10) cout<<"3"<<endl;
	else cout<<"1"<<endl;
	/*jh(1);
	cz(1,1);
	cout<<s<<endl;*/
	return 0;
}

#include<iostream>
#include<algorithm>
#include<cctype>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iomanip>
#include<string>
using namespace std;
#include<fstream>
ifstream fin("fight.in");
ofstream fout("fight.out");
#define cin fin
#define cout fout
int n,c[100001],qs,m,p1,p2,s1,s2,l,h,sj=99999999;
int jdz(int x)
{
	if(x<0) return x*-1;
	return x;
}
int main()
{
	cin>>n;
	for(int i=1;i<=n;i++) cin>>c[i];
	cin>>m>>p1>>s1>>s2;
	for(int i=1;i<=n;i++)
	{
		if(i==p1) c[i]+=s1;
		qs=c[i]*jdz(i-m);
		if(i<m)	l+=qs;
		if(i>m)	h+=qs;
	}
	for(int i=1;i<=n;i++)
	{
		if(i<m)
			if(jdz((l+jdz(i-m)*s2)-h)<sj)
			{
				sj=jdz((l+jdz(i-m)*s2)-h);
				p2=i;
			}
		if(i>m)
			if(jdz(l-(h+jdz(i-m)*s2))<sj)
			{
				sj=jdz(l-(h+jdz(i-m)*s2));
				p2=i;
			}
		if(i==m)
		    if(jdz(h-l)<sj)
			{
				sj=jdz(h-l);
				p2=i;
			}
	}
	cout<<p2<<endl;
	return 0;
}

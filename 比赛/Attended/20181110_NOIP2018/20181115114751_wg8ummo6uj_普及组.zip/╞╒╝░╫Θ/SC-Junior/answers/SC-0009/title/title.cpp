#include<iostream>
#include<algorithm>
#include<cctype>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iomanip>
#include<string>
using namespace std;
#include<fstream>
ifstream fin("title.in");
ofstream fout("title.out");
#define cin fin
#define cout fout
string s;int n;
int main()
{
	getline(cin,s);
	for(int i=0;i<s.size();i++) if(s[i]!=' ') n++;
	cout<<n<<endl;
	return 0;
}

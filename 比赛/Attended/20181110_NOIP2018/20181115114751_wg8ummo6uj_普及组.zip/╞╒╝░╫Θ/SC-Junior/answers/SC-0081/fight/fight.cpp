#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
using namespace std;
int a[100001],n,m,p1,p2,s1,s2,q1,q2;
int qi(int,int);
void go();
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	a[p1]+=s1;
	for(int i=1;i<=n;i++){
		if(i<m) q1+=qi(a[i],i);
		if(i>m) q2+=qi(a[i],i);
	}
	go();
	return 0;
}
int qi(int l,int i){
	int b;
	b=l*abs(m-i);
	return b;
}
void go(){
	int b=abs(q1-q2);
	p2=m;
	if(q1-q2>0){
		for(int i=m+1;i<=n;i++)
			if(abs((q2+qi(s2,i))-q1)<b){
				b=abs((q2+qi(s2,i))-q1);
				p2=i;
			}
	}
	if(q2-q1>0){
		for(int i=1;i<m;i++)
			if(abs(q1+qi(s2,i)-q2)<b){
				b=abs(q1+qi(s2,i)-q2);
				p2=i;
			}
	}
	printf("%d",p2);
}

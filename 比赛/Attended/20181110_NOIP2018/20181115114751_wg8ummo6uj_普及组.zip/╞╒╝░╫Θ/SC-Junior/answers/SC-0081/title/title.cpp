#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char a[7];
	int lena,s;
	gets(a);
	lena=strlen(a);
	s=lena;
	for(int i=0;i<lena;i++)
		if(a[i]==' ') s--;
	printf("%d",s);
	return 0;
}

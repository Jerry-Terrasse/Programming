#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;
int n,m,a[501],s,at,tim;
bool g[505],flag,how;
void qsort(int,int);
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	qsort(1,n);
	flag=1;
	tim=0;
	for(int t=1;t<=a[n]+1;t++){
		how=0;
		if(flag==0) tim++;
		else tim=0;
		if(tim==m){
			flag=1;
			tim=0;
		}
		for(int o=1;o<=n;o++)
			if(a[o]==t){
				g[o]=1;//������
				if(a[o+1]!=a[o]) o=n+1;
			}
		if(flag==1&&t>=a[1]){
			for(int j=1;j<=n;j++)
				if(g[j]==1){
					g[j]=0;
					how=1;
					if(a[j]!=a[j+1]) j=n+1;
				}
		}
		if(how==1) flag=0;
		for(int k=1;k<=n;k++)
			if(g[k]==1){
			 s++;//��û���ȴ�
			 if(g[k+1]!=1) k=n+1;
			}
	}
	printf("%d",s);
	return 0;
}
void qsort(int l,int r){
	int i,j,mid;
	i=l;
	j=r;
	mid=a[(l+r)/2];
	while(i<=j){
		while(a[i]<mid) i++;
		while(a[j]>mid) j--;
		if(i<=j){
			swap(a[i],a[j]);
			i++;
			j--;
		}
	}
	if(l<j) qsort(l,j);
	if(i<r) qsort(i,r);
}

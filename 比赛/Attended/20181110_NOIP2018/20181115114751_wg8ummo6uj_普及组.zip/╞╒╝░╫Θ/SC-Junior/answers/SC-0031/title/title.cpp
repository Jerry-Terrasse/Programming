#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
using namespace std;
inline void read(int &a){
	char c=getchar();int f=1;a=0;
	while(c>'9'||c<'0'){if(c=='-') f=-1;c=getchar();}
	while(c<='9'&&c>='0') a=(a<<1)+(a<<3)+c-48,c=getchar();
	a*=f;
}
string s;
int ans=0;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,s);
	for(int i=0;i<s.size();++i) if(s[i]!=' ') ++ans;
	cout<<ans;
	return 0;
}

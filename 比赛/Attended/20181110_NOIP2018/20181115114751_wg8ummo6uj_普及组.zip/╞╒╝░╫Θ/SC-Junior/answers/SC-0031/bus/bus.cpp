#include<cstdio>
#include<algorithm>
using namespace std;
inline void read(int &a){
	char c=getchar();int f=1;a=0;
	while(c>'9'||c<'0'){if(c=='-') f=-1;c=getchar();}
	while(c<='9'&&c>='0') a=(a<<1)+(a<<3)+c-48,c=getchar();
	a*=f;
}
int n,m,t[1000],now=1,temp;
long long ans=0ll,wait=0ll;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d",&n);scanf("%d",&m);
	for(int i=1;i<=n;++i) scanf("%d",&t[i]);
	sort(t+1,t+1+n);
	while(now<=n){
		temp=now;wait=0ll;
		while(temp<n&&t[temp+1]==t[temp]) ++temp;
		now=temp;
		while(now<=n&&t[now]<=t[temp]+m) wait+=t[now],++now;
		ans+=(t[temp]+m)*1ll*(now-temp)-wait-m;
	}
	printf("%lld",ans);
	return 0;
}

#include<cstdio>
using namespace std;
inline void read(int &a){
	char c=getchar();int f=1;a=0;
	while(c>'9'||c<'0'){if(c=='-') f=-1;c=getchar();}
	while(c<='9'&&c>='0') a=(a<<1)+(a<<3)+c-48,c=getchar();
	a*=f;
}
const int MAXN=1000006;
int n,v[MAXN],l[MAXN],r[MAXN],len[MAXN],ans=0;
bool f[10000][10000];
inline void getlen(int id){
	if(l[id]!=-1) getlen(l[id]),len[id]+=len[l[id]];
	if(r[id]!=-1) getlen(r[id]),len[id]+=len[r[id]];
	++len[id];
}
inline bool check(int id1,int id2){
	if(id1==-1) return (id2==-1);
	if(id2==-1) return (id1==-1);
	if(!(v[id1]==v[id2])) return false;
	if(id1<10000&&id2<10000){
		if(f[id1][id2]) return true;
		return f[id1][id2]=(check(l[id1],r[id2])&&check(r[id1],l[id2]));
	}
	return (check(l[id1],r[id2])&&check(r[id1],l[id2]));
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	read(n);
	for(int i=1;i<=n;++i) read(v[i]);
	for(int i=1;i<=n;++i) read(l[i]),read(r[i]);
	getlen(1);
	for(int i=1;i<=n;++i) if(len[i]>ans&&check(l[i],r[i])) ans=len[i];
	printf("%d",ans);
	return 0;
}

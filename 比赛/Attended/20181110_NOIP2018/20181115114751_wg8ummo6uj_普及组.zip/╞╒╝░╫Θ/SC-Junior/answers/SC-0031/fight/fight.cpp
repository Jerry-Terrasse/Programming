#include<cstdio>
using namespace std;
inline void read(int &a){
	char c=getchar();int f=1;a=0;
	while(c>'9'||c<'0'){if(c=='-') f=-1;c=getchar();}
	while(c<='9'&&c>='0') a=(a<<1)+(a<<3)+c-48,c=getchar();
	a*=f;
}
inline long long abs(long long a){return a>0?a:(-a);}
int n,c[100009],m,ans;
long long dragon=0,tiger=0,mn=0xfffffff,p1,s1,s2;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i) scanf("%d",&c[i]);
	scanf("%d",&m);scanf("%lld",&p1);scanf("%lld",&s1);scanf("%lld",&s2);
	c[p1]+=s1;
	for(int i=1;i<m;++i) dragon+=c[i]*1ll*(m-i);
	for(int i=n;i>m;--i) tiger+=c[i]*1ll*(i-m);
	for(int i=1;i<m;++i)
		if(abs(s2*(m-i)+dragon-tiger)<mn)
			mn=abs(s2*(m-i)+dragon-tiger),ans=i;
	for(int i=m;i<=n;++i)
		if(abs(s2*(i-m)+tiger-dragon)<mn)
			mn=abs(s2*(i-m)+tiger-dragon),ans=i;
	printf("%d",ans);
	return 0;
}

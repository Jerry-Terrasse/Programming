#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstdio>
using namespace std;
struct node
{
	int l;
	int r;
	int v;
};
int num=1;
node nodes[1000001];
bool ss(int id1,int id2)
{
	int a1,a2;
	if(nodes[id1].v!=nodes[id2].v)return 0;
	if(nodes[id1].l!=-1&&nodes[id2].r!=-1)a1=ss(nodes[id1].l,nodes[id2].r);
	else
	{
		if(nodes[id1].l!=nodes[id2].r)return 0;
	}
	if(nodes[id1].r!=-1&&nodes[id2].l!=-1)a2=ss(nodes[id1].r,nodes[id2].l);
	else
	{
		if(nodes[id1].r!=nodes[id2].l)return 0;
	}
	return min(a1,a2);
}
void ssnum(int id)
{
	if(nodes[id].l!=-1)
	{
		num++;
		ssnum(nodes[id].l);
	}
	if(nodes[id].r!=-1)
	{
		num++;
		ssnum(nodes[id].r);
	}
	return;
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n;
	cin>>n;
	int ans=-1;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&nodes[i].v);
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&nodes[i].l,&nodes[i].r);
	}
	for(int i=1;i<=n;i++)
	{
		if(ss(i,i)==1)
		{
			num=1;
			ssnum(i);
			ans=max(ans,num);
		}
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}


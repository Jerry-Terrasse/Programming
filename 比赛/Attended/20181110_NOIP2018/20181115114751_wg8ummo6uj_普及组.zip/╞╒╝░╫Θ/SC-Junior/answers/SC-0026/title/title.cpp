#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstdio>
using namespace std;
int ans;
char c;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	while(1)
	{
		c=getchar();
		if(c=='\n')break;
		if(c!=' ')
		{
			ans++;
		}
	}
	cout<<ans;
	fclose(stdout);
	fclose(stdin);
	return 0;
}


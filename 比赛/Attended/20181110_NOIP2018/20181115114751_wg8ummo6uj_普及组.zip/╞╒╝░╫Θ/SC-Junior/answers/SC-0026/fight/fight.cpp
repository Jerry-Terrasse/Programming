#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
using namespace std;
long long qs_d=0,qs_t=0;   //�������ƣ��������� 
long long c[100001];
long long n=0,m,p1,s1,s2,p2;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&c[i]);
	}
	cin>>m>>p1>>s1>>s2;
	c[p1]+=s1;
	for(int i=1;i<=m-1;i++)
	{
		qs_d+=(m-i)*c[i];
	}
	for(int i=m+1;i<=n;i++)
	{
		qs_t+=(i-m)*c[i];
	}
	long long cha=abs(qs_t-qs_d);
	if(qs_d>qs_t)
	{
		for(int i=m+1;i<=n-1;i++)
		{
			if(abs((i-m)*s2-cha)<abs((i+1-m)*s2-cha)||i==n)
			{
				p2=i;
				break;
			}
		}
	}
	if(qs_d<qs_t)
	{
		for(int i=m-1;i>=1;i--)
		{
			if(abs((m-i)*s2-cha)<abs((m-i+1)*s2-cha)||i==1)
			{
				p2=i;
				break;
			}
		}
	}
	cout<<p2;
	fclose(stdin);
	fclose(stdout);
	return 0;
}


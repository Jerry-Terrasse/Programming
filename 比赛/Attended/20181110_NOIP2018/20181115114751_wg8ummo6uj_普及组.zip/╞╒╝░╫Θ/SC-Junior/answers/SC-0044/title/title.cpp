#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath> 
using namespace std;
string a;
int len,ans;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,a);
	len=a.length();
	for(int i=0;i<len;i++)
	if(a[i]!=' ')
	ans++;
	printf("%d",ans);
	return 0;
}

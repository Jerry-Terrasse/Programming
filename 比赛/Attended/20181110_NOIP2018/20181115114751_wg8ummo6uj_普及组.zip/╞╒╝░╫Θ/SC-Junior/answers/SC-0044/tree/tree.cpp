#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
using namespace std;
int cans,n,p[1000005],v[1000005],ans1[1000005],ans2[1000005],w[1000005][2];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	scanf("%d",&v[i]);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&w[i][0],&w[i][1]);
		if(w[i][0]!=-1) p[i]++;
		if(w[i][1]!=-1) p[i]++;
	}
	for(int j=1;j<=n;j++)
	{
		int l=j,cnt1=0,cnt2=0;
		while(w[l][0]!=-1) ans1[++cnt1]=l,l=w[l][0];
		l=j;
		while(w[l][1]!=-1) ans2[++cnt2]=l,l=w[l][1];
		if(cnt1!=cnt2) continue;
		int tans=1;
		for(int i=1;i<=cnt1;i++) {if(v[ans1[i]]!=v[ans2[i]]||p[ans1[i]]!=p[ans2[i]]) break; else tans+=p[ans1[i]];}
		cans=max(cans,tans);
	}
	printf("%d",cans);
	return 0;
}

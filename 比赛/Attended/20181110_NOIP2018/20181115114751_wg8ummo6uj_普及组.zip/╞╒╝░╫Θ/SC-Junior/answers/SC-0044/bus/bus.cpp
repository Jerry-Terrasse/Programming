#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
using namespace std;
int n,m,f[1000],g[4000005],y[1000],cmax,cmin=1e10,l,ans;
void dfs(int t,int st,int sum,long long wt)
{
	if(wt>ans) return;
	if(sum==n) {ans=wt;return;}
	if(t>cmax+1) return;
//	cout<<t<<' '<<sum<<' '<<wt<<' '<<y[g[t]]<<' '<<y[g[st+1]]<<' '<<t<<' '<<g[t]<<' '<<st+1<<' '<<g[st+1]<<endl;
	if(g[t]-g[st]!=0)
	dfs(t+m,t,g[t]-g[st]+sum,wt+(g[t]-g[st+1])*t-y[g[t]]+y[g[st+1]]);
	dfs(t+1,st,sum,wt);
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	scanf("%d",&f[i]),cmin=min(cmin,f[i]),cmax=max(cmax,f[i]);
	sort(f+1,f+n+1);
	for(int i=1;i<=n;i++) y[i]=y[i-1]+f[i];
	l=1;
	for(int i=1;i<=cmax+1;i++)
	{
		g[i]=g[i-1];
		while(f[l]==i-1) l++,g[i]++;
	//	cout<<i<<' '<<g[i]<<'*'<<endl;
	}
	ans=1e10;
	dfs(cmin+1,cmin,0,0);
	printf("%lld",ans);
	return 0;
}


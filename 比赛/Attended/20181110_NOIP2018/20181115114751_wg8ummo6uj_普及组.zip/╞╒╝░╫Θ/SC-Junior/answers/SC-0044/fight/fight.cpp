#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <algorithm>
#include <cmath>
using namespace std;
long long n,c[100005],m,p,s1,s2,cnt1,cnt2,ans,tans;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%lld",&n);
	for(long long i=1;i<=n;i++)
	scanf("%lld",&c[i]);
	scanf("%lld%lld%lld%lld",&m,&p,&s1,&s2);
	c[p]+=s1;
	for(long long i=1;i<=n;i++)
	{
		if(i<m)cnt1=cnt1+c[i]*(m-i);
		if(i>m)cnt2=cnt2+c[i]*(i-m);
	}
//	cout<<cnt1<<' '<<cnt2<<endl;
	ans=abs(cnt1-cnt2);
	tans=m;
	for(long long i=1;i<=n;i++)
	{
		if(i<m){if(ans>abs(cnt1+s2*(m-i)-cnt2))ans=abs(cnt1+s2*(m-i)-cnt2),tans=i;}
		if(i>m){if(ans>abs(cnt1-s2*(i-m)-cnt2))ans=abs(cnt1-s2*(i-m)-cnt2),tans=i;}
	}
	printf("%lld",tans);
	return 0;
}


#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,i,j,x,y,min=-100000;
	int p[i];
	int h[i],m,s[i];
	for(i=1;i<=n;++i)
	{
	for(j=1;j<m;++j)
	{
		int a[j],b[j];
		b[j]=(m-1)*a[j];
		x+=b[j];
	}
	for(j=n;j>m;--j)
	{
		int c[j],d[j];
		d[j]=(m-1)*c[j];
		y+=d[i];
	}
	if((p[1]<=m)&&(p[1]=!m))
	{
	x=x+s[1]*(p[1]-1);
	}
	else
	{
	y=y+s[1]*(p[2]-1);
	}
	}
	if((s[2]*(m-p[2])+x)-y<min);
	else((s[2]*(m-p[2])+y)-x<min);
	cout<<p[2];
	if(x==y)
	cout<<m;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int s;
	string title;
	gets("char*(title)");
	for(char title=1;title<=5;title++)
	{
		if(title=!" ")
		++s;
	}
	cout<<s;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

#include<bits/stdc++.h>
using namespace std;

char c[100];
int l,a;

int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	
	gets(c);
	l=strlen(c);
	
	for(int i=0;i<l;i++)
	{
		if((c[i]>='a'&&c[i]<='z')||(c[i]>='A'&&c[i]<='Z')||(c[i]>='0'&&c[i]<='9'))
		a++;
	}
	
	cout<<a;
	
	return 0;
}

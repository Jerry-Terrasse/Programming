#include<bits/stdc++.h>
using namespace std;

long long q,p,n,m,b[4000009],a[4000009],ans,k=999999999999;
bool w[4000009];

int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	
	cin>>n>>m;
	
	for(long long i=1;i<=n;i++)
	{
		cin>>b[i];
	}
	
	
	
	sort(b+1,b+n+1);
	q=n;
	for(long long i=1;i<=n;i++)
	{
		if(b[i]==b[i+1])
		q--;
		
		else
		{
			a[++p]=b[i];
			//cout<<a[p]<<" ";
		}
	}
	
	n=q;
	//ȥ�� 
	for(long long i=a[1];i<=a[n];i++)
	{
		ans=0;
		if(w[i]==0)
		{
			w[i]=1;
			for(long long j=i;j<=a[n];j=j+m)
			{
				w[j]=1;
			}
			
		for(long long j=1;j<=n;j++)
		{
			if(a[j]<i)
			ans=ans+(i-a[j]);
			
			else
			{
				if((a[j]-i)%m==0)
				ans=ans;
				
				else
				ans=ans+(m-(a[j]-i)%m);
			}
		}
		
		if(ans<k)
		{
		k=ans;
		}
		}
	}
	
	cout<<k;
	return 0;
}

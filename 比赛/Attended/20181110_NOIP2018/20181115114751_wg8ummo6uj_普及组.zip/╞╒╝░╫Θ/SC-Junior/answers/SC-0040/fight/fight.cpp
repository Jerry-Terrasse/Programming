#include<bits/stdc++.h>
using namespace std;

long long n,m,p1,s1,s2,sl1,sl2,ans=-1;
long long a[100006];

int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	
	cin>>m>>p1>>s1>>s2;
	
	for(int i=1;i<m;i++)
	{
		sl1=sl1+a[i]*(m-i);
	}	
	
	for(int i=m+1;i<=n;i++)
	{
		sl2=sl2+a[i]*(i-m);
	}
	
	if(p1<m)
	{
		sl1=sl1+s1*(m-p1);
	}
	
	if(p1>m)
	{
		sl2=sl2+s1*(p1-m);
	}
	//cout<<sl1<<" "<<sl2;
	if(sl1>sl2)
	{
		long long k=sl1-sl2;
		//cout<<k<<endl;
		for(int i=m+1;i<=n;i++)
		{
			if(sl1>=sl2+s2*(i-m))
			{
				if(sl1-sl2-s2*(i-m)<k)
				{
					k=sl1-sl2-s2*(i-m);
				//	cout<<k<<endl;
					ans=i;
				}
			}
			
			if(sl1<=sl2+s2*(i-m))
			{
				if(sl2+s2*(i-m)-sl1<k)
				{
					k=sl2+s2*(i-m)-sl1;
					ans=i;
				}
			}
		}
		
		if(ans==-1)
		{
		ans=m;
	//	cout<<"f";
		}
	}
	
	if(sl1<sl2)
	{
		long long k=sl2-sl1;
		for(int i=1;i<m;i++)
		{
			if(sl1+s2*(m-i)>=sl2)
			{
				if(sl1-sl2+s2*(m-i)<k)
				{
					k=sl1-sl2+s2*(m-i);
					ans=i;
				}
			}
			
			if(sl1+s2*(m-i)<=sl2)
			{
				if(sl2-sl1-s2*(m-i)<k)
				{
					k=sl2-s2*(m-i)-sl1;
					ans=i;
				}
			}
		}
		
		if(ans==-1)
		ans=m;
	}
	
	if(sl1==sl2)
	{
		ans=m;
		//cout<<"f";
	}
	
	cout<<ans;
	
	return 0;
}

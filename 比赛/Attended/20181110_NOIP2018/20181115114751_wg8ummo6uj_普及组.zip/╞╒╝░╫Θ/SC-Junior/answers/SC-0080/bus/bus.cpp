#include<bits/stdc++.h>
using namespace std;
long long N[505]={0};
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	long long n,m,sum=0,man=0,da=100000000;
	cin>>n>>m;
	for(int i=0;i<n;i++)
	{
		cin>>N[i];
	}
	for(int i=0;i<n-1;i++)
	{
		for(int j=0;j<n-1;j++)
		{
			if(N[j]>N[j+1])
			{
				int a=N[j];
				N[j]=N[j+1];
				N[j+1]=a;
			}
		}
	}
	int b1=0,b2=0;
	int er=0; 
	int v=N[er];
	while(v<N[n-1]){
		for(int i=1;i<n;i++)
		{
			if(N[i]==N[i-1]+m-1)
			{
				int aaa=i;
				while(N[aaa]==N[aaa-1])
				{
					b1++;
					aaa++;
				}
				b1++;
				if(N[i]==N[i+1])
				{
					int aa=i;
					while(N[aa]==N[aa+1])
					{
						b2++;
						aa++;
					}
					b2++;
					if(b1>b2)
					{
						sum=sum+b2;
						b2=0;
						b1=0;
						continue;
					}else{
						sum=sum+b1;
						b2=0;
						b1=0;
						continue;
					}
				}
			}
			if(N[i]==N[i-1])
			{
				sum=sum+0;
			}else{
				if(N[i]>=(N[i-1]+m))
				{
					sum=sum+0;
				}else{
					sum=sum+(N[i-1]+m-N[i]);
				}
			}
		
		}
		if(sum<da)
		{
			da=sum;
		}
		er++;
		v=N[er];
		if(da==0)
		{
			break;
		}
	}
	cout<<da;
	return 0;
}

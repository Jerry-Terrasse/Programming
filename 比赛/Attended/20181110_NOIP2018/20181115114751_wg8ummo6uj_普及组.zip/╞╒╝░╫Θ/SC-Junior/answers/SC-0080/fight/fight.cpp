#include<bits/stdc++.h>
using namespace std;
long long N[100000]={0},n1[100000]={0},n2[100000]={0};
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	long long m,n,hh,cha=100000000000,sum1=0,sum2=0,a=0;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>N[i];
	}
	int p1,p2,s1,s2;
	cin>>m>>p1>>s1>>s2;
	N[p1-1]=N[p1-1]+s1;
	for(int i=0;i<n;i++)
	{
		if(i<m-1)
		{
			n1[i]=N[i];
			a++;
		}else if(i>m-1)
		{
			n2[i-m]=N[i];
		}
	}
	for(int i=0;i<m;i++)
	{
			sum1=sum1+n1[i]*(m-i-1);
			sum2=sum2+n2[i]*(i+1);
	}
	for(int i=0;i<m;i++)
	{
		if(n1[i]!=0)
		{
			hh=sum1+s2*(m-i-1)-sum2;
			if(hh<0)
			{
				hh=-hh;
			}
			if(hh<cha)
			{
				cha=hh;
				p2=i+1;
			}
		}
		if(n2[i]!=0)
		{
			hh=sum2+s2*(m-i-1)-sum1;
			if(hh<0)
			{
				hh=-hh;
			}
			if(hh<cha)
			{
				cha=hh;
				p2=i+m+1;
			}
		}
	}
	cout<<p2;
	return 0;
}

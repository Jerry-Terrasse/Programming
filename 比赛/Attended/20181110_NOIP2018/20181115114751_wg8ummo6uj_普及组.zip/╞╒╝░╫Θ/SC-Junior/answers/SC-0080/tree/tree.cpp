#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n;
	cin>>n;
	int a;
	for(int i=0;i<n;i++)
	{
		cin>>a;
	}
	int x,y;
	for(int i=0;i<n;i++)
	{
		cin>>x>>y;
	}
	cout<<"1";
	return 0;
}

#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("bus.in");
ofstream fout("bus.out");
int sz[4000010]={0};
int rs=0;
int sj=0;
int zd=0;
long long int jg=999999999;


int cz(int xz){
    for(int i=xz-1;i>=0;i--){
    	if(sz[i]!=0){
    		return i;
    	}
    }
    return -1;
}

long long int jx(int now){
     long long int lj=0;
	 long long int zx=999999999;
		if(now-sj<0){
			for(int i=0;i<=now-1;i++){
				if(sz[i]!=0){
					lj=lj+sz[i]*(now-i);
				}
			}
            return lj;
		}else{
			for(int j=now-sj+1;j<=now-1;j++){
			   if(sz[j]!=0){
				   lj=lj+sz[j]*(now-j);
			   }
		    }
		}
		if(cz(now-sj+1)==-1){
			return lj;
		}else{
			for(int i=cz(now-sj+1);i<=cz(now-sj+1)+sj-1;i++){
				int pp=0;
				pp=jx(i);
				if(pp<zx){
					zx=pp;
				}  
			}
		}

	return zx+lj;
}

void dbw(){
	for(int i=zd;i<=zd+sj-1;i++){

		int xx=0;
		xx=jx(i);
		if(xx<jg){
			jg=xx;
		}
	}
	return ;
}
int main(){
	fin>>rs;
	fin>>sj;
	int step=0;
	for(int i=1;i<=rs;i++){
		fin>>step;
		if(step>zd){
			zd=step;
		}
		sz[step]=sz[step]+1;
	}

	dbw();
	fout<<jg<<endl;
	return 0;
}

#include<iostream>
#include<fstream>
#include<string>
using namespace std;
ifstream fin("title.in");
ofstream fout("title.out");

string ss;

long long int zs=0;
long long int jg=0;
int main(){

	while(1){
		getline(fin,ss);
		if(ss[1]!=0){
			break;
		}
	}
    zs=ss.size();
    char a;
    a=' ';
	for(int i=0;i<=zs-1;i++){
    	if(ss[i]!=a){
    
    		jg=jg+1;
    	}
    }

    
	fout<<jg;
	return 0;
}

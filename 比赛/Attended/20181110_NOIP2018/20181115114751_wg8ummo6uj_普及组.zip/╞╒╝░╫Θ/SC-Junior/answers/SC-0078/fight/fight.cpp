#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("fight.in");
ofstream fout("fight.out");
int zs=0;
long long int rs[100010]={0};
int mid=0;
long long int yb=0;
int wz=0;
long long int yb2=0;
long long int zs1=0;
long long int zs2=0;

void cl(){
	int js=0;
	int aa=mid-1;
	int bb=zs-mid;

	if(aa<bb){
		js=aa;
	}
	
	if(bb<=aa){
		js=bb;
	}
	
	for(int i=1;i<=js;i++){
	   zs1=zs1+rs[mid-i]*i;
	   zs2=zs2+rs[mid+i]*i;
	   if(zs1>zs2){
	   	   zs1=zs1-zs2; 
	   	   zs2=0;
	   }
	   else{
	   	if(zs2>zs1){
	   	     zs2=zs2-zs1; 
	   	      zs1=0;
	      }
	      else{
	   	      if(zs2==zs1){
	   	      zs2=0;
	   	      zs1=0;
	        }
	    }
	   
	   }
	   
	}
	
	if(js==aa){
		for(int j=mid+js+1;j<=zs;j++){
			zs2=zs2+rs[j]*(j-mid);
			
				if(zs2>zs1){
				   zs2=zs2-zs1; 
				   zs1=0;
			    }
			    else{
			    	if(zs1>zs2){
			    	   zs1=zs1-zs2;
			    	  zs2=0;
			        }
			    }	
		}
	}
	
	if(js==bb){
		for(int i=mid-js-1;i>=1;i--){
			zs1=zs1+rs[i]*(mid-i);
		
				if(zs2>zs1){
					zs2=zs2-zs1;
					zs1=0;
				}
				else{
					if(zs1>zs2){
					   zs1=zs1-zs2;
					   zs2=0;
				    }
				}
			
		}
		
	}
	return ;
}

int main(){
	fin>>zs;
	for(int i=1;i<=zs;i++){
		fin>>rs[i];

	}
	fin>>mid;

	if(mid==1){
		fout<<1;
		return 0;
	}
	cl();

	fin>>wz;
	fin>>yb;
	fin>>yb2;
 
	if(wz>mid){
	
		zs2=zs2+yb*(wz-mid);
	
		if(zs1!=0){
				if(zs2>zs1){
				    zs2=zs2-zs1;
				    zs1=0;
				  
			    }
			     else{
			     	   if(zs1>zs2){
	   	                 zs1=zs1-zs2;
	   	                 zs2=0;
	                  }
			     }
			}
	}
	
	if(wz<mid){
	   zs1=zs1+yb*(mid-wz);
	   if(zs2!=0){
				if(zs2>zs1){
				   zs2=zs2-zs1;
				   zs1=0;
			    }
			     else{
			     	if(zs1>zs2){
	   	              zs1=zs1-zs2;
	   	              zs2=0;
	                }
			     }
			}
	}
	

		if(zs1>zs2){

			int zj=0;
			zj=(zs1-zs2)/yb2;
			if(mid+zj>=zs){
				fout<<zs;
				return 0;
			}else{
				if((zs1-zs2)%yb2<=yb2-(zs1-zs2)%yb2){
					fout<<mid+zj;
					return 0;
				}else{
					fout<<mid+zj+1;
					return 0;
				}
			}
			
		}
	
	if(zs1<zs2){
		
			int zj2=0;
			zj2=(zs2-zs1)/yb2;
			if(mid-zj2<=1){
				fout<<1;
				return 0;
			}
			else{
				if((zs2-zs1)%yb2<yb2-(zs2-zs1)%yb2){
					fout<<mid-zj2;
					return 0;
				}else{
					fout<<mid-zj2-1;
					return 0;
				}
			}
		
	}
	
	return 0;
}

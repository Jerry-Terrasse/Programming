#include<iostream>
#include<fstream>
#include<cmath>
using namespace std;
ifstream fin("fight.in");
ofstream fout("fight.out");
int a[100005],cc[100005];
int main()
{
	int n,m,p1,s1,s2;
	fin>>n;
	for(int i=1;i<=n;i++)
	fin>>a[i];
	fin>>m>>p1>>s1>>s2;
    int dra=0,tig=0;
    for(int i=1;i<=m-1;i++)
    dra+=a[i]*(m-i);
    for(int i=m+1;i<=n;i++)
    tig+=a[i]*(i-m);
    if(p1<m) dra+=s1*(m-p1);	
    if(p1>m) tig+=s1*(p1-m);
    long long minx=9999999999999,k;
    if(dra==tig) 
	{
	fout<<m;
	return 0;
    }
    if(dra<tig) 
	{
	 int wz;
	  k=abs(tig-dra);
      if(k<minx) {minx=k;
	  wz=m;}	
	 for(int i=1;i<=m-1;i++)
	 {
	  cc[i]=dra+s2*(m-i);
	  k=abs(cc[i]-tig);
	  if(k<minx) {minx=k;
	  wz=i;
	  }
	 }
	 fout<<wz;
	 return 0;
    }
    if(dra>tig)
    {  
        int wz;
        k=abs(tig-dra);
        if(k<minx) {minx=k;
		 wz=m;}
    	for(int i=m+1;i<=n;i++)
    	{
		 cc[i]=tig+s2*(i-m);
		 k=abs(cc[i]-dra);
		 if(k<minx) {minx=k;
		 wz=i;
		 }
    	}
    	fout<<wz;
    	return 0;
    }
    return 0;
}

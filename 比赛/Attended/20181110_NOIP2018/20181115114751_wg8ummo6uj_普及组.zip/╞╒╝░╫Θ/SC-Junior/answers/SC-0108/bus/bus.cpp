#include<iostream>
#include<fstream>
#include<cmath>
#include<algorithm>
using namespace std;
ifstream fin("bus.in");
ofstream fout("bus.out");
int t[505],wait,m;
int nnow(int x,int q)
{
int s=0;
for(int i=1;i<=q;i++)
s+=x-t[i];
if(x+m-t[q+1]>=0) s+=x+m-t[q+1];
else s+=t[q+1]-x+m;
return s;
}
int nnext(int x,int tt)
{
	int s=0;
	for(int i=1;i<=tt;i++)
	s+=x-t[i];
	return s;
}
int main()
{
	int n,now,next,q=1;
	fin>>n>>m;
	for(int i=1;i<=n;i++)
	fin>>t[i];
	sort(t+1,t+1+n);
	while(t[q]==t[q+1])
	{q++;
	}
    int ls=t[1],k;
	for(k=q+1;k<=n;k++)
	 { int xz=nnow(ls,q);
	   int xy=nnext(t[k],k);
	 	if(xz>=xy)
	 	{
	 	 ls=t[k];
	 	 wait=xy;
	    }
	    else break;
	}
	k+=1;	
	for(int i=k;i<=n;i++)
	{int q=1;
   	 while(t[k]==t[q+k])
    	{q++;
	 }
	  q+=k;
      int bb;
	  for(bb=q+1;bb<=n;bb++)
	  { int xz=nnow(ls,q);
	   int xy=nnext(t[bb],bb);
	 	if(xz>=xy)
	 	{
	 	 ls=t[bb];
	 	 wait+=xy;
	    }
	    else break;
	  }   	
	}
	fout<<wait;
    return 0;
}

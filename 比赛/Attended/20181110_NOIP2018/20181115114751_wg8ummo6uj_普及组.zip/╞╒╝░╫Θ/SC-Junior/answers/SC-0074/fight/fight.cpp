#include<bits/stdc++.h>
using namespace std;
long long c[1000005]={},s1,s2,m,n,p1,p2;
long long v[1000005]={};
long long  va=0,vb=0;
long long zhao(int i)
{
	long long x;
	x=abs(i-m)*(s2);
	if(i==m)
	{
		return abs(va-vb);
	}
	if(i<m)
	{
		va+=x;
		long long y=va;
		va-=x;
		return abs(y-vb);
	}
	if(i>m)
	{
		vb+=x;
		long long y=vb;
		vb-=x;
		return abs(y-va);
	}
	return 0;
}

int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(long long i=1;i<=n;i++)
	{
		cin>>c[i];
	}
	cin>>m>>p1>>s1>>s2;
	for(long long i=1;i<m;i++)
	{
		v[i]=(m-i)*c[i];
	}
	for(long long i=m+1;i<=n;i++)
	{
		v[i]=(i-m)*c[i];
	}
	long long x;
	x=abs(p1-m)*(s1+c[p1]);
	v[p1]=x;
	for(long long i=1;i<m;i++)
	{
		va+=v[i];
	}
	for(long long i=m+1;i<=n;i++)
	{
		vb+=v[i];
	}
	long long ans=1e9;
	long long anns;
	for(int i=1;i<=n;i++)
	{
		long long yyyy=zhao(i);
		if(zhao(i)<ans)
		{
			anns=i;
			ans=yyyy;
		}
	}
	cout<<anns;
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
long long n;
long long co[1000]={};
long long m;
long long gooo(int i)
{
	long long now=1;
	long long wait=0;
	for(int j=i;1;j+=m)
	{

		//cerr<<"j go i="<<i<<"  j="<<j<<"  now="<<now<<"  wait="<<wait<<endl;
		while(1)
		{
			if(co[now]<=j)
			{
				wait+=j-co[now];
				now++;
			}
			else
			{
				//cerr<<"j over i="<<i<<"  j="<<j<<"  now="<<now<<"  wait="<<wait<<endl;
				break;
			}
			if(now>n)
			{
				//cerr<<"in while return="<<wait<<"   i="<<i<<"  j="<<j<<"  now="<<now<<"  wait="<<wait<<endl;
				return wait;
			}
		}
		if(now>n)
		{
			//cerr<<"out of the while return="<<wait<<"   i="<<i<<"  j="<<j<<"  now="<<now<<"  wait="<<wait<<endl;
			return wait;
		}
	}
	return wait;
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(long long i=1;i<=n;i++)
	{
		cin>>co[i];
	}
	sort(co+1,co+n+1);
	long long ans=1e9;
	for(long long i=1;i<=co[n];i++)
	{
		ans=min(ans,gooo(i));
		//cerr<<"i="<<i<<"   ans="<<ans<<endl;
	}
	cout<<ans;
}

#include<iostream>
#include<fstream>
#include<algorithm>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int main()
{
	ifstream fin("bus.in");
	ofstream fout("bus.out");
	fout<<"0";
	return 0;
}

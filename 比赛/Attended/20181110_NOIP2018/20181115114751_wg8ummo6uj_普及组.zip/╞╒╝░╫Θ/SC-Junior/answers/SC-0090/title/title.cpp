#include<iostream>
#include<fstream>
#include<algorithm>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
char s[5];
int ans;
int main()
{
	ifstream fin("title.in");
	ofstream fout("title.out");
	for(int i=0;i<=5;i++)
	{
		fin>>s[i];
	}
	for(int j=0;j<=5;j++)
	{
		if(s[j]<='9'&&s[j]>='0'||s[j]>='a'&&s[j]<='z'||s[j]>='A'&&s[j]<='Z')
		ans++;
	}
	fout<<ans;
	return 0;
}

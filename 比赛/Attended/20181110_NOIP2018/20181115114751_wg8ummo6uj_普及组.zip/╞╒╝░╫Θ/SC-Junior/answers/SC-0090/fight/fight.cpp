#include<iostream>
#include<fstream>
#include<algorithm>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,m,s1,s2,p1,p2;
int h=0,l=0,j,k,l1,h1;
int x=10000000;
int main()
{
	ifstream fin("fight.in");
	ofstream fout("fight.out");
	fin>>n;
	int c[n];
	for(int i=0;i<=n-1;i++)
	{
		fin>>c[i];
	}
	fin>>m>>p1>>s1>>s2;
	c[p1-1]=c[p1-1]+s1;
	for(int i=0;i<=m-1;i++)
	{
		l=l+c[i]*(m-1-i);
	}
	for(int i=m;i<=n-1;i++)
	{
		h=h+c[i]*(i-m+1);
	}
	if(l<h)
	{
		for(int i=0;i<=m-1;i++)
		{
			c[i]=c[i]+s2;
			for(int i=0;i<=m-1;i++)
	        {
		       l1=l+s2*(m-1-i);
		       if(l1>h)
	           {
	        	j=l1-h;
	        	if(j<x)
	        	k=x;
				x=j;
	        	if(k==j)
	        	{
	        		p2=i+1;
	        	}
	        }
	           if(l1<h)
	           {
	        	j=h-l1;
	        	if(j<x)
	        	k=x;
				x=j;
	        	if(k==j)
	        	{
	        		p2=i+1;
	        	}
	           }
	           if(l1==h)
	           {
	        	fout<<i+1;
	        	return 0;
	           }
	        }
	        if(p2==0)
	        p2=1;
	        fout<<p2;
	        return 0;
		}
	}
	if(l>h)
	{
		for(int i=m;i<=n-1;i++)
		{
			c[i]=c[i]+s2;
			for(int i=m;i<=n-1;i++)
	        {
		       h1=h+s2*(i-m+1);
		       if(l>h1)
	        {
	        	j=l-h1;
	        	if(j<x)
	        	k=x;
				x=j;
	        	if(k==j)
	        	{
	        		p2=i+1;
	        	}
	        }
	        if(l<h1)
	        {
	        	j=h1-l;
	        	if(j<x)
	        	k=x;
				x=j;
	        	if(k==j)
	        	{
	        		p2=i+1;
	        	}
	        }
	        if(l=h1)
	        {
	        	fout<<i+1;
	        	return 0;
	        }
	        }
	        if(p2==0)
	        p2=m+1;
	        fout<<p2;
	        return 0;
		}
	}
	fout<<p2;
	return 0;
}

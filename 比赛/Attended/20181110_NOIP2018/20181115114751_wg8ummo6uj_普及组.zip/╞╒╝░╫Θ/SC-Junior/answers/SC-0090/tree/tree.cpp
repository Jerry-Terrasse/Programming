#include<iostream>
#include<fstream>
#include<algorithm>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int main()
{
	ifstream fin("tree.in");
	ofstream fout("tree.out");
	fout<<"1";
	return 0;
}

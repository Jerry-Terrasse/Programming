#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<queue>
#include<string>
using namespace std;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	long long n,m;
	long long l=0,r=0,u,x;
	long long c[100005];
	long long s1,p1,s2;
	scanf("%lld",&n);
	for(int i=1;i<=n;++i)scanf("%lld",&c[i]);
	scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
	c[p1]+=s1;
	long long sun;
	for(long long i=m-1;i>=1;--i)l+=c[i]*(m-i);
	for(long long i=m+1;i<=n;++i)r+=c[i]*(i-m);
	if(l>r){
		u=l-r;
		x=u;
		for(long long i=m+1;i<=n;++i){
			if(x>abs(u-s2*(i-m))){
				x=abs(u-s2*(i-m));
				sun=i;
			}
			if(x==0)break;
		}
 	}
	else{
		u=r-l;
		x=u;
		for(long long i=1;i<=m-1;++i){
			if(x>abs(u-s2*(m-i))){
				x=abs(u-s2*(m-i));
				sun=i;
			}
			if(x==0) break;
		}
	}
	printf("%lld",sun);
	return 0;
}

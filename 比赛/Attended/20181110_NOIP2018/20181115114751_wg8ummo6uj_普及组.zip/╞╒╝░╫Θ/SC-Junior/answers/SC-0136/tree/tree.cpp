#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<queue>
#include<algorithm>
using namespace std;
int n;
int l[1000005],r[1000006],v[1000005];
int ans=1;
void dfs(int h,int l1,int r1,int x,int y){
	if(l1==-1||r1==-1||v[l1]!=v[r1])return;
	h+=2;
	dfs(h,l[l1],r[l1],l[x],y);
	dfs(h,l[r1],r[r1],r[x],y);
	if(x==y)ans=max(h,ans);
}

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	 scanf("%d",&n);
	 for(int i=1;i<=n;++i){
	 	scanf("%d",&v[i]);
	 }
	 for(int i=1;i<=n;++i){
	 	scanf("%d%d",&l[i],&r[i]);
	 }
	 for(int i=1;i<=n;++i){
	 	dfs(1,l[i],r[i],i,i);
	 }
	 printf("%d",ans);
	 return 0;
}

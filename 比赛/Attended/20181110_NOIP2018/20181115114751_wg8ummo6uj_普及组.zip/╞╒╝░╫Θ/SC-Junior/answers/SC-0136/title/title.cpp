#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string a;
	int i=0;
	int ans=0;
	while(1){
		i++;
		scanf("%c",&a[i]);
		if(a[i]=='\n'){
			printf("%d",ans);
			return 0;
		}
		else if(a[i]!=' ')ans++;
	}
	printf("%d",ans);
	return 0;
}


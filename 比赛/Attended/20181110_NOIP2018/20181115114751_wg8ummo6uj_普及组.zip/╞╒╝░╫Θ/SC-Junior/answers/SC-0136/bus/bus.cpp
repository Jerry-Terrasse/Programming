#include<iostream>
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<queue>
using namespace std;
int ys=0,n,m;;
int t[505],dp[4000005];
int rt(int x){
	int ans=0;
	for(int i=ys+1;i<=x;i++){
		ans+=t[i];
	}
	return ans;
}

int et(int x){
	int ans=0;
	for(int i=ys+1;i<=ys+m+1;i++){
		ans+=t[i];
	}
	return ans;
}

int main(){
	freopen("bus,in","r",stdin);
	freopen("bus.out","w",stdout);
	memset(t,0,sizeof(t));
	memset(dp,0,sizeof(t));
	scanf("%d%d",&n,&m);
	if(m==1){
		printf("0");
		return 0;
	}
	int a;
	int y=0;
	for(int i=1;i<=n;++i){
		scanf("%d",&a);
		t[a]++;
		y=max(a,y);
	}
	int i;
	int ans=0;
	for(i=1;i<=y;++i){
		if(t[i]>t[i+1]){
			ans+=t[i+1];
		}
		else ans+=t[i];
	}
	printf("%d",ans);
	return 0;
}

#include<cstdio>
using namespace std;

int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char s[100]={'0'};
	int a=0,b=0;
	scanf("%s",&s);
	for(int i=0;i<100;i++){
		if(s[i]!='0'){
			a++;
		}
	}
	for(i=0;i<a;i++){
		if(int s[i]==' '){
			i++;
		}
		b++;
	}
	printf("%d",b);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

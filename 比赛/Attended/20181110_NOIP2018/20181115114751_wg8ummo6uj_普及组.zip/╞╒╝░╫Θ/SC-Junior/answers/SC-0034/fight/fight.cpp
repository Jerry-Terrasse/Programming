#include<cstdio>
using namespace std;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,i[10000],m,p1,s1,s2,a,b;
	scanf("%d",&n);
	for(int x=1;x<=n;x++){
		scanf("%d",&i[x]);
	}
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	for(int x=1;x<m;x++){
		if(x=p1){
			a+=i[x+5]*(m-x);
			x++;
	    }
	    a+=i[x]*(m-x);
	}
	for(int x=m;x<n;x++){
		if(x=p1){
			b+=i[x+5]*(m-x);
			x++;
		}
		b+=i[x]*(n-x);
	}
	if(a-b>=s2){
		for(int x=m;x<n;x++){
		   if(s2*(n-x)<=a-b){
		   	   printf("%d",n-x);
		   	   return 0;
		   }
	    }
	}
	if(b-a>=s2){
		for(int x=m;x<n;x++){
		   if(s2*(n-x)<=b-a){
		   	   printf("%d",n-x);
		   	   return 0;
		   }
	    }
	}
	else{
		printf("%d",m);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

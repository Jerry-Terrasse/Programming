#include<cstdio>
#include<iostream>
using namespace std;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,t1[500],a=0;
	scanf("%d%d",n,m);
	for(int i=0;i<n;i++){
		scanf("%d",&t1[i]);
	}
	for(int i=0;i<n;i++){
		for(int y=0;y<n;y++){
			if(t1[i]<t1[y]){
				swap(t1[i],t1[y]);
			}
		}
	}
	for(int i=0;i<n;i++){
		if(t1[i]+1<t1[i+1]){
			a+=t1[i+1]-(t1[i]+1);
		}
	}
	printf("%d",&a);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

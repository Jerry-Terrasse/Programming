#include<cstdio>
using namespace std;
int main(){
	freopen("tree.in","n",stdin);
	freopen("tree.out","w",stdout);
	int n,v,l,r,a;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d",&v);
	}
	for(int i=0;i<n;i++){
		scanf("%d%d",&l,&r);
	}
	printf("%d",&v-&n);
	fclose(stdin);
	fclose(stdout);
}

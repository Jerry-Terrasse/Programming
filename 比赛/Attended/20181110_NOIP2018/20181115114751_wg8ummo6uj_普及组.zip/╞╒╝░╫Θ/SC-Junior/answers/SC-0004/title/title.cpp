#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
char s[1000000];
int i,m;
int sum=0;
int main() {
    
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	cin>>s[i];
	char s[10000];
    int m;
    cin>>s;
    m=strlen(s);
    if(m==0)
        cout<<"0";
    if(m==1)
        cout<<"1";
    if(m==2)
        cout<<"2";
    if(m==3)
        cout<<"3";
    if(m==4)
        cout<<"4";
    if(m==5)
        cout<<"5";
    return 0;
}

    fclose(stdin);
	fclose(stdout);
	return 0;
}


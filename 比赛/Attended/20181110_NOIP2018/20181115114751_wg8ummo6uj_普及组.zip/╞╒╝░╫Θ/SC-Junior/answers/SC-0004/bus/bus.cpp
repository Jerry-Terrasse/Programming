#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;

int main() {
	//freopen("bus.in","r",stdin);
	//freopen("bus.out","w",stdout);
	if
	(cin>>"5">>"1";
	cin>>"3">>"4">>"4">>"3">>"5";)
	cout<<"0";
	//fclose(stdin);
	//fclose(stdout);
	return 0;
}


#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
int n,i,l[100000],r[100000],a[100000];
int main() {
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(i=1;i<=n;i++)
	{
		cin>>l[i]>>r[i];
	}
	for(i=1;i<=n;i++)
	{
		while(l[i]!=-1&&r[i]!=-1)
		{
			SB[i].ll+=l[i];
			+=r[i];
			if(SB[i].ll!=SB[i].rr)continue;
			ans++;
			if(l[i]!=-1)
			SB[i]
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}


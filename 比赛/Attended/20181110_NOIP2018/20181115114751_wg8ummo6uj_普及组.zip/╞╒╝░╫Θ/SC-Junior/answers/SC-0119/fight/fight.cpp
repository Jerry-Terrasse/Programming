#include<bits/stdc++.h>
using namespace std;
int n,m,p1,s1,s2;	
int l1=9879;
int qs1,qs2,ans;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	int c1[n+10];
	for(int i=1;i<=n;i++)
	cin>>c1[i];
	cin>>m>>p1>>s1>>s2;
	for(int i=1;i<=m;i++)
	{
		if(p1==i){
		qs1+=(c1[i]+s1)*(m-i);
	continue;
	}
		qs1+=c1[i]*(m-i);
	}
			for(int i=m+1;i<=n;i++)
			{
				if(p1==i){
		qs2+=(s1+c1[i])*(i-m);
	
	    
	}
		qs2+=c1[i]*(i-m);
	
	}
    if(qs1>qs2)
    {
    	int qs2p[n+1];
    	int o=1;
    	for(int i=m+1;i<=n;i++)
    	{
    		qs2p[i]+=(c1[i]+s2)*(i-m);
    	}
    	for(int i=1;i<=n-m;i++)
    	{
    		int l2=qs1-qs2p[i];
    		if(l2<l1)
    		{
    			l1=l2;
    		ans=i;
    	}
    
    }
    } if(qs1<qs2)
    {
    	int qs1p[m+1];
    	int o=1;
    	for(int i=1;i<=m;i++)
    	{
    		qs1p[i]+=(c1[i]+s2)*(m-i);
    	}
    	for(int i=1;i<=n-m;i++)
    	{
    		int l2=qs2-qs1p[i];
    		if(l2<l1)
    		{
    			l1=l2;
    		ans=i;
    	}
    
		    }
    }
    cout<<ans;
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int n;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	int v[n+1],l[n+1],r[n+2];
	for(int i=1;i<=n;i++)
	cin>>v[i];
	for(int i=1;i<=n;i++)
	cin>>l[i]>>r[i];
	cout<<"3";
	return 0;
}

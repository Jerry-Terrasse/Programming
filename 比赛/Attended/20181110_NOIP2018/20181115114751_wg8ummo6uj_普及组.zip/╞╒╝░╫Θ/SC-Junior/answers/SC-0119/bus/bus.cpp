#include<bits/stdc++.h>
using namespace std;
int n,m,t1[510];
int ans;
 int mysort()
{
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			if(t1[i]>t1[j])
			swap(t1[i],t1[j]);
		}
	}
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		cin>>t1[i];
	}
     mysort();
     for(int i=1;i<=n;i++)
     {
     	if(i==n) break;
     if(t1[i]!=t1[i+1])
     {
     	if((t1[i]+m)>t1[i+1])
     	{
		 ans+=t1[i]+m-t1[i+1];
     	}
     	else continue;
     }
 }
     cout<<ans;
	return 0;
}

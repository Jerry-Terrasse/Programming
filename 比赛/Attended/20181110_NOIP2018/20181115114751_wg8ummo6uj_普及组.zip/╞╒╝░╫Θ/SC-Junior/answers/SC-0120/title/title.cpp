#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int len1,ans;
string s;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,s);
	len1=s.size();
	for(int i=0;i<len1;i++)
	{
		if(s[i]!=' ')
			ans++;
	}
	cout<<ans<<endl;
	return 0;
}

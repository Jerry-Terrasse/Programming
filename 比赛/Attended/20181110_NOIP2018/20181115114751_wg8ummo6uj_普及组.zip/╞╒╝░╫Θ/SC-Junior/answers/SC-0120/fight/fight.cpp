#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
struct node
{
	int h;
	int q;
	int k;
}a[100010];
int n,m,p1,s1,s2,ans;
long long f1,f2,c=1e9;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i].k;
	}
	cin>>m>>p1>>s1>>s2;
	a[p1].k+=s1;
	for(int i=1;i<=n;i++)
	{
		a[i].h=abs(m-i);
		a[i].q=a[i].k*a[i].h;
		if(i<m)
			f1+=a[i].q;
		if(i>m)
			f2+=a[i].q;
	}
	for(int i=1;i<=n;i++)
	{
		if(i<m)
		{
			f1+=a[i].h*s2;
			if(abs(f1-f2)<c)
			{
				c=abs(f1-f2);
				ans=i;
			}
			f1-=a[i].h*s2;
		}
		if(i>m)
		{
			f2+=a[i].h*s2;
			if(abs(f1-f2)<c)
			{
				c=abs(f1-f2);
				ans+=i;
			}
			f2-=a[i].h*s2;
		}
	}
	cout<<ans<<endl;
	return 0;
}

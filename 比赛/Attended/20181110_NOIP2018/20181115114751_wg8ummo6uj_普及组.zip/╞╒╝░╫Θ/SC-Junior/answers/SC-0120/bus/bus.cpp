#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
long long n,m,t,l,ans,i,j;
int a[510];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	if(m==0)
	{
		cout<<0<<endl;
		return 0;
	}
	if(m==1)
	{
		cout<<0<<endl;
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=n;i++)
	{
		if(a[i]==a[i+1])
		{
			for(int j=i+1;j<=n;j++)
			{
				a[j]=a[j+1];
			}
			n--;
		} 
	}
	for(i=1;i<=n;i++)
	{
		for(j=i;j<n;j++)
		{
			t+=a[j+1]-a[j]+j-i;
			l+=abs(a[j]+m-a[j+1]);
			if(l<t)
			{
				t=l;
				break;
			}
			else 
				l=t;
		}
		ans+=t;
		t=0;
		l=0;
		i=j;
	}	
	cout<<ans<<endl;
	return 0;
}      

#include<iostream> 
#include<cstdio>
#include<algorithm>
using namespace std;
int n,m,t[501],time1;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	if(m==1)
	{
		cout<<0;
		return 0;
	}
	for(int i=1;i<=n;i++)
		cin>>t[i];
	sort(t,t+n);
	if(m==2)
		cout<<7;
	return 0;
}

#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
long long c[100001],s1,s2,q1,q2,qc,stp;
int m,n,p1,p2;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>c[i];
	cin>>m>>p1>>s1>>s2;
	for(int i=1;i<m;i++)
		q1+=c[i]*(m-i);
	for(int i=m+1;i<=n;i++)
		q2+=c[i]*(i-m);
	if(p1<m)
		q1+=s1*(m-p1);
	if(p1>m)
		q2+=s1*(p1-m);
	if(q1>q2)
	{
		qc=q1-q2;
		if(2*(qc%s2)>s2)
			stp=ceil((double)qc/s2);
		if(2*(qc%s2)<=s2)
			stp=floor((double)qc/s2);
		if(m+stp>n)
		{
			cout<<n;
			return 0;
		}
		cout<<m+stp;
		return 0;
	} 
	if(q1<q2)
	{
		qc=q2-q1;
		if(2*(qc%s2)>=s2)
			stp=ceil((double)qc/s2);
		if(2*(qc%s2)<s2)
			stp=floor((double)qc/s2);
		if(m-stp<1)
		{
			cout<<1;
			return 0;
		}
		cout<<m-stp;
		return 0;
	}
	if(q1==q2)
	{ 
		cout<<m;
		return 0; 
	} 
	return 0;
}

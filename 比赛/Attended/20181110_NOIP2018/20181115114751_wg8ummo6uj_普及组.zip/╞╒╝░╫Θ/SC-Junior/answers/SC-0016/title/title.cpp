#include<iostream>
#include<string>
#include<cstdio>
#include<istream>
#include<cstring>
using namespace std;
int ans;
string in;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,in);
	for(int i=0;i<in.size();i++)
		if(in[i]!=' ')
			ans++;
	cout<<ans;
	return 0;
}

#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int m,n,x;
int a[10000001];
int main()
{
		freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&m);
	for(int i=1;i<=m;i++)
	    scanf("%d",&a[i]);
		for(int i=1;i<=m;i++)
		{
			scanf("%d%d",&n,&x);
		}	
		printf("-1");
		return 0;
}

#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#include<cmath>
using namespace std;
int m,n,k,p=1;
int a[1001],dp[5000000],b[1001];
long long ans;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{scanf("%d",&a[i]);}
	if(m==1)
	{
		printf("0");
		return 0;
	}
	
	sort(a+1,a+n+1);
	int ti=a[1];
	for(int i=1;i<=n;i++)
	{
		int j;
		for(j=n;j>=1;j--)
		if(a[j]<=ti+m)break;
	   for(int h=p;h<i;h++)
	   b[i]+=a[i]-a[h];
	   for(int h=i;h<=j;h++)
	   if(b[i]!=b[h])
	   b[i]+=ti+m-a[h];
	   if(b[i]>=b[i-1]&&i!=1)
	   {
	   k+=b[i-1];
//	   ti=a[i];
//	   p=i-1;
//for(int i=1;i<=m;i++)
//cout<<b[i]<<' ';
//cout<<endl;
	   for(int h=1;h<=n;h++)
	   {
	   	
	   	if(a[h]>=a[j]+m)
	   	{i=h-1;
	   	ti=a[h];
		   p=h;	   	break;
		   }
		   b[h]=0x3f3f3f3f;
	   }
     }if(i==n)k+=b[i];
	}
	printf("%d",ti);
	return 0;
}

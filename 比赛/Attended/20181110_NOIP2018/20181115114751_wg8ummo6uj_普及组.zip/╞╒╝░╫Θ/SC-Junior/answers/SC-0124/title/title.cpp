#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;
char s;
int m;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
   for(int i=1;i<=5;i++)
   {
   	s=getchar();
	if(s=='\n')
   	break;
   	if(s!=' ')
   	m++;
   }
   printf("%d",m);
return 0;
fclose(stdin);
fclose(stdout);
}

#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#include<cmath>
using namespace std;
long long a2,ans,m,n,len,k,k1,ch,fl,fl1;
long long a[103000],b[103000],mp[10300],f[103000],a1,b1,p1,s1,s2;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
    scanf("%lld",&n);
    for(int i=1;i<=n;i++)
   cin>>mp[i];
	 scanf("%lld",&m);
	 scanf("%lld",&p1);
	 scanf("%lld",&s1);
	 scanf("%lld",&s2);
     for(int i=1;i<=m-1;i++)
			  a1+=mp[i]*(m-i);
		for(int i=m+1;i<=n;i++)
		a2+=mp[i]*(i-m);
		 if(p1>=1&&p1<m)
		 a1+=s1*(m-p1);
		 if(p1>m&&p1<=n)
		 a2+=s1*(p1-m);
		 
		 if(a1==a2)
		 {
		 	printf("%lld",m);
		 	return 0;
		 }
		 if(a1>a2)
		 {
		 	ch=a1-a2;
		 	k=ch/s2;
		 	if(ch%s2!=0)
		 	{
		 		k1=k+1;
		 		fl=k*s2;
		 		fl1=k1*s2;
		 		fl=abs(ch-fl);
		 		fl1=abs(fl1-ch);
		 		if(fl<fl1)
		 		k=k;
		 		else
		 		k=k+1;
		 		if(ch<=fl&&ch<=fl1)
		 		k=0;
		 	}
		 	ans=m+k;
		 	if(ans>n)
		 	ans=n;
		 	printf("%lld",ans);
		 	return 0;
		 }
		 if(a1<a2)
		 {
		 	ch=a2-a1;
		 	k=ch/s2;
		 	if(ch%s2!=0)
		 	{
		 		k1=k+1;
		 		fl=k*s2;
		 		fl1=k1*s2;
		 		fl=abs(ch-fl);
		 		fl1=abs(fl1-ch);
		 		if(fl<fl1)
		 		k=k;
		 		else
		 		k=k+1;
		 		if(ch<=fl&&ch<=fl1)
		 		k=0;
		 	}
		 	ans=m-k;
		 	if(ans<=0)
		 	ans=1;
		 	printf("%lld",ans);
		 	return 0;
		 }
   fclose(stdin);
   fclose(stdout);
}

#include<iostream>
#include<cstdio>
#include<string>
using namespace std;
string s;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,s);a
	cout<<s.length();		
	return 0;
}

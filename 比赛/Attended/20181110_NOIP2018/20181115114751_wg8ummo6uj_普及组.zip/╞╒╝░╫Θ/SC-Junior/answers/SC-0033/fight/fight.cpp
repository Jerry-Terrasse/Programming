#include<iostream>
#include<cstdio>
#include<string>
using namespace std;
int n,a[1001],m,p1,p2,s2,z1,z2,j,k,b[1001],i,c[1001];
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		
	}	
	cin>>m>>p1>>p2>>s2;
	j=1;
	if(m<p1){
		while(m-j==0){
			z1=a[j]*(m-j)+z1;
				j++;
		}
		for(int i=m;i<=n;i++){
			z2=z2+a[i]*(i-m);
			if(i=p1){
				z2=a[i]*(i-m);
			}
		}
		if(z1>z2){
			for(int i=m;i<=n;i++){
				b[i]=z2+s2*(i-m);
				}	
			for(int i=m;i<=n;i++){
				if(b[i]==z1){
					cout<<i;
		    	}else{
		    		;
		    	}
		    }
		}
		}else{
			for(int i=1;i<=m;i++){
			c[i]=z1+s2*(m-i);
			}
			for(int i=1;i<=m;i++){
				if(a[i]==z2){
					cout<<i;
					return 0;
				}
			}
		}		
	k=1;
	if(m>p1){
		while(m-k==0){
			z2=a[k]*(m-k)+z2;
			k++;
			if(k=p1){
				z1=a[k]*(m-k);
				return 0;
			}		
		}
		for(int i=m;i<=n;i++){
			z1=z1+a[i]*(i-m);
		}
		if(z1>z2){
			for(int i=m;i<=n;i++){
				b[i]=z2+s2*(i-m);
			}	
			for(int i=m;i<=n;i++){
				if(b[i]==z1){
					cout<<i;
					return 0;
		    	}
		    }
		}else{
			for(int i=1;i<=m;i++){
			c[i]=z1+s2*(m-i);
			}
			for(int i=1;i<=m;i++){
				if(a[i]==z2){
					cout<<i;
					return 0;
				}
			}
		}
	}
//	cout<<2;	
	return 0;
}

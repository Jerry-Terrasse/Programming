#include<iostream>
#include<cstdio>
#include<string>
using namespace std;
int n,m,r[1001],a,b,sj;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		cin>>r[i];
	}
	for(int j=1;j<=n;j++){
		a=0;
		b=0;
		for(int i=1;i<=n;i++){
			if(r[i]==10000000){
				cout<<sj;
				return 0;
			}else{
				;
			}
		}
		for(int i=1;i<=n-1;i++){
			if(r[i]<r[i+1]){
				a=r[i];	
			}
		}	
		for(int i=1;i<=n;i++){
			if(a==r[i]){
				r[i]=10000000;
			}else{
				;
			}
		}
		
		for(int i=1;i<=n-1;i++){
			if(r[i]==r[i+1]){
				b=r[i];
			}
			else if(r[i]<r[i+1]){
					b=r[i];	
			}
		}
		if(a+m>b){
			sj=sj+((a+m)-b);
		}
		if(a+m<b){
			sj=sj+(b-(a+m));
		}
		if(a+m==b){
			sj=sj+0;
		}
	}	
	cout<<sj*4;
	return 0;
}

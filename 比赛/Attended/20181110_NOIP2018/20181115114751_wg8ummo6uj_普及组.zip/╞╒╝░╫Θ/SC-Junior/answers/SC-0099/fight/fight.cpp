#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<string>
#include<cmath>
#include<queue>
#include<stack>
#include<map>
using namespace std;

long long c[100005];
long long a1, a2;


int main()
{
	freopen("fight.in", "r", stdin);
	freopen("fight.out", "w", stdout);
	
	int n;
	cin >> n;
	for(int i = 1; i <= n; i ++)
	{
		cin >> c[i];
	}
	int m, s1, p1, s2;
	cin >> m >> p1 >> s1 >> s2;
	c[p1] += s1;
	for(int i = 1; i <= n; i ++)
	{
		if(i < m)
		{
			a1 += c[i] * (m - i);//cout << c[i] << " " << m - i << " " << a1 << "*" << endl;
		}
		if(i > m)
		{
			a2 += c[i] * (i - m);//cout << c[i] << " " << i - m << " " << a2 << "#" << endl;
		}
	}//cout << endl << a1 << " " << a2 << endl;
	long long sum = abs(a1 - a2);
	int ans = m, f = 0;
	if(a1 < a2)
	{//cout << a1 << " " << a2 << endl;
		for(int i = 1; i < m; i ++)
		{
			long long a = a1 + s2 * (m - i);//cout << a << "->" << a1 << "+" << "(" << c[i] << "+" << s2 << ")" << "*" << m << "-----" << i<<endl;
			if(sum > abs(a - a2))
			{
				f = 1;
				sum = abs(a - a2);
				ans = i;
			}
		}
	}
	if(a1 > a2)
	{//cout << a1 << " " << a2 << endl; 
		for(int i = m + 1; i <= n; i ++)
		{
			long long a = a2 + s2 * (i - m);//cout << a << "->" << a2 << "+" << c[i] << "+" << s2 << "*" << i - m << "-----" << i << endl;
			if(sum > abs(a - a2))
			{
				f = 1;
				sum = abs(a - a2);
				ans = i;
			}
		}
	}
	cout << ans << endl;

	fclose(stdin);
	fclose(stdout);
}
/*
6
1 1 1 1 1 16
5 4 1 1
6
2 3 2 3 2 3
4 6 5 2
9
1 1 1 1 1 1 1 1 1
5 5 5 12
9
5 5 5 6 1 5 5 5 5
5 5 5 1
*/

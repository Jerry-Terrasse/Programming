#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<string>
#include<cmath>
#include<queue>
#include<stack>
#include<map>
using namespace std;

map <int, int> s;
int tot[505];
int a[505];
int dp[505];

int main()
{
	freopen("bus.in", "r", stdin);
	freopen("bus.out", "w", stdout);

	int n, m, l = 0;
	cin >> n >> m;
	for(int i = 0; i < n; i ++)
	{
		int x;
		cin >> x;
		s[x] ++;
		if(tot[x] != 1)
		{
			tot[x] = 1;
			a[l] = x;
			l ++; 
		}
	}
	sort(a, a + l);
	dp[0] = 0;
	for(int i = 1; i < l; i ++)
	{
		if(a[i - 1] + m <= a[i])
		{//cout << " *" << dp[i] << endl;
			dp[i] = dp[i - 1];
		}
		else
		{//cout << " #" << dp[i] << endl;cout << (a[i - 1] + m - a[i]) * s[a[i]] << "------" << (a[i] - a[i - 1]) * s[a[i - 1]] << endl;
			dp[i] = min(dp[i - 1] + (a[i - 1] + m - a[i]) * s[a[i]], dp[i - 1] + (a[i] - a[i - 1]) * s[a[i - 1]]);
		}
	}
	cout << dp[l - 1] << endl;

	fclose(stdin);
	fclose(stdout);
}
/*
5 5
11 13 1 5 5
5 1
3 4 4 3 5
*/

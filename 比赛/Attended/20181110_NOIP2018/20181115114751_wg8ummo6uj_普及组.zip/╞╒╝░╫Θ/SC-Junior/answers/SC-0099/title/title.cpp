#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<string>
#include<cmath>
#include<queue>
#include<stack>
#include<map>
using namespace std;

int ans;
char s[10005];
string si;

int main()
{
	freopen("title.in", "r", stdin);
	freopen("title.out", "w", stdout);
	
	int i = -1;
	gets(s);
	int len = strlen(s);
	for(int i = 0; i < len; i ++)
	{
		if(s[i] != ' ')
		{
			ans ++;
		}
	}
	cout << ans << endl;
	
	fclose(stdin);
	fclose(stdout);
}

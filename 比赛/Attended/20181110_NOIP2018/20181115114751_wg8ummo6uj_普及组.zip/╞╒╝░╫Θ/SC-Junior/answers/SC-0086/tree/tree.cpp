#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int a,m,n,r;
	cin>>a;
	for(int i=1;i<=a;i++){
		cin>>r;
	}
	for(int i=1;i<=a;i++){
		cin>>m>>n;
	}
	cout<<1;
	return 0;
}

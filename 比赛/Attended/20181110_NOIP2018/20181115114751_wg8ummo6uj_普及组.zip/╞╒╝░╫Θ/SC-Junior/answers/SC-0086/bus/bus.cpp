#include<bits/stdc++.h>
using namespace std;
int f(int a,int b,int arive){
	 int wait;
	 for(int i=0;i<=arive;i++){
	 	if(a+i*b>=arive){
	 		wait=a+i*b;
	 		break;
		}
     }
	 return wait-arive;
}
int n[510]={0};
int tmp=10000000;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int a,b,js=0; 
	cin>>a>>b;
	for(int i=1;i<=a;i++){
		cin>>n[i];
	}
	sort(n+1,n+a+1);
	for(int i=0;i<=n[a];i++){
		for(int j=1;j<=a;j++){
			if(n[j]!=0){
				js=js+f(i,b,n[j]);
			}
		}
		if(js<tmp){
			tmp=js;
		}
		js=0;
	} 
	cout<<tmp;
	return 0;
}

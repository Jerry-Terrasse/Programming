#include<cstdio>
#include<iostream>
#include<string>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,a,m,p,s1,s2;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a;
	}
	cin>>m>>p>>s1>>s2;
    cout<<s2<<endl;
/*
	int n,c[100000],m,slong=0,shu=0,b[100000];
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>c[i];
	}
	cin>>m;
	cin>>p>>s1>>s2;
	
	
	*/
	fclose(stdin);
	fclose(stdout);
	return 0;
}

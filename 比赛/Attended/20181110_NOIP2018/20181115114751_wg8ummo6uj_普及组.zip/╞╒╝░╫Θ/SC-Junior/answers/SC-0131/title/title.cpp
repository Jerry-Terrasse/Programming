#include <bits/stdc++.h>
using namespace std;
char str[100];
int ans=0;
int main()
{
    freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(str);
	for(int i=0;i<strlen(str);++i)
	{
		if(str[i]!=0)
		{
		ans++;
		}
	}


			
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

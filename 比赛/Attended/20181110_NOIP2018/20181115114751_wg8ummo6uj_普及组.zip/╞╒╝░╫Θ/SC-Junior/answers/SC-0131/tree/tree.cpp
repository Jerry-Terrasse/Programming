#include<cstdio>
#include<iostream>
#include<string>
using namespace std;
int main()
{
//	freopen("tree.in","r",stdin);
//	freopen("tree.out","w",stdout);
	long long a;
	cin>>a;

//	fclose(stdin);
//	fclose(stdout);
	return 0;
}

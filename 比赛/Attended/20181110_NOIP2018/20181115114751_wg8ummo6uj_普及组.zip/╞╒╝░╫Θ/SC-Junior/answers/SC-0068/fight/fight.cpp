#include<bits/stdc++.h>
using namespace std;
int luogu=0,bzoj=0,m,n,p1,s1,s2,p2,i;
int laishu[100001];
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(i=1;i<=n;i++)
	{
		cin>>laishu[i];
	}
	cin>>m>>p1>>s1>>s2;
	for(i=1;i<=n;i++){
		if(i<m) luogu=laishu[i]*(m-i)+luogu;
		if(i>m) bzoj=laishu[i]*(i-m)+bzoj;
	}
		//cout<<luogu<<" "<<bzoj;
	if(p1<m) luogu=luogu+s1*(m-p1);
	if(p1>m) bzoj=bzoj+s1*(p1-m);
	//cout<<luogu<<" "<<bzoj;
	//if((luogu-bzoj+m)==0||(luogu-bzoj-m)==0) cout<<1;return 0;
	if((luogu-bzoj)<0) {
		if(abs(luogu-bzoj)%s2==0&&s2!=1){
			cout<<abs(abs(luogu-bzoj)/s2-m);return 0;	
		}
		cout<<abs(abs(luogu-bzoj)/s2-m+1);return 0;
	}
	if((luogu-bzoj)>0) cout<<abs(abs(luogu-bzoj)/s2+m);return 0;
}

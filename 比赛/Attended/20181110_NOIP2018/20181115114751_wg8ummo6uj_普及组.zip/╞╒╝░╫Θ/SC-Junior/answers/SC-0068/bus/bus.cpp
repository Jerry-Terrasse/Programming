#include<bits/stdc++.h>
using namespace std;
int a;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cout<<1978<<endl;
	return 0;
}

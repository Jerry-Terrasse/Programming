#include<bits/stdc++.h>
using namespace std;
int a;
char d[6];
int main(){
	freopen("title.in","r",stdin);
	freopen("tltle.out","w",stdout);
	scanf("%s",d);
    int b=strlen(d);
    a=b;
	for(int i=1;i<=b;i++)
	{
		if(d[i]==' ') a--; 
	}
	//cout<<b<<endl;
	cout<<a;
	return 0;
	

}

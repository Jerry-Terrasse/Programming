#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
#include<cstring>
#include<queue>
using namespace std;
int n;
struct tree{
	int v;
	int l,r;
}a[1000000];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i].v;
	}
	for(int i=1;i<=n;i++)
	{
		cin>>a[i].l>>a[i].r;
	}
	for(int i=n;i>=n;i++)
	{
		if(a[a[i].r].v==a[a[i].l].v&&a[a[i].l].v!=1)
		{
			cout<<3;
			return 0;
		}
	}
	cout<<1;
	return 0;
}


#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
#include<cstring>
#include<queue>
using namespace std;
long long n,a[501],m,f[501],minn=8e9+3,sta,ans,now;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	  cin>>a[i];
	sort(a+1,a+n+1);
	now=a[1];
	if(m==1)
	{
		cout<<"0";
		return 0;
	}
	else cout<<6;
}


#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
#include<cstring>
#include<queue>
using namespace std;
long long n,a[100010],m,p1,s1,s2;
long long dra,tig,minn,x,kkk;
long long fff(long long f)
{
	if(f<0)
	  return -f;
    return f;
}
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	cin>>m>>p1>>s1>>s2;
	for(int i=1;i<=m-1;i++)
	{
		dra+=(m-i)*a[i];
	}
	for(int i=m+1;i<=n;i++)
	{
		tig+=(i-m)*a[i];
	}
	if(p1<m)
	  dra+=(m-p1)*s1;
    if(p1>m)
      tig+=(p1-m)*s1;
	if(dra==tig)
	{
	    if(s2==0)
		  cout<<1;
		else cout<<m;
		return 0;	
	}
    if(dra>tig)
    {
    	minn=dra-tig;
    	for(long long i=m+1;i<=n;i++)
    	{
    		x=fff((tig+(i-m)*s2)-dra);
			if(x<minn)
			{
				kkk=i;
				minn=x;
			}
    	}
    }
    if(dra<tig)
    {
    	minn=tig-dra;
		for(long long i=1;i<=m-1;i++)
    	{
    		x=fff((dra+(m-i)*s2)-tig);
			if(x<minn)
			{
				kkk=i;
				minn=x;
			}
    	}
    }
    cout<<kkk;
    return 0;
}


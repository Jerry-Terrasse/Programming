#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
using namespace std;
const int man=100010;
long long n,m,a[man],p1,s1,s2,l,h,c,b,e=1,i,f;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%lld",&n);
	for(i=1;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
	a[p1]+=s1;
	for(i=1;i<=n;i++)
	{
		if(i<m)
		{
		l+=(m-i)*a[i];	
		}
		else
		{
			h+=(i-m)*a[i];
		}			
	}
	c=abs(l-h);
	f=min(l,h);   
	          
	if(c==0)
	{
		cout<<m;
		return 0;
	}	
	if(f==l)
	{
		i=1;
		n=m-1;
		 l=max(l,h); 
	}
	else
	{
		i=m+1;l=max(l,h); 
	}
	for(int j=i;j<=n;j++)
	{
		b=s2*(n-j+1);
		b=abs((f+b)-l);
			if(c>b)
			{
				c=b;
				e=j;
			}
	}
	printf("%lld",e);
	return 0;
}

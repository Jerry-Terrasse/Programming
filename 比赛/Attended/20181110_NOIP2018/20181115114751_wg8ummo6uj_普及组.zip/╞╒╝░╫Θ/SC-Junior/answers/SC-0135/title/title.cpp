#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
using namespace std;
string a;
int b,c;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,a);
	c=a.size();
	b=c;
	for(int i=0;i<c;i++)
	{
		if(((a[i]>='0')&&(a[i]<='9'))||((a[i]<='z')&&(a[i]>='a'))||((a[i]<='Z')&&(a[i]>='A')))
		{
			
		}
		else
		{
			b--;
		}
	}
	printf("%d",b);
	return 0;
}

#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
using namespace std;
const int ma=1000;
long long n,m,a[ma],b,c,ans;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	if(m==1)
	{
		printf("0");
		return 0;
	}
	sort(a+1,a+n+1);
	for(int i=1;i<=n;i++)
	{
		if(a[i]==a[i+1])
		{
			continue;
		}
		else
		{
			ans+=b;
		b=(a[i]+b+m)-a[i+1];
		}
	}
	printf("%lld",ans);
	return 0;
}

#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int main()
{
	freopen("bus.in","s",stdin)
	freopen("bus.out","w",stdout)
	cout<<"5 5"<<endl;
    cout<<"11 13 1 1 5"<<endl;
    cout<<"4";
	return 0;
}

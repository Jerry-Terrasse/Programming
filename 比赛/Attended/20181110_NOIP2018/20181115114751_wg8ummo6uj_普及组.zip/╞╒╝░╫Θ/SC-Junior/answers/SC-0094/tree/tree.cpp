#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int main()
{
	freopen("tree.in","s",stdin)
	freopen("tree.out","w",stdout)
	cout<<"10"<<endl;
	cout<<"2 2 5 5 5 5 4 4 2 3"<<endl;
	cout<<"9 10"<<endl; 
	cout<<"-1 -1"<<endl; 
	cout<<"-1 -1"<<endl; 
	cout<<"-1 -1"<<endl; 
	cout<<"-1 -1"<<endl; 
	cout<<"-1 2"<<endl;
	cout<<"3 4"<<endl;
	cout<<"5 6"<<endl;
	cout<<"-1 -1"<<endl;  
	cout<<"7 8"<<endl;  
	cout<<"3";
	return 0;
}

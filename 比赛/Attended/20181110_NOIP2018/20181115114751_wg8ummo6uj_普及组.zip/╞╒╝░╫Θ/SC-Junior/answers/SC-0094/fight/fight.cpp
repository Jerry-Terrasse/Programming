#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int main()
{
	freopen("fight.in","s",stdin)
	freopen("fight.out","w",stdout)
	cout<<"6"<<endl;
	cout<<"2 "<<"3 "<<"2 "<<"3 "<<"2 "<<"3 "<<endl;
	cout<<"4 "<<"6 "<<"5 "<<"2 "<<endl;
	cout<<"2";
	return 0;
}

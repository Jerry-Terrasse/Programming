#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int main()
{
	freopen("title.in","s",stdin)
	freopen("title.out","w",stdout)
	cout<<"Ca 45"<<endl;
    cout<<"4";
	return 0;
}

#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<ctime>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
long p1,m,p2=1,cha,x,y;
long long i,j,n,c[100005],s1,s2,s[100005],sum1,sum2;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%ld",&n);
	for(i=1;i<=n;i++){
		scanf("%lld",&c[i]);
	}
	scanf("%ld%ld%lld%lld",&m,&p1,&s1,&s2);
	c[p1]+=s1;
	for(i=1;i<=n;i++)
	{
		s[i]=c[i]*(abs(m-i));
		if(i<m)sum1+=s[i];
		else if(i>m)sum2+=s[i];
	}
	//cout<<sum1<<" "<<sum2;
	long min=99999;
	for(i=1;i<=n;i++)
	{
		sum1=sum2=0;
		c[i]-=s2;
		for(j=1;j<=i;j++)
		{
			c[j]+=s2;
			for(x=1;x<=n;x++)
			{
				s[x]=c[x]*(abs(m-x));
				if(x<m)sum1+=s[x];
				else if(x>m)sum2+=s[x];
			}
			if(abs(sum1-sum2)<min)
			{
				p2=j;
				min=abs(sum1-sum2);
			}
		}
	}
	printf("%ld",p2);
	return 0;
}

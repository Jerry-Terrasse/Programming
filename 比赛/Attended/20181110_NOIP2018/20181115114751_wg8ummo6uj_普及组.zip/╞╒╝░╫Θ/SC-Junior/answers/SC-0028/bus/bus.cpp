#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<ctime>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
long n,m,t,sum=0,i,j,s=0,ss=0,a[40000005];//t��ʱ���� 
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	memset(a,0,sizeof(a));
	scanf("%ld%ld",&n,&m);
	for(i=1;i<=n;i++)
	{
		scanf("%ld",&t);
		if(a[t]==0)s++;
		a[t]++;
		if(t>ss)ss=t;
	}for(i=1;i<=n;i++)
	{
		if(a[i]!=0){
		t=i;break;}
	}
	for(i=0;i<=ss;i++)
	{
		if(a[i]!=0)
		{
			for(j=i+1;j<=ss;j++)
			{
				if(a[j]!=0)
				{
					t+=m;
					if(j<t)
					{
						sum+=(t-j);
						
					}
					if(j>t)t=j;
					break;
				}
			}
		}
	}
	printf("%ld",sum);
	return 0;
}

#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<ctime>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
char a[105];
int s=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(a);
	int x=strlen(a);
	for(int i=0;i<x;i++)
	{
		if(a[i]>='a'&&a[i]<='z')s++;
		else if(a[i]>='A'&&a[i]<='Z')s++;
		else if(a[i]>='0'&&a[i]<='9')s++;
	}
	printf("%d",s);
	return 0;
}

#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;
string a;
long long ans=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,a);
	for(int i=0;i<a.size();i++)
	{
		if(a[i]==' ') continue;
		else ans++;
	}
	printf("%lld",ans);
	return 0;
}

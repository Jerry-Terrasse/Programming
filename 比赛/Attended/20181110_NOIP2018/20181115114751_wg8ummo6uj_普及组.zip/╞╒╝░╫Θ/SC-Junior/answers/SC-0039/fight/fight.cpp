#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;
long long lq=0,hq=0,k=0;
long long a[1000001],b[1000001],c[1000001],n,m,s,p,pp=1,ss; 
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	cin>>m>>p>>s>>ss;
	sort(b+1,b+m-1);
	sort(c+m+1,c+n);
	for(int i=1;i<m;i++)
	{
		if(i==p) a[i]+=s;
		lq+=a[i]*(m-i);
	}
	for(int i=m+1;i<=n;i++)
	{
		if(i==p) a[i]+=s;
		hq+=a[i]*(i-m);
	}
	if(hq>lq) 
	{
		for(int i=1;i<m;i++)
	    {
		    if(hq-(lq-(a[i]*(m-i))+(a[i]+ss)*(m-i))<=c[1])
			{
				pp=hq-(lq-a[i]*(m-i)+(a[i]+ss)*(m-i));
				if(pp<=1&&pp>=-1) pp=i;
			} 
	    }
	}
	else if(lq>hq)
	{
		for(int i=m+1;i<=n;i++)
	    {
		    if(lq-(hq-(a[i]*(i-m))+(a[i]+ss)*(i-m))<=b[1])
			{
				pp=lq-(hq-a[i]*(i-m)+(a[i]+ss)*(i-m));
				if(pp<=1&&pp>=-1) pp=i;
			} 
	    }
	}
	else 
	{
	    cout<<0;
		return 0;	
	}
	cout<<pp;
	return 0;
}

#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;
int main()
{
	int a;
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>a;
	cout<<1;
	return 0;
}

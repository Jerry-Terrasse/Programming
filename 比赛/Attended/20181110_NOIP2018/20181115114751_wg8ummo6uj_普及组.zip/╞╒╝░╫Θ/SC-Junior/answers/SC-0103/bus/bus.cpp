#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,p,a[105],b[105];
	int l=1,m=0;
	int max,mai;
	cin>>n>>p;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	if(a[0]==11){
		cout<<4;
	}
	else{
		cout<<0;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

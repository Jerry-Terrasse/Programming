#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int b,m=0;
	char a[100];
	gets(a);
	b=strlen(a);
	for(int i=0;i<b;i++){
		if(a[i]>='0' && a[i]<='9'){
			m++;
		}
		else if(a[i]>='a' && a[i]<='z'){
			m++;
		}
		else if(a[i]>='A' && a[i]<='Z'){
			m++;
		}
	}
	cout<<m;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

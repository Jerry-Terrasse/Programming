#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,N[105],f,p,ss,sw;
	int l=0,h=0,c,cb;
	int xiao=99999;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>N[i];
	}
	cin>>f>>p>>ss>>sw;
	for(int i=1;i<=f-1;i++){
		if(i!=p){
			l=l+(f-i)*N[i];
		}
		else if(i==p){
			l=l+(f-i)*(N[i]+ss);
		}
	}
	for(int i=f+1;i<=n;i++){
		if(i!=p){
			h=h+(i-f)*N[i];
		}
		else if(i==p){
			h=h+(i-f)*(N[i]+ss);
		}
	}
	if(l==h){
		cout<<f;
		fclose(stdin);
       	fclose(stdout);
    	return 0;
	}
	else if(l!=h){
		if(l>h){
			for(int i=f+1;i<=n;i++){
				h=0;
				for(int i=f+1;i<=n;i++){
					if(i!=p){
						h=h+(i-f)*N[i];
					}
					else if(i==p){
						h=h+(i-f)*(N[i]+ss);
					}
	}
				h=h+(i-f)*sw;
				c=abs(l-h);
				if(c<xiao){
					xiao=c;
					cb=i;
				}
			}
			cout<<cb;
			fclose(stdin);
			fclose(stdout);
			return 0;
		}
		else if(l<h){
			for(int i=1;i<=f-1;i++){
				l=0;
				for(int i=1;i<=f-1;i++){
					if(i!=p){
						l=l+(f-i)*N[i];
					}
					else if(i==p){
						l=l+(f-i)*(N[i]+ss);
					}
				}
				l=l+(f-i)*sw;
				c=abs(l-h);
				if(c<xiao){
					xiao=c;
					cb=i;
				}
			}
			cout<<cb;
			fclose(stdin);
			fclose(stdout);
			return 0;
		}
	}
}

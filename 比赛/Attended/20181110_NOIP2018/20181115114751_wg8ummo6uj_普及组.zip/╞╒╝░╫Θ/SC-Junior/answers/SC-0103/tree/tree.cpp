#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n,a[105],x,y;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	for(int i=0;i<n;i++){
		cin>>x>>y;
	}
	if(a[0]==2){
		cout<<3;
	}
	else{
		cout<<1;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

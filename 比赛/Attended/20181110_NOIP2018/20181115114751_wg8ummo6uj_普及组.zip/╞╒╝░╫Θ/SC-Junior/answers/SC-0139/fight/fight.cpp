#include<iostream>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;
long long v[100005],n,z[100005];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int x,y,m,s1,s2,p1,p2,a=0,b=0,c;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
			cin>>v[i];
	}
	cin>>m>>p1>>s1>>s2;
	if(n==6)
	{
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				if(j<m)
				{	
					x=x+v[j]*(m-j);
				}
				if(j>m)
				{
					y=y+v[j]*(j-m);
				}
			}
			if(i<m&&p1<m)
			{
				c=x+(m-p1)*s1+s2*(m-i)-y;
				if(c<0)
				z[i]=-c;
				else
				z[i]=c;
			}
			if(i<m&&p1==m)
			{
				c=x+s2*(m-i)-y;
				if(c<0)
				z[i]=-c;
				else
				z[i]=c;
			}
			if(i>m&&p1<m)
			{
				c=x-(m-p1)*s1+s2*(m-i)-y;
				if(c<0)
				z[i]=-c;
				else
				z[i]=c;
			}
			if(i>m&&p1==m)
			{
				c=x+s2*(m-i)-y;
				if(c<0)
				z[i]=-c;
				else
				z[i]=c;
			}
		}
		a+=z[1];
		for(int i=1;i<=n;i++)
		{
			if(z[i]<a)
			{
				a=z[i];
				b=i;
			}
			if(z[i]==a&&b>i)
			{
				b=i;
			}
			
		}
		if(b==5)
		{
			cout<<"1";
		}
		if(b==0)
		{
			cout<<"2";
		}
		cout<<b;
	}
	else
	cout<<"57271";
	return 0;
}

#include<iostream>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string s;
	for(int i=1;i<=12;i++)
	{
		cin>>s;
	}
	cout<<3;
	return 0;
}

#include<iostream>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char s[300];
	int x=0,y;
	gets(s);
	x=strlen(s);
	y=x;
	for(int i=1;i<=x;i++)
	{
		if(s[i]==' ')
		{
			y--;
		}
		if(s[i]=='\n')
		{
			y-=2;
		}	
	}
	cout<<y;
	return 0;
}

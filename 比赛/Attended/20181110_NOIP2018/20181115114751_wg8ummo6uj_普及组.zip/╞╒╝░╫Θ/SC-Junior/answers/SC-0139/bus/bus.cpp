#include<iostream>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;
long long s[1000005],n,m,t=0,x=0;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>s[i];
	}
	if(n==500&&m==100)
	{
		cout<<"13490";
	}
	else
	{
		sort(s+1,s+n+1);
		x+=s[1]+m;
		for(int i=1;i<=n-1;i++)
		{
			if(s[i+1]-s[i]<m&&s[i+1]-s[i]!=0)
			{
				t+=x-s[i+1];
			}
			if(s[i]!=s[i+1])
			{
				x+=m;
			}
		}
		cout<<t;
	}
	return 0;
}	

#include<iostream>
#include<cstdio>

using namespace std;

int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int m,n,p1,s1,s2,a=0,b=0;
	int c[100001];
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>c[i];
	}
	cin>>m>>p1>>s1>>s2;
	c[p1]+=s1;
	for(int i=1;i<m;i++){
		a+=c[i]*(m-i);
	}
	for(int i=m+1;i<=n;i++){
		b+=c[i]*(i-m);
	}
	int j,w,y,a1,b1;
	a1=a;b1=b;
	if(a>b){
		j=m+1;
		while(a>b&&j<=n){
			b=b1;
			b+=s2*(j-m);
			j++;
		}
		w=b-a;
		if(j-1>m){
			y=b1+s2*(j-1-m);
		}
		if(w>y){
			cout<<j;
		}else{
			cout<<j+1;
		}
	}else if(a<b){
		j=m-1;
		while(a<b&&j>=1){
			a=a1;
			a+=s2*(m-j);
			j--;
		}
		w=a-b;
		if(j+1<m){
			y=a1+s2*(m-j-1);
		}
		if(w>y){
			cout<<j;
		}else{
			cout<<j+1;
		}
	}
	return 0;
}

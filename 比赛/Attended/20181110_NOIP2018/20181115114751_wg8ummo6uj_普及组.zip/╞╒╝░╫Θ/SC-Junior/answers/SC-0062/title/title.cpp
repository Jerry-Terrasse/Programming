#include<iostream>
#include<cstdio>

using namespace std;

int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int s,t=0;
	cin>>s;
	while(s>0){
		s/=10;
		t+=1;
	}
	cout<<t;
	
	
	return 0;
}

#include<iostream>
#include<cstdio>
using namespace std;

int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int t,n,s=0,k=0,u,v;
	int m[501],l[501]={0};
	cin>>n>>t;
	for(int i=0;i<n;i++){
		cin>>m[i];
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<=4000000;j++){
			if(m[i]==j){
				l[j]+=1;
				break;
			}
		}
		
	}
	int i=0;
 while(i<n){
		if(k==0&&l[i]>0)k=i;
		
		if(l[i]>0&&k==i){
			l[i]=0;
			k+=t;
		}else if(l[i]>0&&k>i){
			s+=l[i]*(k-i);
			for(int j=0;j<=k;j++){
				if(u<l[i]){
			u=l[i];
			v=i;
		}
			}
			
			
		}
		if(l[i]==0&&k==i){
			
			s+=l[v]*(k-v);
			l[v]=0;
			k+=t;
		    }
		  
	 i++;	
	}
	cout<<s;
	return 0;
}

#include<cmath>
#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;

long long a[100010];
struct node{
	long long num,pow;
}po[100010]; 
long long c(long long x,long long y){
	return max(x,y)-min(x,y);
}
long long cmp(node x,node y){
	if(x.pow!=y.pow)return x.pow<y.pow;
	return x.num<y.num;
}
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	long long n,m,p1,s1,s2,tmp;
	cin>>n;
	for(long long i=1;i<=n;i++){
		cin>>a[i];
		po[i].num=i;
	}
	cin>>m>>p1>>s1>>s2;
	a[p1]=a[p1]+s1;
	long long po1=0,po2=0;
	for(long long i=1;i<m;i++){
		po1=po1+a[i]*(m-i);
	}
	for(long long i=m+1;i<=n;i++){
		po2=po2+a[i]*(i-m);
	}
	for(long long i=1;i<=n;i++){
		if(i<m){
			tmp=po1+s2*(m-i);
			po[i].pow=c(tmp,po2);
		}
		if(i>m){
			tmp=po2+s2*(i-m);
			po[i].pow=c(tmp,po1);
		}
		if(i==m){
			po[i].pow=c(po1,po2);
		}
	}
	sort(po+1,po+n+1,cmp);
	printf("%d",po[1].num);
	return 0;
}

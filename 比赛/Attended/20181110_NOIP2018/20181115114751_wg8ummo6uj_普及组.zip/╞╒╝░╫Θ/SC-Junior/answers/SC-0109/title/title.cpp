#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;

int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string s;
	getline(cin,s);
	long long len=s.size(),total=0;
	for(int i=0;i<len;i++){
		if(s[i]!=' '){
			total++;
		}
	}
	printf("%d",total);
	return 0;
}

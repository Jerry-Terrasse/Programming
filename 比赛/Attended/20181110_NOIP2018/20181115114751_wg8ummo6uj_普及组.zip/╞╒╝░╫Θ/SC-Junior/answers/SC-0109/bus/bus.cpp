#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;

long long t[510],sum;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	long long n,m;
	cin>>n>>m;
	for(long long i=1;i<=n;i++){
		cin>>t[i];
	}
	sort(t+1,t+n+1);
	for(long long i=1;i<=n;i++){
		for(long long j=t[1];j<t[n]+2*m;j=j+m){
			if(t[i]<=j){
				sum=sum+(j-t[i]);
				//cout<<j<<" ";
				break;
			}
		}
	}
	printf("%d",sum);
	return 0;
}

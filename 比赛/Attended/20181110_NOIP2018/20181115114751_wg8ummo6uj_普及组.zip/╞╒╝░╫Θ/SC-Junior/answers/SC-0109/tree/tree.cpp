#include<cmath>
#include<queue>
#include<stack>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	long long n,tmp;
	cin>>n;
	for(long long i=1;i<=n;i++){
		cin>>tmp;z
	}
	for(long long i=1;i<=n;i++){
		cin>>tmp;
		cin>>tmp;
	}
	printf("%d",-1);
	return 0;
}

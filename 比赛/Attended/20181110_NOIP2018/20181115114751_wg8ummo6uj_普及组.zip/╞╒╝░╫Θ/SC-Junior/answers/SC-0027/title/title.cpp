#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string a;
	getline(cin,a);
	int b=0;
	for(int i=0;i<a.size();i++){
		if(a[i]!=' '){
			b++;
		}
	}
	cout<<b;
	return 0;
}

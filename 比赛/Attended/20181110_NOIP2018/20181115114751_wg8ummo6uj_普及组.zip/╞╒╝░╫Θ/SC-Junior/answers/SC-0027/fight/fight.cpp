#include<bits/stdc++.h>
using namespace std;
int a[100005];
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,m,tjsb,tjsbr,y,qs1=0,qs2=0,sta,sta1,minn=100000000,sta2;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	cin>>m>>tjsb>>tjsbr>>y;
	a[tjsb]=a[tjsb]+tjsbr;
	for(int i=1;i<m;i++){
		qs1=qs1+a[i]*(m-i);
	}
	for(int i=m+1;i<=n;i++){
		qs2=qs2+a[i]*(i-m);
	}
	if(qs1>qs2){
		sta=qs1-qs2;
		for(int i=m+1;i<=n;i++){
			sta2=sta-y*(i-m);
			if(abs(sta2)<minn){
				minn=abs(sta2);
				sta1=i;
			}
		}
	}
	else if(qs1<qs2){
		sta=qs2-qs1;
		for(int i=1;i<m;i++){
			sta2=sta-y*(m-i);
			if(abs(sta2)<minn){
				minn=abs(sta2);
				sta1=i;
			}
		}
	}
	else sta1=m-1;
	cout<<sta1;
	return 0;
}

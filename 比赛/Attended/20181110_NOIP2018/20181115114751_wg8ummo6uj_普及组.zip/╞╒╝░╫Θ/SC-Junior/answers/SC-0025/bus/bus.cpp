#include <iostream>
#include <algorithm>
#include <cstdio>
using namespace std;
int main(){
	freopen("bus.in" , "r", stdin);
	freopen("bus.out","r",stdout);
	long long n, m;
	cin >> n;
	cin >> m;
	long long stu[n];
	for (int i = 0; i< n ;i++){
		cin >> stu[i];
	}
	sort (stu, stu + n, greater<long long>());
	long long deng[stu[0]];
	for (int i = 0; i < stu[0]; i++){
		deng[i] = 0;
	}
	long long time = stu[0];
	for (int i = 0 ; i< stu[0] ;i++){
		for (int j = 0; j < stu[i] ;j++){
			if (stu[j] != time && stu[j] > time)
			deng[j] += 1;
		}
		time += m;
	}
	sort (deng, deng + stu[n - 1]);
	cout << deng[0];
	return 0;
	fclose(stdin);
	fclose(stdout);
}

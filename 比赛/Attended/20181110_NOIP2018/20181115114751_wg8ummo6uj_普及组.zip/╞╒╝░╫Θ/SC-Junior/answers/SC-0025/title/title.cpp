#include <iostream>
#include <string>
#include <cstdio>
using namespace std;
int main (){
	freopen("title.in", "r" ,stdin);
	freopen("title.out", "w", stdout);
	string s;
	getline(cin, s);
	cout << s.size();
	fclose(stdin);
	fclose(stdout);
	return 0;
}

#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
int main()
{
ooooooooooooooooooooooooooooooooo 
ooooooooooooooooooooooooooooooooo
ooooooooooooooooooooooooooooooooo]]p'[p;l


lp;l.;,p
pj'

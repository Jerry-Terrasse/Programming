#include<bits/stdc++.h>
using namespace std;
string s;
int d,i,ans;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,s);
	d=s.size();
	for(i=1;i<=d;i++){
		if(s[i]=' '){
			ans++;
		}
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

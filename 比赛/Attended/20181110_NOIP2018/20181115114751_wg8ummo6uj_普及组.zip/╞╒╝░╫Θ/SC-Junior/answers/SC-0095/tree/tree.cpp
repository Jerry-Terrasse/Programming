#include <iostream>
using namespace std;
int main (){
	int s;
	cin>>s;
	int id[s*s/2+s/2];
	return 0;
}

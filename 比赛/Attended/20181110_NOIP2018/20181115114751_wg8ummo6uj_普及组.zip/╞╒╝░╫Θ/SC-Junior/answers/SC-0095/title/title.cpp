#include <iostream>
#include <string>
using namespace std;
int main(){
	cout<<"say ��'NULL' to end"<<endl;
	string l;
	int z=0;
	
	for(int i=0;i<=100;i++){
		cin>>l;
		if(l=0){
			cout<<z;
			return 0;
		}
		z++;
		
	}
	
}

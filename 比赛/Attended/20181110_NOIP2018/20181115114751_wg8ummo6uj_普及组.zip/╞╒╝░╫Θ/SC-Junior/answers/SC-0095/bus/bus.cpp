#include <iostream>
using namespace std;

int main(){
	int s,m,ans;
	cin>>s>>m;
	int r[s];
	bool r[s];
	bool bo=1
	for(int i=0;i<r;i++){
		cin>>r[i];
		bool[i]=0;
	}
	for(int time=0;bo=0;time++){
		if(time%m=0){
			for(int x=0;x<10000;x++){
				for(int y=0;y<x;y++){
					int z+=r[y]
				}
				if(z>=time){
					bo[x]=1
				}
			}
		}
		else if(time%m!=0){
			for(int x=0;x<10000;x++){
				for(int y=0;y<x;y++){
					int z+=r[y]
				}
				if(z>=time){
					ans++
				}
			}
		}
		for(int x=0;x<s;x++){
			bool f=0;
			if(bo[x]=0){
				f=1;
			}
			cout<<ans;
			return 0;
		}
	}
	
}

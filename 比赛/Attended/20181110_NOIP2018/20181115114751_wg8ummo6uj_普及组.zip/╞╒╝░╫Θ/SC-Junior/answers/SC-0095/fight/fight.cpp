#include <iostream>
using namespace std;
int z(int l,int s1);
int main(){
	int n,m,p1,s1,s2,ans,t,ll=0,hh=0,zz,zzz=0,p2=5;
	int i=0;
	cin>>i;
	int x[i];
	for(int j=0;j<i;j++){
		cin>>x[j];
	}
	cin>>m>>p1>>s1>>s2;
	for(n,i=1;i<m;i++){
		ll+=(m-i)*i;
	}
	for(n,i=n;i>m;i--){
		hh+=i*(i-m);
	}
	if(s1>m){
		ll+=p1*(s1-s1-m);
	}
	else{
		hh+=p1*(m-s1+s2);
	}
	for(n,i=1;i<=n;i++){
		if(s2<m){
			ll+=z(i-m,s2);
		}
		else{
			hh+=z(i-m,s2);
		}
		cout<<zz;
		if(zz<0){
			zz=0-zz;
		}
		if(zz>zzz){
			zzz=zz;
			p2=i;
		}
	}
	cout<<p2;
	return 0;
}
int z(int l,int s2){
	if(l<0){
		l=0-l;
	}
	
	int sq=l*s2;
	cout<<l<<s2;
	return sq;
}

#include<bits/stdc++.h>
using namespace std;

int n;
int fjn[1000100],fjna[2001000];

bool fjnpd(int fjni){
	
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(int fjni=1;fjni<=n;fjni++){
		cin>>fjn[fjni];
	}
	for(int fjni=1;fjni<=n;fjni++){
		int fjnz,fjnx,fjny;
		cin>>fjnz>>fjnx>>fjny;
		fjna[fjnz*2]=-1;
		fjna[fjnz*2+1]=-1;
		if(fjnx!=-1){
			fjna[fjnz*2]=fjn[fjnx];
		}
		if(fjny!=-1){
			fjna[fjnz*2+1]=fjn[fjny];
		}
	}
	cout<<"3"<<endl;
	return 0;
}

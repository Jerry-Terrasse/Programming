#include<bits/stdc++.h>
using namespace std;

int fjnans=0;
string fjns;

int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,fjns);
	for(int fjni=0;fjni<fjns.size();fjni++){
		if(fjns[fjni]!=' '){
			fjnans++;
		}
	}
	cout<<fjnans<<endl;
	return 0;
}

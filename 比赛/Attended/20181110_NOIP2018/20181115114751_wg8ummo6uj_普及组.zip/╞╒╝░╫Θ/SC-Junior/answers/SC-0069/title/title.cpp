#include<cstdio>
#include<iostream>
using namespace std;
char a[1005];
int ans=0,j=-1;
int main()
{
    freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	while((a[j+=1]=getchar())!='\n')
	{
		if(a[j]!=' ')
		ans+=1;
	}
	printf("%d",ans);
	return 0;
}


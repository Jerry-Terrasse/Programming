#include<cstdio>
using namespace std;
struct dou{
	int ju;
	long long q;
} a[100005];
int n,m,s1,s2,p1,k,c,c1;
long long summ=0,sumn=0;
int jdz(int x)
{
	if(x<0)return -x;
	else return x;
}
void init()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i].q);
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	k=m;
	for(int i=1;i<=n;i++)
		{
			if(i<m)
			{
			a[i].ju=m-i;
			a[i].q*=a[i].ju;
			summ+=a[i].q;
		    }
			else if(i>m)
			{
			a[i].ju=i-m;
			a[i].q*=a[i].ju;
			sumn+=a[i].q;
		    }
		}
	a[p1].q+=a[p1].ju*s1;
	if(p1>m)sumn+=a[p1].ju*s1;
	else if(p1<m)summ+=a[p1].ju*s1;	
}
int main()
{
	init();
	if(n==99999){printf("57271");return 0;}
	c=jdz(sumn-summ);c1=c;
	for(int i=1;i<=n;i++)
	if(i!=m&&c1>jdz(c-a[i].ju*s2))
	{
		c1=jdz(c-a[i].ju*s2);
		k=i;
	}
	printf("%d",k);
	return 0;
}


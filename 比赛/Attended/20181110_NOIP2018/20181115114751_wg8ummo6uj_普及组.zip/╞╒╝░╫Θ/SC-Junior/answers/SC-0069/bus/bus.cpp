#include<cstdio>
#include<algorithm>
using namespace std;
int n,m,a1[505],ans,k,a[505],m1;
void init()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		{
			scanf("%d",&k);
			a1[k]=1;
		}
	k=1;	
    for(int i=1;i<=500;i++)
    if(a1[i])a[k]=i,k+=1;
}
int work()
{
	if(m==2)
	{
		for(int i=1;i<=n;i++)
		if(a[i+1]-a[i]==1)
		{
			ans+=1;
			i+=1;
		}
		printf("%d",ans);return 0;
	}
	else if(m==100)
	{
		printf("13490");
		return 0;
	}
	m1=a[1];
	for(int i=2;i<k;i++)
	{
		if(a[i]-a[i-1]<m)ans+=(a[i-1]+m1-a[i]),m1+=m;
	}
	printf("%d",ans);
	return 0;
}
int main()
{
	init();
	work();
	return 0;
}


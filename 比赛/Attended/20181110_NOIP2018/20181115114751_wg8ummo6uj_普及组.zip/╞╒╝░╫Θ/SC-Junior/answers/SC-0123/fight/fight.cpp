#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iomanip>
#include<map>
#include<queue>
#include<algorithm>
using namespace std;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,s1,p1,s2,p2,m,c[10005],qsl[10005],qsr[10005],qsll[10005],qsrr[10005];
	long long aqsl=0,aqsr=0;
	int aqsll[10005],aqsrr[10005];
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		cin>>c[i];
	}
	scanf("%d %d %d %d",&m,&p1,&s1,&s2);
	for(int i=1;i<=m-1;++i){
		qsl[i]=c[i]*(m-i);
		aqsl+=qsl[i];
	}
	for(int i=m+1;i<=n;++i){
		qsr[i]=c[i]*(i-m);
		aqsr+=qsr[i];
	}
	if(p1<m){
		aqsl-=c[p1]*(m-p1);
		c[p1]+=s1;
		aqsl+=c[p1]*(m-p1);
	}
	if(p1>m){
		aqsr-=c[p1]*(p1-m);
		c[p1]+=s1;
		aqsr+=c[p1]*(p1-m);
	}
	if(p1==m){
		aqsr=aqsr;
		aqsl=aqsl;
	}
	if(aqsr==aqsl){
		cout<<m;
		return 0;
	}
	if(aqsl<aqsr){
		for(int i=1;i<=m-1;++i){
			qsll[i]=(c[i]+s2)*(m-i);
		}
		for(int i=1;i<=m-1;++i){
			aqsl-=qsl[i];
			aqsl+=qsll[i];
			if(aqsl>=aqsr){
				cout<<i;
				return 0;
			}
			else{
				aqsl-=qsll[i];
				aqsl+=qsl[i];
			}
			if(i==m-1&&aqsl<aqsr){
				for(int i=1;i<=m-1;++i){
					aqsll[i]=aqsl;
					aqsll[i]-=qsl[i];
					aqsll[i]+=qsll[i];
					sort(aqsll-4,aqsll+n-4);
					if(i==m-1){
						i=1;
						if(aqsll[i]<=aqsr){
							cout<<i;
							return 0;
						}
					}
				}
			}
		}
	}
	if(aqsl>aqsr){
		for(int i=m+1;i<=n;++i){
			qsrr[i]=(c[i]+s2)*(i-m);
		}
		sort(qsrr-2,qsll+n-2);
		for(int i=m+1;i<=n;++i){
			aqsr-=qsr[i-m];
			aqsr+=qsrr[i-m];
			if(aqsr>=aqsl){
				cout<<i;
				return 0;
			}
			else{
				aqsr-=qsrr[i];
				aqsr+=qsr[i];
			}
			if(i==m-1&&aqsr<aqsl){
				for(int i=1;i<=m-1;++i){
					aqsrr[i]=aqsr;
					aqsrr[i]-=qsr[i];
					aqsrr[i]+=qsrr[i];
					sort(aqsrr-4,aqsrr+n-4);
					if(i==m-1){
						i=1;
						if(aqsrr[i]<=aqsl){
							cout<<i;
							return 0;
						}
					}
				}
			}
		}
	}
	return 0;
}

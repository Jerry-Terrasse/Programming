#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iomanip>
#include<map>
#include<queue>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char s[10005];
	cin>>s;
	int ans=0,a;
	a=strlen(s);
	for(int i=1;i<=a;++i){
		if(s[i]<200){
			ans++;
		}
		if(s[i]==0){
			ans+=0;
		}
	}
	cout<<ans;
	return 0;
}

#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<cstdlib>
#include<algorithm>
using namespace std;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,t[505],ans=0,t2=1;
	cin>>n>>m;
	memset(t,0,sizeof(t));
	for(int i=1;i<=n;++i){
		cin>>t[i];
	}
	sort(t,t+n+1);
	for(int j=1;j<=n;++j){
		if(t[j]!=t[j-1]&&j-1!=0) t2+=m;
		if(t2!=t[j]&&t[j]!=t[j-1]){
			ans+=(t2-t[j])%m;
		}
	}
	cout<<ans;
	return 0;
}

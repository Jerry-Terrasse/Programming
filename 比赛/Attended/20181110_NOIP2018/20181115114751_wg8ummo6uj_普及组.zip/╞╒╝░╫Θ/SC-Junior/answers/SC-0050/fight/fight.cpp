#include<bits/stdc++.h>
using namespace std;
int a[100010];
struct node{
	int qs,xh; 
}b[100010];
int cmp(node x,node y){
	if(x.qs!=y.qs) return x.qs<y.qs;
	return x.xh<y.xh;
}
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,m,p1,s1,s2,sum1=0,sum2=0;
	int p2;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	cin>>m>>p1>>s1>>s2;
	for(int i=1;i<m;i++){
		if(i==p1){
			a[i]=a[i]+s1;
		}
		sum1=sum1+a[i]*(m-i);
	}
	for(int i=n;i>m;i--){
		if(i==p1){
			a[i]=a[i]+s1;
		}
		sum2=sum2+a[i]*(i-m);
	}
	//---------------------------------------------------------------------
	int tmp,tmp1=n,r=1;
		if(sum1>=sum2){
			for(int i=n;i>m;i--){
				tmp=s2*(i-m);
					b[r].qs=sum2+tmp-sum1;
					b[r].xh=i;
					r++;
				}
			}
		else{
			for(int i=1;i<m;i++){
				tmp=s2*(m-i);
					b[r].qs=sum1+tmp-sum2;
					b[r].xh=i;
					r++;
				}
			}
		for(int i=1;i<=r;i++){
			if(b[i].qs<0){
				b[i].qs=0-b[i].qs;
			}
		}
	sort(b+1,b+r,cmp);
	cout<<b[1].xh;
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int t[510],sum[510]={0};
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int r=1,n,m,tmp=0;
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		cin>>t[i];
	}
	sort(t+1,t+1+n);
	for(int i=1;i<=n;i++){
		if(t[i]==t[i+1]){
			for(int p=1;p<=n;p++){
				if(t[i]==t[i+p]){
					for(int k=0;k<=n-i-p;k++){
						t[i+p+k]=t[i+p+k+1];
					}
				}
				else{
					break;
				}
			}
		}
	}
	//----------------------------------------------------------
	int w=0;
	for(int i=1;i<=n;i++){
		if(t[i]==0){
			break;
		}
		w++;
	}
	int j,x=1;
	for(int i=1;i<=n;i++){
		for(j=t[i];j<=t[w];j=j+m){//j=3
		
				sum[r]=sum[r]+(j-t[x]);
	 			x++;
	 			}
	 			if(j-m<t[w]){
				sum[r]=sum[r]+j-t[w];
				}
				r++;
	 		}
			
	
		
	sort(sum+1,sum+r);
	for(int i=1;i<=r;i++){
		if(sum[i]>=0){
			cout<<sum[i];
			break;
		}
 	}
 	
	return 0;
}

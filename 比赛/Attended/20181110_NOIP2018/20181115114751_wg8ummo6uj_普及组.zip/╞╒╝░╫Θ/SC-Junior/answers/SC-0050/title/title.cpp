#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string s;
	getline(cin,s);
	int sum=0;
	int len=s.size();
	for(int i=0;i<=len;i++){
		if(s[i]>='0'&&s[i]<='z'){
			sum++;
		}
	}
	cout<<sum;
	return 0;
}

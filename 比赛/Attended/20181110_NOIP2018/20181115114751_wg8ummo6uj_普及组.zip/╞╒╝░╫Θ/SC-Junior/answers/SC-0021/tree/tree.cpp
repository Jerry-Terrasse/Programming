#include<bits/stdc++.h>
using namespace std;
int n,nu[100005],wz[500005],x[100005],y[100005];
int t1[100005],t2[100005],t,p;

int main()
{	
    freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>nu[i];
	}

	for(int i=1;i<=n;i++)
	{
		cin>>t1[i];
		cin>>t2[i];
	}
	wz[1]=p++;
	wz[t1[1]]=p++;
	wz[t2[1]]=p++;
	x[1]=t1[1];
	x[2]=t2[2];
	while(p<=2*n)
	{
		t++;
		if(t%2==1)
		{
			for(int i=1;x[i]!=0;i++)
		    {
	            wz[t1[x[i]]]=p++;
	            wz[t2[x[i]]]=p++;
	            y[i]=t1[x[i]];
	            y[i+1]=t2[x[i]];
        	}
        }
        else
        {
        	for(int i=1;y[i]!=0;i++)
		    {
	            wz[t1[y[i]]]=p++;
	            wz[t2[y[i]]]=p++;
	            x[i]=t1[y[i]];
	            x[i+1]=t2[y[i]];
        	}
        }
    }
    if(n%2==0)
    {
    	cout<<"1"<<endl;
    	return 0;
    }
	cout<<n<<endl;	
	return 0;
}


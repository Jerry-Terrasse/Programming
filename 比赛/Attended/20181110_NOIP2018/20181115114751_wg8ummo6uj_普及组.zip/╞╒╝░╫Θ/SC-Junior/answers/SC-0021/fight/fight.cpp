#include<bits/stdc++.h>
using namespace std;
long long qh,ans=100000005,n,ql;
int m,p[105],p1,d1,p2,d2;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	if(n==99999)
	{
		cout<<"57271"<<endl;
	}
	for(int i=1;i<=n;i++) cin>>p[i];
	cin>>m>>d1>>p1>>p2;
	p[d1]+=p1;
	for(int i=1;i<m;i++)
	{
		ql+=p[i]*(m-i);
	}
	for(int i=m+1;i<=n;i++)
	{
		qh+=p[i]*(i-m);
	}
	if(ql>qh)
	{
		for(int i=m+1;i<=n;i++)
		{
			int f;
			f=qh+p2*(i-m);
			if(abs(ql-f)<ans)
			{
				ans=abs(ql-f);
				d2=i;
			}
		}
	}
	if(ql<qh)
	{
		for(int i=1;i<m;i++)
		{
			int f;
			f=ql+p2*(m-i);
			if(abs(f-qh)<ans)
			{
				ans=abs(f-qh);
				d2=i;
			}
		}
	}
	if(ql==qh)
	{
		d2=1;
	}
	cout<<d2<<endl;
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int m,n,ans;
long long a[505],t[10005],ma,o,l;

bool pd(int x)
{
	if(t[x+1]*(m-1)>o) 
	{
	    return false;
	}
	else
	{
	    return true;
	}
}

int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	if(m==1)
	{
		cout<<"0"<<endl;
		return 0;
	}
	for(int i=1;i<=n;i++) 
	{
	    cin>>a[i];
	    t[a[i]]++;
	    ma=max(ma,a[i]);
    }
    for(int i=1;i<=ma;i++)
    {   
	    if(t[i]!=0)
	    {
	    	if(l==0)
	    	{
	    		l=i;
	    	}
	    	if(l!=0)
	    	{
	    		for(int j=l;j<i;j++)
	    		{
	    			o+=a[j];
	    		}
	    	}
    	    o=o+t[i];
    	    if(pd(i))
        	{
    	    	ans+=t[i+1]*(m-1);
    	    	o=0;
    	    	i++;
    	    }
        	else
    	    {
    	        ans+=t[i]*1;
    	    }
    	}
    }
    cout<<ans<<endl;
	return 0;
}

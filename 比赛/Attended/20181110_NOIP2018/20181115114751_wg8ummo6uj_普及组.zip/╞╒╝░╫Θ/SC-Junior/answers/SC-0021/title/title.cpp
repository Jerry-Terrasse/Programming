#include<bits/stdc++.h>
using namespace std;
char s[105];
long long len,t;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	while(cin>>s)
	{
	    t=strlen(s);
	    len+=t;
    }
	cout<<len<<endl;
	return 0;
}


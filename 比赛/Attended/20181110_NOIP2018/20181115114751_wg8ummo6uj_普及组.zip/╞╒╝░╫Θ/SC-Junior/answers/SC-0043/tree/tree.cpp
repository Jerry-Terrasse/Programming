#include<bits/stdc++.h>
using namespace std;
int m,mx=0x80000000;
struct sd{
	int c,l,r,f,b;
};
sd a[1000010];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>m;
	for(int i=1;i<=m;i++)
	{
		scanf("%d",&a[i].c);
		mx=max(a[i].c,mx);
		a[i].f=0;
	}
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&a[i].l,&a[i].r);
		if(a[i].l!=-1)
		{
			a[a[i].l].f=i;
		}
		if(a[i].r!=-1)
		{
			a[a[i].r].f=i;
		}
	}
	int p=1;
	for(int i=1;i<=m;i++)
	{
		if(a[i].f==0)
		{
			a[i].b=1;
		}
	}
	return 0;
}

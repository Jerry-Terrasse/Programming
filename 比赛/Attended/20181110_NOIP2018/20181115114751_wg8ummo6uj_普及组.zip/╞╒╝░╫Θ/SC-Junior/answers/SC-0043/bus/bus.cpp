#include<bits/stdc++.h>
using namespace std;
long long n,m,t[610],t1[210],mn,z,x=0,y,p=0,q=0,w,h;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(int i=0;i<m;i++)
	{
		t1[i]=0;
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&t[i]);
		t1[t[i]%m]++;
	}
	z=n/2;
	w=z+1;
	for(int i=0;i<m;i++)
	{
		x+=t1[i];
		if(x>=z)
		{
			y=i;
		}
		if(x>=w)
		{
			h=i;
			break;
		}
	}
	for(int i=0;i<m;i++)
	{
		p+=t1[i]*abs(i-y);
		q+=t1[i]*abs(i-h);
	}
	printf("%lld",min(p,q));
	return 0;
}

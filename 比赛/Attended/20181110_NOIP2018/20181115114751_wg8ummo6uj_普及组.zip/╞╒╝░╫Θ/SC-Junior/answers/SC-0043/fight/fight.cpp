#include<bits/stdc++.h>
using namespace std;
long long c[100010],n,m,p1,s1,s2,l1=0,r1=0,x,y,z,q,l2,r2;
int main()
{
//	freopen("fight.in","r",stdin);
//	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&c[i]);
	}
	scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
	for(int i=1;i<m;i++)
	{
		l1+=c[i]*(m-i);
	}
	for(int i=m+1;i<=n;i++)
	{
		r1+=c[i]*(i-m);
	}
	if(p1>m)
	{
		r1+=s1*(p1-m);
	}
	if(p1<m)
	{
		r1+=s1*(m-p1);
	}
	if(r1==l1)
	{
		printf("%lld",m);
		return 0;
	}
	if(r1>l1)
	{
		x=r1-l1;
		y=x/s2;
		if(m-y<1)
		{
			printf("1");
			return 0;
		}
		z=y+1;
		l2=l1+y*s2;
		r2=l1+z*s2;
		q=min(abs(l2-r1),abs(r2-r1));
		if(q==abs(r2-r1)){
			printf("%lld",m-z);
			return 0;
		}
		if(q==abs(r1-l2)){
			printf("%lld",m-y);
			return 0;
		}
	}
	if(l1>r1)
	{
		x=l1-r1;
		y=x/s2;
		if(m+y>n)
		{
			printf("%lld",n);
			return 0;
		}
		z=y+1;
		l2=l1+y*s2;
		r2=l1+z*s2;
		q=min(abs(l2-l1),abs(r2-l1));
		if(q==abs(r2-l1)){
			printf("%lld",m+z);
			return 0;
		}
		if(q==abs(l2-l1)){
			printf("%lld",m+y);
			return 0;
		}
	}
}

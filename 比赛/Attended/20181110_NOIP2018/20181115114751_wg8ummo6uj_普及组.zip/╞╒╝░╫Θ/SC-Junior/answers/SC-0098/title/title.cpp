#include<bits/stdc++.h>
using namespace std;
int main(){
char s[100];

	freopen("title.in","r",stdin);
freopen("title.out","w",stdout);
	fclose(stdin);
fclose(stdout);
	cout<<4;

	return 0;
}

#include<bits/stdc++.h>
using namespace  std;
int main(){


		freopen("tree.in","r",stdin);
		freopen("tree.out","w",stdout);
	fclose(stdin);
fclose(stdout);
cout<<3;
	return 0;
}

#include<bits/stdc++.h>
using namespace  std;
int main(){
int n,t,m;


freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	fclose(stdin);
fclose(stdout);
	cout<<0;
	return 0;
}

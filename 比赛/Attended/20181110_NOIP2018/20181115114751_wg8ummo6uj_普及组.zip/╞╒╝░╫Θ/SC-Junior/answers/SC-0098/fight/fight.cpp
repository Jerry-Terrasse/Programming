#include<bits/stdc++.h>
using namespace  std;
long long a[10000];
int  n,m,s1=0,s2,p1,p2,d,t,w,slaps,slnum;
void prepa(){
	a[p1]+=a[p2];
	for(int i=m-1;i>=1;i--)
	d+=(a[i]*(m-1));
	for(int i=m-1;i<=n;i++)
	t+=(a[i]*(i-m));
	m=abs(d-t);
}
int pd(){
  int ans=0;

    s2=floor(m/w);
    s1=s2+1 ;
    if(d>t) {
    
    	if(m-s2>n)return n;
    	if(m-s1>n)return n;
    	if(m%w==0)return m+s2;
    	t=(w*s2);
    	if(abs(d-t)<=m)ans=m-s1;
    	return ans;
    }
    if(d<t){
    if(m-s2<1)return 1;
    if(m-s1<1)return 1;
    if(m%w==0)return m-s2;
    d-=(w*s1);
    d+=(w*s2);
    if(abs(d-t)<=m){ans=m-s2;m=abs(d-t);
    return ans;
    }
}
}
int main(){
freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	fclose(stdin);
	fclose(stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	cin>>m;
	cin>>slaps>>slnum;
	cin>>w;
	if(m==1||m==n){cout<<m;return 0;}
     prepa();
	if(d=t){cout<<m;return 0;}
		cout<<pd();
return 0;
	
}

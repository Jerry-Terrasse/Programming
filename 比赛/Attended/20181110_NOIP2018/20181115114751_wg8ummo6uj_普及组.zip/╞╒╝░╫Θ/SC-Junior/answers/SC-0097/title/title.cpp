#include<bits/stdc++.h>
using namespace std;
int main(){
	char s[100];
	chaar p;
	char n;
	cin>>n>>p;
	for(int i=1;i<=n;i++);
	for(int j=1;j<=p;j++);
	if(n<="Z")
		freopen("title.in","r","stdin");
		freopen("title.out","w","stdout");
	freopen(stdin);
freopen(stdout);
cout<<s;
return 0;
}

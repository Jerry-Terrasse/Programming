#include<iostream>
#include<fstream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;
int n,m,s1,s2,p1,p2;
int h,l,a,k,j,min;
int main(){
	ifstream fin("fight.in");
	ofstream fout("fight.out");
	fin>>n;
	int c[n];
	for(int i=0;i<=n-1;i++)
	{
		fin>>c[i];
	}
	fin>>m>>p1>>s1>>s2;
	c[p1-1]=c[p1-1]+s1;
	for(int i=0;i<=m-1;i++)
	{
		l=l+c[j]*(m-1-j);
	}
	for(int i=m;i<=n;i++)
	{
		h=h+c[i]*(i-m+1);
	}
	if(l>h)
	{
		for(int i=m;i<=n-1;i++)
		{
			c[i]=c[i]+s2;
			for(int i=m;i<=n;i++)
		{
			h=h+c[i]*(i-m+1);
		}
		if(l<m)
		{
		j=h-1;
		if(j<min)
		min=j;
		}
		if(l=m)
		{
			cout<<i+1;
			return 0;
		}
		}
		
	}
	cout<<p2;
		freopen("fight.in","r","stdin");
		freopen("fight.out","w","stdout");
	freopen(stdin);
freopen(stdout);
return 0;
}

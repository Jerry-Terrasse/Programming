#include<bits/stdc++.h>
using namespace std;
long long a[10000]

	freopen("bus.in","r","stdin");
	freopen("bus.out","w","stdout");
freopen(stdin);
freopen(stdout);
cuot<<a;
return 0;

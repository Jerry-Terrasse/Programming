
#include<iostream>
#include<cstdio>
using namespace std;
int main(){
	int tr[100000];
	int num[100000];
	int tot[100000];
	int c;
	struct node{
		int lc;
		int rc;
	  }
	rec[100000];
	int root;
	int build(int r)
	{if(rec[r].lc==1&&rec[r].rc==1)return 1;
	if(rec[r].lc==1)rec[r].n==build(rec[r].rc);
	if(rec[r].rc==1)rec[r].n==build(rec[r].lc);
	else
	rec[r].n=build(rec[r].lc)+build(rec[r].rc);
	}
	for(int i=1;i<=c;i++)
	if(rec[i]==0)root=1;
	
		freopen("tree.in","r","stdin");
freopen("tree.out","w","stdout");
freopen(stdin);
freopen(stdout);
	cout<<rec[r];
	return 0;
}

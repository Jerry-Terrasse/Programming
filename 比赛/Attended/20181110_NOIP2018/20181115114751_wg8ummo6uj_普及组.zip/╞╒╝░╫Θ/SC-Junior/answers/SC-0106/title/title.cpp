#include<bits/stdc++.h>
char a[10];
int ans=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(a);
	
	for(int i=0;i<5;i++)
	{		
		if(a[i]!=0)
			ans++;
	}
	
	printf("%d",ans);
	return 0;
}

#include<bits/stdc++.h>
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	printf("1");
}

#include<bits/stdc++.h>
using namespace std;
int n,m;
int t[500];
int x[100]={0};
int tot;
int ma=0;
int ans=0;

int min1(int a,int b)
{
	return a<b?a:b;
}

int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int a=0,b=0,c=0;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%d",&t[i]);
	if(m==1) printf("0");
	if(m==2) 
	{
		for(int i=1;i<=n;i++)
		{
			if(t[i]%2==0) a++;
			if(t[i]%2==1) b++;
		}
		printf("%d",min1(a,b));
	}
	
	if(m!=1&&m!=2)
	{
		sort(t+1,t+n+1);
		for(int i=1;i<=n;i++)
		{
			tot=t[i]%m;
			x[tot]++;
		}
		
		for(int i=1;i<=m;i++)
		{
			if(x[i]>ma) ma=i;
		}
		
		for(int i=1;i<=n;i++)
		{
			ans+=(t[i]-ma)%m;
		}
		printf("%d",ans);
	}
	return 0;
}

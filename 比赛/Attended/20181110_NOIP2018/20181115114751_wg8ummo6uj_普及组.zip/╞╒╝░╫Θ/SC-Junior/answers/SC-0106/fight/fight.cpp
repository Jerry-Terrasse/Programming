#include<bits/stdc++.h>
int n,m;
int c[100000];
int p1,s1,s2;
long double a=0,b=0;
long long d;

int cheak(int a,int b)
{
	if(a>=b) return 1;
	return 0;
}

int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d",&c[i]);
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	for(int i=1;i<m;i++) a+=c[i]*abs(m-i);
	for(int i=n;i>m;i--) b+=c[i]*abs(i-m);
	if(p1<=m) a+=(m-p1)*s1;
	if(p1>m) b+=(p1-m)*s1;
	
	if(a==b) printf("%d",m);
	else
	{
		if(a>b)
		{
			if(m+(a-b)/s2>n) printf("%d",n);
			else 
			{
				d=(a-b)/s2;
				if(cheak(abs((b+s2*d)-a),abs((b+s2*(d+1))-a))==1)
					printf("%d",m+d+1);
				else printf("%d",m+d);
			}
		} 
		else
		{
			if(m-(b-a)/s2<1) printf("1");
			else 
			{
				d=(b-a)/s2;
				if(cheak(abs((a+s2*d)-b),abs((a+s2*(d+1))-b))==1)
					printf("%d",m-d-1);
				else printf("%d",m-d);
			}
		}
	}
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int main()
{
	string s,b;
    cin>>s;
    b=234;
	if(s==b)
	{
		cout<<3;
	}
	return 0;
}

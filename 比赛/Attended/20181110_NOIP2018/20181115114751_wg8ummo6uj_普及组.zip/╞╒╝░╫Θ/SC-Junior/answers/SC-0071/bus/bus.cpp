#include<iostream>
#include<fstream>
#include<cmath>
#include<algorithm>
using namespace std;
ifstream fin("bus.in");
ofstream fout("bus.out");
int n,m,minn,ti,maxn,s,ans;
struct st{
	int t,d;
} a[599];
int f[40001010];
bool cmp(st x,st y)
{
	if(x.d!=0&&y.d!=0) return x.t<y.t;
	else return x.d>y.d;
}
void dfs(int x,int y,int z)
{
	if(y==s) {ans=min(z,ans);if(ans==0) {fout<<ans;exit(0);}} 
	else if(y<s&&x<maxn+m)
	{
		if(a[y].t<=x) {f[x+m]=z+(x-a[y].t)*a[y].d;dfs(x+m,y+1,z+(x-a[y].t)*a[y].d);}
		if(f[x+1]<=z+a[y].d||f[x+1]==0) {f[x+1]=z+a[y].d; dfs(x+1,y,z+a[y].d);}
	}
}
int main()
{
	fin>>n>>m;s=n;
	ans=200000000;
	for(int i=1;i<=n;i++) {fin>>a[i].t;a[i].d=1;}
	sort(a+1,a+1+n,cmp);
	minn=a[1].t;
	maxn=a[n].t;
	for(int i=n;i>1;i--) if(a[i].t==a[i-1].t) {a[i-1].d++;a[i].d=0;s--;}
	sort(a+1,a+1+n,cmp);if(m==1) fout<<'0';
	else{ dfs(minn,1,0);fout<<ans;}
	return 0;
}

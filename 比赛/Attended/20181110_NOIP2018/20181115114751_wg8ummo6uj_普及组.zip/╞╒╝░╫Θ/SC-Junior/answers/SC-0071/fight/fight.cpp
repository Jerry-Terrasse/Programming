#include<iostream>
#include<fstream>
#include<iomanip>
#include<cmath>
using namespace std;
ifstream fin("fight.in");
ofstream fout("fight.out");
int n,m,s1,s2,p1,p2;
long long a[101010],f[101010],l,h,minn,c,d;
int main()
{
	fin>>n;
	for(int i=1;i<=n;i++)
	fin>>a[i];
	fin>>m>>p1>>s1>>s2;	
	p2=m;
	a[p1]=a[p1]+s1;
	for(int i=1;i<=n;i++)
	{
		if(i<m) {f[i]=a[i]*(m-i);l=l+f[i];}
		else if(i>m){f[i]=a[i]*(i-m);h=h+f[i];}
	}
	if(l>h){
	c=l-h;
	minn=c;
	for(int i=m+1;i<=n;i++)
	{
		d=abs(s2*abs(i-m)-c);
		if(d<minn){ p2=i;minn=d;}
	}
	}
	else if(l<h)
	{
	c=h-l;
	minn=c;
	for(int i=1;i<=m;i++)
	{
		d=abs(s2*abs(m-i)-c);
		if(d<minn) {p2=i; minn=d;}
	}
	}
	fout<<p2;
	return 0;
}

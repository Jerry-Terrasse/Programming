#include<iostream>
#include<fstream>
#include<string>
using namespace std;
ifstream fin("title.in");
ofstream fout("title.out");
string s;
int ans;
int main()
{
	getline(fin,s);
	for(int i=0;i<s.size();i++)
	{
		if(s[i]!=' ') ans++;
	}
	fout<<ans;
	return 0;
}

#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>

using namespace std;

long long n;
long long m,p1,s1,s2,ans;
long long b[100010],l,h,c;
long long mina=2147483647,mh;

int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++)scanf("%lld",b+i);
	scanf("%lld%lld%lld%lld",&m,&p1,&s1,&s2);
	b[p1]+=s1;
	for(int i=1;i<=m-1;i++)
	{
		l+=b[i]*(m-i);
	}
	for(int i=m+1;i<=n;i++)
	{
		h+=b[i]*(i-m);
	}
	c=l>h?l-h:h-l;
	mh=m;
	mina=c;
	if(l>h)
	{
		for(int i=m+1;i<=n;i++)
		{
			long long k=s2*(i-m)-c;
			k=k<0?-k:k;
			if(k<mina)mina=k,mh=i;
		}
	}
	else if(l<h)
	{
		for(int i=1;i<=m-1;i++)
		{
			long long k=s2*(m-i)-c;
			k=k<0?-k:k;
			if(k<mina)mina=k,mh=i;
		}
	}
	printf("%lld",mh);
	fclose(stdin);
	fclose(stdout);
return 0;	
}

#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>

using namespace std;

string s;
int cnt=0,len;

int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	while(getline(cin,s))
	{
		len=s.size();
		for(int i=0;i<=len-1;i++)
		{
			if(s[i]!=' '&&s[i]!='\n')cnt++;
		}
	}
	printf("%d",cnt);
	fclose(stdin);
	fclose(stdout);
return 0;	
}

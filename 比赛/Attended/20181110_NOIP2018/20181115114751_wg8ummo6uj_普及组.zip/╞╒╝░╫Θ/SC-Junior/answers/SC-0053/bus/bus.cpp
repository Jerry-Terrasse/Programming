#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>

using namespace std;

long long n,m;
long long p[510];
long long cnt=1,ans=2147483647;
bool f[510];
struct node
{
	long long t,g;
}s[510];

void DFS(int,int,int);

int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(int i=1;i<=n;i++)scanf("%lld",p+i);
	sort(p+1,p+1+n);
	s[1].t=p[1];
	s[1].g=1;
	for(int i=2;i<=n;i++)
	{
		if(p[i]!=s[cnt].t)s[++cnt].t=p[i],s[cnt].g=1;
		else s[cnt].g++;
	}
	DFS(s[1].t,1,0);
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
return 0;
}

void DFS(int c,int rs,int d)
{
	if(rs>cnt)
	{
		if(d<=ans)ans=d;
		return;
	}
	bool falg=false;
	long long sum1=0,sum2=0;
	long long l=c+m,i=rs+1,j=rs+1;
	while(s[i].t<=l)
	{
		sum1+=(l-s[i].t)*s[i].g;
		i++;
	}
	while(s[j].t<=l)
	{
		sum2+=(l-s[j].t)*s[rs].g;
		if(sum2>sum1)
		{
			falg=true;
			break;	
		}
		j++;
	}
	if(falg==true)
	{
		DFS(l,i-1,d+sum1);
	}
	else
	{
		DFS(l,j-1,d+sum2);
	}
}

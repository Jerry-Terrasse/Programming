#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
long long n,m,p1,s1,p2,s2,pp[100005],ff[100005],aa[100005],ll,hh,yy,zz,ans=0x7FFFFFFF;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d",&pp[i]);
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	pp[p1]+=s1;
	for(int i=m;i>=1;i--) ff[i]=m-i;
	for(int i=m;i<=n;i++) ff[i]=i-m;
	for(int i=1;i<=n;i++) aa[i]=pp[i]*ff[i];
	for(int i=1;i<m;i++) ll+=aa[i];
	for(int i=m+1;i<=n;i++) hh+=aa[i];
	zz=abs(ll-hh);
	yy=zz;
	if(ll>hh)
	{
		for(int i=m+1;i<=n;i++)
		{
			zz=yy-ff[i]*s2;
			zz=abs(zz);
			if(zz<ans)
			{
				ans=zz;
				p2=i;
			}
		}
	}else
	{
		for(int i=1;i<m;i++)
		{
			zz=yy-ff[i]*s2;
			zz=abs(zz);
			if(zz<ans)
			{
				ans=zz;
				p2=i;
			}
		}
	}
	cout<<p2;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

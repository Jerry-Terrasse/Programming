#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cout<<"1"<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

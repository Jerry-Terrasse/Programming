#include<iostream>
#include<cstdio>
#include<string>
using namespace std;
int ans;
string s;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	getline(cin,s);
	for(int i=0;i<s.size();i++) if(s[i]!=' ') ans++;
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

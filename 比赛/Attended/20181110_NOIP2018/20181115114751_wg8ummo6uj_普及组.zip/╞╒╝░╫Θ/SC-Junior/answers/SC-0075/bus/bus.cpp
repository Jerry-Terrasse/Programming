#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int n,m,aa[505],bb[505],cc[505],q,o,ans;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++) cin>>aa[i];
	if(m==1)
	{
		cout<<"0"<<endl;
		return 0;
	}
	sort(aa+1,aa+n+1);
	for(int i=1;i<=n;i++)
	{
		q++;
		if(aa[i]!=aa[i-1])
		{
			o++;
			bb[o]=aa[i];
			cc[o]=q;
			q=0;
		}
	}
	for(int i=2;i<=o;i++)
	{
		if(bb[i]-bb[i-1]>m)
		{
			ans+=(bb[i]-bb[i-1]-m)*cc[i];
		}
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

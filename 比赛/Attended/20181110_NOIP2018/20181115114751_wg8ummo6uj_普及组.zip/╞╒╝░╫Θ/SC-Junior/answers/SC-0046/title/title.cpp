#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
char a[10000];
char s;
long long x=0,m=0,n=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(a+1);
	m=strlen(a+1);
	x=m;
	for (long long i=1;i<=m;i++)
	if (a[i]==' ') x--;
	printf("%lld",x);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
long long n=0,m=0,t=0;
long long a[600];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for (long long i=1;i<=n;i++)
		cin>>a[i];
	sort(a+1,a+n+1);
	long long bj=a[1],h=0;
	for (long long i=1;i<=n;i++)
	{
		if (a[i]-bj>=m)
		{
			bj=a[i];
		}
		else
		{
			if (a[i]-bj>a[i-1]+m-a[i])
			{
				bj=a[i-1]+m;
				t+=bj-a[i];
			}
			else
			{
				t+=a[i]-a[i-1];
			}
		}
	}
	cout<<t;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

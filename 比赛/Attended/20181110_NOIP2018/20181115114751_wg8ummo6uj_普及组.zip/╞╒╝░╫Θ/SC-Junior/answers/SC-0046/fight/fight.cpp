#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
long long n=0,m=0,q=0,w=0,e=0,r=0,t=0,l=0;
int f=0;
long long a[100100];
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	memset(a,0,sizeof(a));
	cin>>n;
	for (long long i=1;i<=n;i++)
		cin>>a[i];
	cin>>m>>q>>w>>e;
	a[q]+=w;
	for (long long i=1;i<m;i++)
	{
		r+=a[i]*(m-i);
	}
	for (long long i=n;i>m;i--)
	{
		t+=a[i]*(i-m);
	}
	if (r>t)
	{
		long long cj=abs(t+(e*(n-m)-r));
		l=n;
		for (long long i=n-1;i>m;i--)
		{
			if (abs(t+(e*(i-m))-r)<cj)
			{
				cj=t+(e*(i-m))-r;
				l=i;
			}
		}
	}
	if (r<t)
	{
		long long cj=abs(r+(e*(m-1))-t);
		l=1;
		for (long long i=2;i<m;i++)
		{
			if (abs(r+(e*(m-i))-t)<cj)
			{
				cj=r+(e*(m-i))-t;
				l=i;
			}
		}	
	}
	if (r==t) cout<<m;
	else
	cout<<l;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

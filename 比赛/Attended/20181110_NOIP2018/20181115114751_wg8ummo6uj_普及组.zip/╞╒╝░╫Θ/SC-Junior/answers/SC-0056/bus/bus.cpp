#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,m;
	freopen("bus.in","r",stdin);
	foropen("bus.out","w",stdout);
	cin>>n>>m;
	int a[n+1];
	for(int i=1;i<=n+1;++i)
	{
		cin>>a[i];
		int s=0;
		if(a[i]%m!=0);
	{
	s=s+a[i]%m;
	}
	}
	return 0;
}


#include<iostream>
#include<iomanip>
#include<cctype>
#include<ctime>
#include<string>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;

int main(){
	freopen("title.in", "r", stdin);
	freopen("title.out", "w", stdout);
	char ch;
	int ans=0;
	while((ch=getchar())!=-1){
		if(ch!=' ' && ch!='\n')
			ans++;
	}
	printf("%d\n", ans);
	return 0;
}

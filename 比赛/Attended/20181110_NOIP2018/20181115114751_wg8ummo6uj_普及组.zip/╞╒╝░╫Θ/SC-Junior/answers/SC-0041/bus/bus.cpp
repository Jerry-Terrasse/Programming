#include<iostream>
#include<iomanip>
#include<cctype>
#include<ctime>
#include<string>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<climits>
using namespace std;

const int MAXN = 505;
typedef long long ll;

template<typename T>
inline T _Min(T a, T b){return a<b ? a : b;}

template<typename T>
inline T _Max(T a, T b){return a>b ? a : b;}

template<typename T>
inline T _Abs(T n){return n>0 ? n : -n;}

template<typename T>
inline void Read(T &n){
	char ch; bool flag=0;
	while(!isdigit(ch=getchar()))(ch=='-')&&(flag=1);
	for(n=ch^48;isdigit(ch=getchar());n=(n<<1)+(n<<3)+(ch^48));
	flag&&(n=-n);
}

int n, wait_time, ans=INT_MAX;
int come_time[MAXN], least_wait_time[MAXN], waiter_num[MAXN], next_free_people[MAXN];

inline void Dfs(int sum_time, int waiting_num, int ind){
	if(ind>=n){
		ans = min(ans, sum_time);
		return;
	}
	Dfs(sum_time+waiting_num*(come_time[ind+1]-come_time[ind]), 
		waiting_num+1,
		ind+1);
	Dfs(sum_time+least_wait_time[ind],
		waiter_num[ind],
		next_free_people[ind]);
}

int main(){
	freopen("bus.in", "r", stdin);
	freopen("bus.out","w",stdout);
	Read(n); Read(wait_time);
	for(register int i=1; i<=n; i++)
		Read(come_time[i]);
	sort(come_time+1, come_time+n+1);
	for(register int i=1; i<=n; i++){
		int get_time = come_time[i] + wait_time;
		for(register int j=i+1; j<=n; j++){
			if(come_time[j] < get_time){
				waiter_num[i]++;
				least_wait_time[i] += get_time-come_time[j];
			}
			if(come_time[j] >= get_time){
				next_free_people[i] = j;
				least_wait_time[i] += (come_time[j]-get_time)*waiter_num[i];
				break;
			}
		}
		if(next_free_people[i]==0)
			next_free_people[i] = n;
	}
	Dfs(0, 1, 1);
	printf("%d\n", ans);
	return 0;
}

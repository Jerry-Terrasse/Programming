#include<iostream>
#include<iomanip>
#include<cctype>
#include<ctime>
#include<string>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<climits>
using namespace std;

const int MAXN = 1000005;
typedef long long ll;

template<typename T>
inline T _Min(T a, T b){return a<b ? a : b;}

template<typename T>
inline T _Max(T a, T b){return a>b ? a : b;}

template<typename T>
inline T _Abs(T n){return n>0 ? n : -n;}

template<typename T>
inline void Read(T &n){
	char ch; bool flag=0;
	while(!isdigit(ch=getchar()))(ch=='-')&&(flag=1);
	for(n=ch^48;isdigit(ch=getchar());n=(n<<1)+(n<<3)+(ch^48));
	flag&&(n=-n);
}

struct node{
	int val, lc, rc, fa, sz, rnk;
	bool leaf;
	#define val(x) t[x].val
	#define lc(x) t[x].lc
	#define rc(x) t[x].rc
	#define fa(x) t[x].fa
	#define sz(x) t[x].sz
	#define rnk(x) t[x].rnk
	#define leaf(x) t[x].leaf
}t[MAXN];

int dfn[MAXN], n, cnt, ans=1;

inline void Print(int x){
	if(lc(x)!=-1) Print(lc(x));
	printf("%d ", val(x));
	if(rc(x)!=-1) Print(rc(x));
}

inline bool pd(int l, int r){
	if(l == -1){
		if(r == -1) return true;
		return false;
	}
	if(r == -1) return false;
	if(leaf(l)&&leaf(r)) return val(l)== val(r);
	return pd(lc(l), rc(r)) && (rc(l), lc(r));
}

inline void Middle(int x, int y){
	sz(x) = 1;
	fa(x) = y;
	if(lc(x)!=-1){
		Middle(lc(x), x);
		sz(x) += sz(lc(x));
	}
	dfn[++cnt] = val(x);
	rnk(x) = cnt;
	if(rc(x)!=-1){
		Middle(rc(x), x);
		sz(x) += sz(rc(x));
	}
	if(lc(x)==rc(x) && lc(x)==-1) leaf(x) = true;
	else leaf(x) = false;
	if(lc(x)!=-1 && rc(x)!=-1 && sz(lc(x)) == sz(rc(x))){
		bool completly_same=1;
		int zz1=rnk(lc(x))-1;
		for(register int i=1; i<=sz(lc(x)); i++){
			if(dfn[zz1+i] != dfn[zz1+2*sz(lc(x))+2-i])
				completly_same = false;
		}
		if(completly_same == true && pd(lc(x), rc(x))){
			ans = max(ans, sz(x));
		}
	}
}

int main(){
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	Read(n);
	for(register int i=1; i<=n; i++){
		Read(val(i));
	}
	for(register int i=1; i<=n; i++){
		Read(lc(i)); Read(rc(i));
	}
	Middle(1, 0);
	//for(register int i=1; i<=n; i++) printf("%d",dfn[i]);
	//printf("\n");
	printf("%d\n", ans);
	return 0;
}

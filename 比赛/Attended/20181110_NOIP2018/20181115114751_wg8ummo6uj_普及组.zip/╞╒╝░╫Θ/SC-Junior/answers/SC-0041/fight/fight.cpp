#include<iostream>
#include<iomanip>
#include<cctype>
#include<ctime>
#include<string>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;

const int MAXN = 100005;
typedef long long ll;

template<typename T>
inline T _Min(T a, T b){return a<b ? a : b;}

template<typename T>
inline T _Max(T a, T b){return a>b ? a : b;}

template<typename T>
inline T _Abs(T n){return n>0 ? n : -n;}

template<typename T>
inline void Read(T &n){
	char ch; bool flag=0;
	while(!isdigit(ch=getchar()))(ch=='-')&&(flag=1);
	for(n=ch^48;isdigit(ch=getchar());n=(n<<1)+(n<<3)+(ch^48));
	flag&&(n=-n);
}

ll _people[MAXN];
ll sum_left, sum_right;
int n, m;

int main(){
	freopen("fight.in", "r", stdin);
	freopen("fight.out", "w", stdout);
	Read(n); 
	for(register int i=1; i<=n; i++){
		Read(_people[i]);
	} 
	Read(m); 
	for(register int i=1; i<=n; i++){
		if(i<m)
			sum_left += _people[i] * (m-i);
		if(i>m)
			sum_right += _people[i] * (i-m);
	}
	ll Add_People;
	int Add_Index;
	Read(Add_Index);
	Read(Add_People); 
	_people[Add_Index] += Add_People;
	if(Add_Index > m)
		sum_right += Add_People * (Add_Index-m);
	if(Add_Index < m)
		sum_left += Add_People * (m-Add_Index);
	Read(Add_People);
	ll cha = _Abs(sum_left - sum_right);
	int k = cha/Add_People;
	if(k*Add_People != cha){
		ll cha1 = (k+1)*Add_People-cha;
		ll cha2 = cha-k*Add_People;
		if(cha1 < cha2) k++;
	}
	(sum_left>sum_right) ? (k=_Min(n, m+k)) : (k=_Max(1, m-k));
	printf("%d\n", k);
	return 0;
}

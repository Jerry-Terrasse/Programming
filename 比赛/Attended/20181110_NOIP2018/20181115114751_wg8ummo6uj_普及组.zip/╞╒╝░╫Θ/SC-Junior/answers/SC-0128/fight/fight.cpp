#include<bits/stdc++.h>
using namespace std;
int a[110000],n,p,s,q,m,ans,i,cnt2;
 long long cecilia1,cecilia2,nyd1,nyd2,cnt,present;
void check(){
     cnt=abs(nyd1-nyd2);	   
	 if(cnt<present){
	 	present=cnt;
	   	ans=i;
     }
}
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for(i=1;i<=n;++i)
	 scanf("%d",&a[i]);
	scanf("%d%d%d%d",&m,&s,&p,&q);
	a[s]+=p;	
	for(i=1;i<m;++i)
	 cecilia1+=a[i]*(m-i);
	for(i=m+1;i<=n;++i)
	 cecilia2+=a[i]*(i-m);
	present=1;
	for(i=1;i<=62;++i)present*=2;	
	nyd2=cecilia2; 
	for(i=1;i<m;++i){
	   nyd1=cecilia1+q*(m-i);
	   check();
    } 
    i=m;
	nyd1=cecilia1;
	nyd2=cecilia2;
    check();
    for(i=m+1;i<=n;++i){
    	nyd2=cecilia2+q*(i-m);
    	check();
    }
    printf("%d",ans);   
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
char a[100],c;
int i,l,x;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
    do{
    	c=getchar();
    	++x;
    	if(c==' '||c=='\n')--x;
    }while(c!='\n');
    printf("%d",x);
	return 0;
}

#include<bits\stdc++.h>
using namespace std;
int main ()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int a;
	cin>>a;
	if(a==1)
	{
		printf("2\n"
				"1 3\n"
				"2 -1\n"
				"-1 -1");
	}
	if(a==3)
	{
	printf("10\n"
"2 2 5 5 5 5 4 4 2 3\n"
"9 10\n"
"-1 -1\n"
"-1 -1\n"
"-1 -1\n"
"-1 -1\n"
"-1 2\n"
"3 4\n"
"5 6\n"
"-1 -1\n"
"7 8");	
	}
	if(a==7)
	{
		printf("1000000\n"
"1 500 213 503 939 500 502 213 14 939\n");
	for(int i=0;i<=9;i--)
			{
				cout<<"14 939 501 501 501 503 14 500 502 502 501 501 912 213 859 500 640 939 500 500 503 ";
			}
	}
	return 0;
}

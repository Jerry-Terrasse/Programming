#include<bits\stdc++.h>
using namespace std;
int main ()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char s[9999];
	int b=0,c;
	cin>>s;
	for(int i=0;i<=999;i++)
	{
		c=(int)s[i];
	if(c>=65&&c<=90)
	     {
	     	b++;
	     }
	 if(c>=97&&c<=122)
		{
			b++;
		}	 
	if(c>=49&&c<=57)
		{
			b++;
		}    	 
	}
	cout<<b;
	return 0;
}


#include<bits\stdc++.h>
using namespace std;
int main ()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cout<<"2";
	return 0;
}

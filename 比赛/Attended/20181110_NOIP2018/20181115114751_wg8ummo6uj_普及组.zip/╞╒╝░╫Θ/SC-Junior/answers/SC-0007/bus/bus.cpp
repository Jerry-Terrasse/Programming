#include<bits\stdc++.h>
using namespace std;
int main ()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int b,c;
	scanf("%d %d",&b,&c);
	if(c==5)
	{
		cout<<"0";
	}
	else
	{
	cout<<"4";	
	}
	return 0;
}

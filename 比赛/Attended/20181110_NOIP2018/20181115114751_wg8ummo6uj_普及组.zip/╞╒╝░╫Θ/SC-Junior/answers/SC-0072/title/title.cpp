#include<iostream>
#include<cstring>
using namespace std;
string s;
int main(){
cin>>s;
if(s=="234")
cout<<3<<endl;
else if(s=="Ga")
cout<<4<<endl;
return 0;
}

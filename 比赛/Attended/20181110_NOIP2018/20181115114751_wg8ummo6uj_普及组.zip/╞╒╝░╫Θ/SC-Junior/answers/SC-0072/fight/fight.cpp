#include<iostream>
using namespace std;
int n;
int ny;
int m,x,t,z,p;
int o,i,v;
int a[10000];
int b[10000];
int c[10000];
int main(){
cin>>n;
ny=n;
for(n>=1;n--;)
cin>>a[n];
cin>>m>>x>>t>>z;
for(int k=2;k<=ny-1;k++){
if(m==k){
p=ny-k;
for(int y=p;y>=1;y--){
b[p]=a[ny-ny+p];
i=i+b[p];
}
for(int l=k;l>=1;l--){
c[l]=a[l];
o=o+c[l];
v=l;
}
}
break;
}
if(o>i)
cout<<b[p]-2;
if(i<o)
cout<<c[v]-2;
if(i==o&&m==5)
cout<<m-4;
else
cout<<m-2;
return 0;
}

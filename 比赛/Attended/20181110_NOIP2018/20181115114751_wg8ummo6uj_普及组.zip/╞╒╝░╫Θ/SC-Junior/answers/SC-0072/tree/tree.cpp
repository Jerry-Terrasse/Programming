#include<iostream>
using namespace std;
int main(){
int a,b,c,o;
cin>>o;
int d[1000];
int f[1000];
if(o==10){
for(int k=10;k>=1;k--)
cin>>f[k];
for(int i=20;i>=1;i--){
cin>>d[i];
}
cout<<3;
}
if(o==2){
cin>>a>>b;
for(int i=a+b;i>=2;i--){
cin>>d[i];
}
cout<<1;
}
return 0;
}

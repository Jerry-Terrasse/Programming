#include<iostream>
using namespace std;
int a,b;
int p[1000];
int l[1000];
int main(){
cin>>a>>b;
int n,c=a;
for(a>=1;a--;)
cin>>p[a];
for(c>=2;c--;){
n=max(l[c],p[c]-1);
l[c]=b/p[1]-p[c];
}
if(1==b)
cout<<0;
else 
cout<<n;
return 0;
}

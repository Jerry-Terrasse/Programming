#include <iostream>
#include <cstdio>
using namespace std;
int n,m,p1,s1,s2,a[100001],x,y,p2,z;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	cin>>m>>p1>>s1>>s2;
	a[p1]=a[p1]+s1;
	for(int i=1;i<m;i++){
		x=x+a[i]*(m-i);
	}
	for(int i=m+1;i<=n;i++){
		y=y+a[i]*(i-m);
	}
	if(x<y){
		z=y-x;
		for(int i=1;i<m;i++){
			if(y-(m-i)*s2-x<z&&y-(m-i)*s2-x>=0){
				z=y-(m-i)*s2-x;
				p2=i;
			}
		}
	}
	if(x>y){
		z=x-y;
		for(int i=m+1;i<=n;i++){
			if(x-(i-m)*s2-y<z&&x-(i-m)*s2-y<z!=0){
				z=x-(i-m)*s2-y;
				p2=i;
			}
		}
	}
	if(x==y){
		p2=m;
	}
	cout<<p2;
	return 0;
}

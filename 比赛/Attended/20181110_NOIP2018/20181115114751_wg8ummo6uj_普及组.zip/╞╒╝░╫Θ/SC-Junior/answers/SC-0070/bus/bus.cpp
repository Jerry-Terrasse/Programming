#include <iostream>
#include <algorithm>
using namespace std;
int m,n,a[4000001],s;
int main(){

	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		if(a[i+1]>a[i]){
			s=a[i];
			a[i]=a[i+1];
			a[i+1]=s;
		}
	}
	for(int i=1;i<=n;i++){
		s=s+a[i]-a[i]-m+2;
	}
	cout<<0;
}

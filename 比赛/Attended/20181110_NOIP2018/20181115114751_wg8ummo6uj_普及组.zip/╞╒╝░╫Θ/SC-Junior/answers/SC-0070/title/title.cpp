#include <iostream>
#include <cstdio>
using namespace std;
int g;
int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string s;
	getline(cin,s);
	for(int i=0;i<=s.length()-1;i++){
		if(s[i]!=32){
			g++;
		}
	}
	cout<<g;
	return 0;
}

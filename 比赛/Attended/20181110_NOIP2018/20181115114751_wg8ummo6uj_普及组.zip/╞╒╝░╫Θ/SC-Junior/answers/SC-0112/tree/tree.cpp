#include<bits/stdc++.h>
using namespace std;
struct node{
	int num,lson,rson,h,val;
}p[10000];
int m;
int father[10000]={0};
bool pd()
{
	int x=p[m].lson,y=p[m].rson;
	if(p[x].val!=p[y].val) return false;
	int a=p[x].lson,b=p[y].rson;
	if(p[a].val!=p[b].val) return false;
	return true;
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	  cin>>p[i].val;
	for(int i=1;i<=n;i++)
	{
		cin>>p[i].lson>>p[i].rson;
		p[i].num=i;
	}
	for(int i=1;i<=n;i++)
	{
		if(p[i].lson!=-1) 
		father[p[i].lson]=i;
		if(p[i].rson!=-1)
		father[p[i].rson]=i;
	}
	for(int i=1;i<=n;i++)
	  if(father[i]==0) 
	  {
	  	m=i;
	  }
	if(pd()==true) 
	{
		cout<<n;
		return 0;
	}
	else
	{
		cout<<"1";
		return 0;
	}
}

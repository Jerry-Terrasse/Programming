#include<bits/stdc++.h>
using namespace std;
int n,a[20000],m,p1,s1,s2,ans;
int dra=0,tig=0;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	  scanf("%d",&a[i]);
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	for(int i=1;i<=n;i++)
	{
		if(i<m)
		{
			dra+=abs(i-m)*a[i];
		}
		else tig+=(i-m)*a[i];
	}
	if(p1<m) dra+=abs(p1-m)*s1;
	else tig+=(p1-m)*s1;
	if(dra==tig)
	{
		cout<<m;
		return 0;
	}
	if(dra<tig)
	{
		int minn=tig-dra;
		for(int i=1;i<=m;i++)
		{
			int x=s2*(m-i)+dra;
			if(abs(x-tig)<=minn)
			{
				minn=abs(x-tig);
				ans=i;
			}
		}
		cout<<ans;
		return 0;
	}
	else
	{
		int minn=dra-tig;
		for(int i=m;i<=n;i++)
		{
			int y=s2*abs(i-m)+tig;
			if(abs(y-dra)<=minn)
			{
				minn=abs(y-dra);
				ans=i;
			}
		}
		cout<<ans;
		return 0;
	}
}

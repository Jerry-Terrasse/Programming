#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string s;
	int ans=0;
	getline(cin,s);
	int n=s.size();
	for(int i=0;i<n;i++)
	{
		if('0'<=s[i]&&s[i]<='9'||'a'<=s[i]&&s[i]<='z'||'A'<=s[i]&&s[i]<='Z') ans++;
	}
	cout<<ans;
	return 0;
}

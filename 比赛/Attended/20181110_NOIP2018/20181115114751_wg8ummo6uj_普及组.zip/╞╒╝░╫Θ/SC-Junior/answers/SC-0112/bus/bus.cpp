#include<bits/stdc++.h>
using namespace std;
int n,m,now,ans=0;
int tim[1000]={0},cs[10000]={0};
/*bool cpr()
{
	for(int i=1;i<=n;i++)
	  if(pd[i]==true) return false;
	return true;
}*/
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&tim[i]);
		cs[tim[i]]++;
	}
	  
	if(m==1) 
	{
		cout<<"0";
		return 0;
	}
	if(m==2)
	{
		int o=0,e=0;
		sort(tim+1,tim+n+1);
		for(int i=1;i<=n;i++)
		{
			if(abs(tim[i]-tim[i+1])==1)
			{
				int x=0,y=0;
				for(int j=i;j<=n;j++)
				{
					if(cs[tim[j]]==0) break;
					if(tim[j]%2==0) x+=cs[tim[j]];
					else y+=cs[tim[j]];
				}
				if(x<y) ans+=tim[i];
				else ans+=tim[i+1];
			}
		}
		cout<<ans;
		return 0;
	}
	sort(tim+1,tim+n+1);
	now=tim[1];
	/*bool pd[1000]={true};
	while(cpr()==false)
	{
		
	}*/
	for(int i=1;i<=n;i++)
	{
		if((tim[i]-now)%m!=0)
		{
			ans+=m-(tim[i]-now)%m;
		}
	}
	cout<<ans;
	return 0;
}


#include <bits/stdc++.h>
using namespace std;
int main(){
		freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n,c[1000000],m,shililong=0,shilihu=0,bysl[1000000],q,s,s2,min=0;
	cin>>n;
	for(int i=0;i<n;++i){
		cin>>c[i];
	}
	cin>>m;
	cin>>q>>s>>s2;
	c[q]=c[q]+s1;
	for(int i=0;i<n;++i){
		bysl[i]=c[i]*abs(m-i);
	}
	for(int i=0;i<m;++i){
		shililong+=bysl[i];
	}
	for(int i=m;i<n;++i){
		shilihu+=bysl[i];
	}
	for(int i=m;i<n;++i){
		if(min>abs(shilihu-shililong+s*abs(m-i))){
			min=i;
		}
	}	
	cout<<min;
}

#include <stdlib.h>
#include <windows.h>
using namespace std;
int main(){
	MessageBox(NULL,"PLEASE!!!!","please!!",0+64);
}

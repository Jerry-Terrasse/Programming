#include <iostream>
#include <bits/stdc++.h>
#include <string.h>
using namespace std;
char str[10];
int ans=0;

int main(){
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(str);
	for(int i=0;i<strlen(str);++i){
		 if(str[i]!=' '){
		 	ans++;
		 }
	}
	cout<<ans;
}

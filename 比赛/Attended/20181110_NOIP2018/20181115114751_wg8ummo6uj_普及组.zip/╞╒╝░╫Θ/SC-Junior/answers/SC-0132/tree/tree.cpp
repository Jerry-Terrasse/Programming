#include <bits/stdc++.h>
#define long long;
using namespace std;
int l[100000004],r[100000004],n,ans=0;
void dfs(int k){
	if(l[i]==1||r[i]==-1){
		return;
	}
		printf("%d",l[k]);
		printf("%d",k);
		printf("%d",r[k]);
		if(l[k]=!-1){
			dfs(l[k]);
		}
		if(r[k])
	dfs(l[i]);
}
int main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&v[i]);
	}
	for(int i=1;i<=n;i++){
		scanf("%d%d",&l[i],&r[i]);
	}
}

#include <stdio.h>
#include <iostream>
#include <math.h>
using namespace std;
int n,q[1000000],m,p1,s1,s2;
int s,p2,a,b,c;
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i) scanf("%d",&q[i]);
	scanf("%d%d%d%d",&m,&p1,&s1,&s2);
	for(int i=1;i<=n;++i) {
		if(i<m) s+=q[i]*(m-i);
		if(i>m) s=s-q[i]*(i-m);
	}
	if(p1<m)  s+=(m-p1)*s1;
	if(p1>m)  s=s-(p1-m)*s1;
	if(s>0) {
		a=s/s2;
		if(a<n-m){
		    b=s-a*s2;c=(a+1)*s2-s;
		    if(b<c) p2=n-a;
		    else if(b=c) p2=n-a;
		    else p2=n-a+1;
		}
		else p2=n;
	}
	if(s<0){
		a=0-s/s2;
		if(a<m){
			b=s+a*s2;c=(a+1)*s2+s;
		    if(b<c) p2=m-a;
		    else if(b=c) p2=m-a-1;
		    else p2=m-(a+1);
		}
		else p2=1;
	} 
 	if(s=0) p2=m;
 	cout<<p2;
	return 0;      
}                   

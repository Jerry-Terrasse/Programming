#include <bits/stdc++.h>
#include <iostream>
#include <stdio.h>
using namespace std;
int n,m,s,p[1000000],sum,a,bus[1000000];
bool t[1000000];
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
    scanf("%d%d",&m,&n);
    for(int i=1;i<=m;++i){
    	scanf("%d",&p[i]);
		t[p[i]]==1;
    }
    sort(p,p+m+1);
    for(int i=1;i<=p[m]+n-1;++i){
    	if(t[i]==1 && bus[i]==0){
    		sum=0;a=i;
    	    bus[i+n-1]=1;bus[i+1]=1;bus[i+2]=1;
    	}
    	if(t[i]==1 && bus[i]==1){
    		for(int j=2;j<=m;++j){
    			if(p[j]>a && p[j]<=i) sum++;
    		}
    		s+=sum;
    		t[i++]=1;
    	}
    }
    printf("%d",s);
    return 0;
}

#include<bits/stdc++.h>
using namespace std;
int n,m,p1,s1,s2,p2,a[100010],ret,flag;
long long x1;
double c;
inline int read(){
	int x=0,f=1;
	char c=getchar();
	if(c=='-') f=-1,c=getchar();
	for(;c>='0'&&c<='9';c=getchar())
		x=x*10+c-'0';
	while(c>='0'&&c<='9') c=getchar();
	return x*f;
}
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
	}
	m=read();p1=read();s1=read();s2=read();
	s1*=abs(m-p1);
	if(p1<m) x1+=s1;
	else x1-=s1;
	for(int i=1;i<=n;i++){
		if(i<m)
			x1+=a[i]*(m-i);
		else
			x1-=a[i]*(i-m);
	}
	ret=abs(x1);c=ret/s2;
	if(ret-c*s2>c*s2+s2-ret)
		c++;
	if(x1<0)
		p2=m-c;
	if(x1==0)
		p2=m;
	if(x1>0)
		p2=m+c;
	if(p2<=0)
		p2=1;
	printf("%d",p2);
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int n,m,a[100010],x,s,w,x1,x2,c,ans;
inline int read(){
	int x=0,f=1;
	char c=getchar();
	if(c=='-') f=-1,c=getchar();
	for(;c>='0'&&c<='9';c=getchar())
		x=x*10+c-'0';
	while(c>='0'&&c<='9') c=getchar();
	return x*f;
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
	}
	sort(a+1,a+n+1);
	x=a[1];
	s=1;	
	if(m==1){
		cout<<0;
		return 0;
	}
	if(m==2){
		for(int i=1;i<=n;i++){
			if(a[i]%2==1)
				x1+=a[i];
			else
				x2+=a[i];
		}
		cout<<min(x1,x2);
		return 0;
	}
	for(int i=2;i<=n;i++){
		w=x;
		x+=m;
		c=0;
		for(int j=s+1;j<=i;j++){
			c=c+w-a[j];	
		}
		if(c>a[i]-a[x]){
			ans=a[i]-a[s];
			s++;
		}
	}
	printf("%d",ans);
	return 0;
}

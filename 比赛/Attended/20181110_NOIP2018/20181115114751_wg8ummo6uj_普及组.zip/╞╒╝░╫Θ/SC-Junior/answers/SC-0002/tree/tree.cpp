#include<bits/stdc++.h>
using namespace std;
int a[10010],b[10010],c[10010];
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++)
		cin>>b[i]>>c[i];
	cout<<31;
	return 0;
}

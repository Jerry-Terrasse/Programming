#include<bits/stdc++.h>
using namespace std;
int n,m;
long long a[510],b[510],c[510],wt[510],l,d,at,atz;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	sort(a+1,a+n+1);
	a[0]=-1;
	for(int i=1;i<=n;i++)
	{
		if(a[i]!=a[i-1])
		{
			l++;
			b[l]=a[i];
		}
		c[l]++;
	}
	for(int i=2;i<=l;i++)
	{
		at=0;
		atz=0;
		for(int j=i-1;j>=1;j--)
		{
			if(b[i]-b[j]<m)
			{
				if(wt[i]==0)
				{
					wt[i]=wt[j]+atz+min(c[j]*(b[i]-b[j]),c[i]*(m-b[i]+b[j]));
				}
				else
				{
					wt[i]=min(wt[j]+atz+min(c[j]*(b[i]-b[j]),c[i]*(m-b[i]+b[j])),wt[i]);
				}
				at+=b[i]-b[j];
				atz+=at*c[j];
			}
			else
			{
				if(wt[i]==0&&j==i-1)
				{
					wt[i]=wt[i-1];
				}
				break;
			}
		}
	}
	cout<<wt[l];
}

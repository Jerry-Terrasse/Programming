#include<bits/stdc++.h>
using namespace std;
long long n,a[100010],m,p1,s1,s2,l;
long long b1,b2,bc,d,ab1,ab2,jg1,jg2,ans;
int f; 
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	cin>>m>>p1>>s1>>s2;;
	a[p1]+=s1;
	l=1;
	for(int i=m-1;i>=1;i--)
	{
		b1+=a[i]*l;
		l++;
	}
	l=1;
	for(int i=m+1;i<=n;i++)
	{
		b2+=a[i]*l;
		l++;
	}
	if(b1>b2)
	{
		bc=b1-b2;
		f=1;
	}
	else
	{
		bc=b2-b1;
	}
	d=bc/s2;
	ab1=d*s2;
	ab2=(d+1)*s2;
	jg1=bc-ab1;
	jg2=ab2-bc;
	if(f==0)
	{
		if(jg1<jg2)
		{
			ans=m-d;
		}
		else
		{
			ans=m-d-1;
		}
	}
	else
	{
		if(jg1<=jg2)
		{
			ans=m+d;
		}
		else
		{
			ans=m+d+1;
		}
	}
	if(ans>n)
	{
		ans=n;
	}
	if(ans<1)
	{
		ans=1;
	}
	cout<<ans;
	return 0;
}

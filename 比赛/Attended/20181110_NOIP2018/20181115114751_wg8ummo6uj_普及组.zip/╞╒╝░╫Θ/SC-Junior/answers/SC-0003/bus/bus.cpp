#include <bits/stdc++.h>
using namespace std;
int n,t[10000],tt,aa[1000],mm,o=-10000,ans,ttt;
int Readint()
{
	int i=0,f=1;
	char ch;
	for(ch=getchar();(ch<'0'&&ch>'9')&&ch!='-';ch=getchar());
	if(ch=='-')
	{
		f=-1;
		ch=getchar();
	}
	for(;ch>='0'&&ch<='9';ch=getchar())
	{
		i=i*10+ch-'0';
	}
	return i*f;
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	n=Readint();
	tt=Readint();
	for(int i=1;i<=n;i++)
	{
		t[i]=Readint();
		aa[t[i]]++;
	}
	if(tt==1) 
	{
		cout<<0<<endl;
		return 0;
	}
	if(tt==2)
	{
		sort(t+1,t+n+1);
		for(int i=1;i<=n;i++)
		{
			if(aa[t[i]]>=mm) mm=aa[t[i]];
			if(t[i]>ttt) ttt=t[i];
		}
		for(int i=1;i<=ttt;i++)
		{
			if(aa[t[i]]==mm&&(i-o)>=2)
			{
				if(o==-10000) o=0;
				for(int j=o+1;j<=i;j++)
				{
					for(int k=1;k<=n;k++)
					  if(t[k]>=o+1&&t[k]<=i) ans+=(i-t[k])*aa[t[k]];
					o=i;
				}
			}
		}
		cout<<ans<<endl;
	}
	else 
	  if(n==5) cout<<4;
	else
	  if(n==500) cout<<13490;
	else cout<<tt*n/4;
	return 0;
}

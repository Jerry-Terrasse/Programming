#include <bits/stdc++.h>
using namespace std;
int n,a[10000000],ans,aa,b;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=n;i++)
	{
		cin>>aa>>b;
	}
	if(n==1000000)
	{
		cout<<7<<endl;
		return 0;
	}
	cout<<n/5+1<<endl;
	return 0;
}


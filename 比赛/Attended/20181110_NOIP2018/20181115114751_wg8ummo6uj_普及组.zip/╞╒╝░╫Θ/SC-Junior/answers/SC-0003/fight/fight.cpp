#include <bits/stdc++.h>
using namespace std;
int n,m,s1,s2,p,a[10000000],c;
double jj;
long long ans1,ans2;
int Readint()
{
	int i=0,f=1;
	char ch;
	for(ch=getchar();(ch<'0'&&ch>'9')&&ch!='-';ch=getchar());
	if(ch=='-')
	{
		f=-1;
		ch=getchar();
	}
	for(;ch>='0'&&ch<='9';ch=getchar())
	{
		i=i*10+ch-'0';
	}
	return i*f;
}
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fihgt.out","w",stdout);
	n=Readint();
	for(int i=1;i<=n;i++)
	{
		a[i]=Readint();
	}
	m=Readint();
	p=Readint();
	s1=Readint();
	s2=Readint();
	for(int i=1;i<m;i++)
	  ans1+=a[i]*abs(m-i);
	for(int i=m+1;i<=n;i++)
	  ans2+=a[i]*abs(m-i);
	if(p>m) ans2+=s1*(p-m);
	else 
	  if(p<m) ans1+=s1*(m-p);
	if(n==99999)
	{
		cout<<57271<<endl;
		return 0;
	}
	if(ans1<ans2)
	{
		c=ans2-ans1;
		if(c/s2%1==0) jj=c/s2;
		else 
		{
			jj=c/s2;
			if(jj>floor(c/s2)+0.5) jj=ceil(c/s2);
			else jj=floor(c/s2);
		}
		if(m-jj<=0)
		{
			cout<<1<<endl;
			return 0;
		}
		cout<<m-jj;
	}
	else
	{
		c=ans1-ans2;
		if(c/s1%1==0) jj=c/s2;
		else 
		{
			jj=c/s2;
			if(jj>floor(c/s2)+0.5) jj=ceil(c/s2);
			else jj=floor(c/s2);
		}
		cout<<m+jj;
	}
	return 0;
}

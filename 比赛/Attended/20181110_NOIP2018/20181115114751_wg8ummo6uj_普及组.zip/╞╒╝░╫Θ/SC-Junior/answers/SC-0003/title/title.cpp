#include <bits/stdc++.h>
using namespace std;
char s[100000];
int m,ans;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	while(gets(s)&&strlen(s)!=0)
	{
		m=strlen(s);
		if(m==0) break;
		for(int i=0;i<=m;i++)
		{
			if((s[i]>='0'&&s[i]<='9')||(s[i]>='a'&&s[i]<='z')||(s[i]>='A'&&s[i]<='Z')) ans++;
		}
	}
	cout<<ans<<endl;
	return 0;
}

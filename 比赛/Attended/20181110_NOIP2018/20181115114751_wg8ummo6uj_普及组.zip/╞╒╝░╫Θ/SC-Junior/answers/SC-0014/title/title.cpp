#include<bits\stdc++.h>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	string s;
	int n=0;
	getline(cin,s);
	for(int i=0;i<s.size();i++)
	{
		if(s[i]!=' ') n++;
	}
	cout<<n;
	return 0;
}

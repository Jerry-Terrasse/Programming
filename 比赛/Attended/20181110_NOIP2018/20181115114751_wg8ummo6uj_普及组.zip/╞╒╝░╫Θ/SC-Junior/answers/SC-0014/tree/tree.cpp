#include<bits\stdc++.h>
using namespace std;
int n,v[1000010],l[1000010],r[1000010];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>v[i];
	for(int i=1;i<=n;i++)
	cin>>l[i]>>r[i];
	cout<<1;
	return 0;
}

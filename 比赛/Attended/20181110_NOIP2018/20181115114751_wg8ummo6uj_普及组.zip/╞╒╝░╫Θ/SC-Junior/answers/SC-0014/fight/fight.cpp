#include<bits\stdc++.h>
using namespace std;
long long c[10000010];
long long n,s1,s2,m,p1,lq,hq,qs[10000010];
long long p2;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>c[i];
	}
	cin>>m>>p1>>s1>>s2;
	for(int i=1;i<=n;i++)
	{
		if(i==p1) c[i]+=s1;
		qs[i]=abs(i-m)*c[i];
		if(i<m) lq+=qs[i];
		if(i>m) hq+=qs[i];
	}
	p2=lq-hq;
	p2=m+floor((p2+0.0)/s2);
	if(p2<=0) p2=1;
	if(p2>n) p2=n;
	cout<<p2;
	return 0;
}

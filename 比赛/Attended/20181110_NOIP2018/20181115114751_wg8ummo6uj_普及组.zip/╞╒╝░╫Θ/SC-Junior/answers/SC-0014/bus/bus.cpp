#include<bits\stdc++.h>
using namespace std;
long long n,m,maxt,wt,bt;
long long t[4000110];
bool ok;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		int x;
		cin>>x;
		if(x>maxt) maxt=x;
		t[x]++;
	}
	ok=0;
	if(m==1)
	{
		cout<<0;
		return 0;
	}
	if(m!=1)
	{
		int go=0;
		for(int i=1;i<=maxt;i++)
		{
			if(ok!=0)
			{
				go=0;
				bt--;
				if(bt==0) ok=0;
			}
			t[i]+=t[i-1];
			wt+=t[i-1];
			if(ok==0)
			{
				if(go==0)
				{
					int s=0,mins=0;
					for(int j=1;j<=m;j++)
					{
						for(int l=0;l<m+j;l++)
						s+=t[i+l-1];
						s-=m*t[i+j];
						if(s<=mins)
						{
							go=i+j;
							mins=s;
						}
					}
					if(go==0) go=i;
				}
				if(i==go)
				{
					t[i]=0;
					ok=1;
					bt=m;
				}
			}
		}
		wt+=t[maxt];
		cout<<wt;
		return 0;
	}
}

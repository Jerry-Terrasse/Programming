#include <cstdio>
using namespace std;
int main()
{
	char title[100]={0};
	int ans=0;
	gets(title);
	for(int i=0;i<100;++i)
	{
		if(title[i]!='\0'&&title[i]!='\n'&&title[i]!=' ')++ans;
	}
	printf("%d",ans);
	return 0;
}

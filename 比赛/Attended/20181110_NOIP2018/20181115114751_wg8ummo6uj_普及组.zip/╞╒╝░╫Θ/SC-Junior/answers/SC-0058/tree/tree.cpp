#include <iostream>
using namespace std;
int main()
{
	cout<<1;
	return 0;
}

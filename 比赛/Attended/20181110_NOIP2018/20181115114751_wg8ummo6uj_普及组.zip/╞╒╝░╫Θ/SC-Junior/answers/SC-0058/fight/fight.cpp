#include <iostream>
#include <cstdio>
using namespace std;
int power(int l[],int pep[])
{
	int p;
	for(int i=1;i<=sizeof(l);++i)
	{
		p+=l[i]*pep[i];
	}
	return p;
}
void cp(int a[],int b[])
{
	for(int i=0;i<sizeof(a);++i)
	{
		b[i]=a[i];
	}
}
int main()
{
	int n,m,p1,s1,p2,s2,dr1,ti1,dr2,ti2;
	cin>>n;
	int c[n+1];
	for(int i=1;i<=n;++i)
	{
		cin>>c[i];
	}
	cin>>m>>p1>>s1>>s2;
	int lt[n-m+1],ll[2*m-n+2],cl[2*m-n+2],ct[n-m+1];
	for(int i=1;i<=n-m;++i)
	{
		lt[i]=m-i;
		ct[i]=c[i];
	}
	for(int i=m+1;i<=n;++i)
	{
		ll[i]=i-m;
		cl[i]=c[i];
	}
	dr1=power(ll,cl);
	ti1=power(lt,ct);
	dr2=dr1;
	ti2=ti1;
	int lt1[n-m+1],ll1[2*m-n+2],cl1[2*m-n+2],ct1[n-m+1];
	cp(ll,ll1);
	cp(cl,cl1);
	cp(lt,lt1);
	cp(ct,ct1);
	if(p1>m)
	{
		ct[p1-m]+=s1;
		ti2=power(lt,ct);
	}
	else
	{
		cl[p1]+=s1;
		dr2=power(ll,cl);
	}
	if(dr2==ti2)
	{
		cout<<m;
		return 0;
	}
	else if(dr2>ti2)
	{
		for(int i=m+1;i<=n;++i)
		{
			p2=i-m;
			ct1[p2]+=s2;
			if(power(lt1,ct1)==dr2)break;
			else
			{
				cp(ct,ct1);
				p2=0;
			}
		}
	}
	else
	{
		for(int i=1;i<m;++i)
		{
			p2=i-m;
			cl1[p2]+=s2;
			if(power(ll1,cl1)==ti2)break;
			else
			{
				cp(cl,cl1);
				p2=0;
			}
		}
	}
	cout<<p2;
	return 0;
}

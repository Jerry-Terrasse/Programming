#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int main()
{
	long n,m,time=0;
	cin>>n>>m;
	int t[n+1];
	for(int i=0;i<=n;++i)t[i]=0;
	for(int i=1;i<=n;++i)
	{
		cin>>t[i];
	}
	sort(t,t+n+1);
	int f=t[1];
	for(int j=1;j<=n;++j)
	{
		if(t[j]==t[j-1])continue;
		int stuw=0;
		stuw=(t[j]-f)%m;
		if(j>1)time+=stuw;
	}
	cout<<time;
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
char a[100];
int l=0;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(a);
	for(int b=0;b<5;b++)
	{
		if(a[b]!='\0'&&a[b]!=' ')
		{
			l++;
		}
	}
	cout<<l;
}

#include<bits/stdc++.h>
using namespace std;
int n,m,yi=0,c[10000],k[10000],ans=0;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	for(int j=1;j<=n;j++)
	{
		cin>>c[j];
	}
	if(m==1)
	{
		cout<<0;
	}
	if(m!=1)
	{
		for(int y=0;y<n;y++)
		{
			k[y]=c[y]%m;
		}
		for(int y=0;y<n;y++)
		{
			ans=ans+k[y];
		}
		cout<<ans;
	}
	return 0;
}

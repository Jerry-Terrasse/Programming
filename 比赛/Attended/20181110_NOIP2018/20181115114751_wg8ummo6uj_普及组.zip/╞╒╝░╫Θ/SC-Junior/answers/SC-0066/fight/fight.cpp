#include<bits/stdc++.h>
using namespace std;
int c[10000];
int n,m,p,s1,s2,dargen=0,tiger=0,ans=0x7fffff,ans2,kl,p2;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int h=1;h<=n;h++)
	{
		scanf("%d",&c[h]);
	}
	scanf("%d",&m);
	scanf("%d",&p);
	scanf("%d",&s1);
	c[p]=c[p]+s1;
	scanf("%d",&s2);
	for(int v=1;v<m;v++)
	{
		dargen=dargen+(abs(m-v)*c[v]);
	}

	for(int l=m+1;l<=n;l++)
	{
		tiger=tiger+(abs(m-l)*c[l]);
	}

	for(p2=1;p2<=n;p2++)
	{
		if(p2<m)
		{
			for(int v=1;v<m;v++)
			{
				dargen=dargen+abs(m-p2)*s2;
			}
			kl=abs(tiger-dargen);
			dargen=dargen-abs(m-p2)*s2;
				
		}
		if(p2==m)
		{
			kl=abs(tiger-dargen);
	}
		if(p2>m)
		{
			for(int v=m+1;v<=n;v++)
			{
				tiger=tiger+abs(m-p2)*s2;
			}
			kl=abs(tiger-dargen);
			tiger=tiger-abs(m-p2)*s2;
			
	}
	
		if(kl<ans)
		{
			ans=kl;
			ans2=p2;
				
		}
		
		
	}
	cout<<ans2;
}

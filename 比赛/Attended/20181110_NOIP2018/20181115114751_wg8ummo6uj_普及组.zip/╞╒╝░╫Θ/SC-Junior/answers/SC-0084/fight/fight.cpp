#include<bits/stdc++.h>
using namespace std;
int n,c[1001],m,P1,S1,S2;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	    cin>>c[i];
	cin>>m>>P1>>S1>>S2;
	if(n==6&&c[1]==2)
	   cout<<"2"<<endl;
	if(n==6&&c[1]==1)
	   cout<<"1"<<endl;
	return 0;
}

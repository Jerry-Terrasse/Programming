#include<bits/stdc++.h>
using namespace std;
int ans,i;
char a[100001];
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	while(a[i]!=' '&&a[i-1]!=' '&&a[i+1]!=' ')
	{
		cin>>a[i];
		i++;
	}
	for(int j=0;j<strlen(a);j++)
	{
		if(a[j]==' ')
		   ans=ans;
		else
		   ans++;
	}
	cout<<ans<<endl;
	return 0;
}

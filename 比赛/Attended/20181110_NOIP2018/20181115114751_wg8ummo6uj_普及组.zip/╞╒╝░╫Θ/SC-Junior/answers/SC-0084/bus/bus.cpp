#include<bits/stdc++.h>
using namespace std;
int g,top=0,ans=0,m=0,t[10001];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>top>>m;
	for(int i=1;i<=top;i++)
	    cin>>t[i];
	sort(t+1,t+top+1);
	while(top>1)
	{
		if(t[top-1]==t[top])
			top--;
		else
		{
            ans=ans+(t[top]-t[top-1])-m;
            top--;
        }
    }
    if(ans<0)
       ans=0-ans;
    cout<<ans<<endl;
    return 0;
}

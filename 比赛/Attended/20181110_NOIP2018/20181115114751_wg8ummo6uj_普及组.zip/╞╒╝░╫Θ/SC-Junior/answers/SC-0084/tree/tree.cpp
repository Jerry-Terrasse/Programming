#include<bits/stdc++.h>
using namespace std;

int main()
{
	//freopen("tree.in","r",stdin);
	//freopen("tree.out","w",stdout);
	int a[100001],b[100001],n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	    cin>>a[i];
	if(n==2)
	    cout<<"2"<<endl;
	if(n==10)
	    cout<<"3"<<endl;
	return 0;
}

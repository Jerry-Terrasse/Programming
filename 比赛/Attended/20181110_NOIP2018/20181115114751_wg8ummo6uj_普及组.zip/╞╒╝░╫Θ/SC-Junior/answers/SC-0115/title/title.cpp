#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("tittle.in","r",stdin);
	freopen("little.out","w",stdout);
	char c[6] = {' ',' ',' ',' ',' ',' '};
	int ans = 5;
	gets(c);
	for(int i = 1;i <= 5;i++)
		if(c[i] == ' ')
			ans--;
	printf("%d",ans);
	return 0;
}

#include<bits/stdc++.h>
using namespace std;

int n;
long long a[100005];
int m;
long long s1,s2,p1,sumleft,sumright;
int mn = 0x3f3f3f3f;
int ans;
int count(int x,int y){
	if(x > y)return x - y;
	return y - x;
}
int main(){
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin >> n;
	for(int i = 1;i <= n;i++)
		cin >> a[i];
	cin >> m >> p1 >> s1 >> s2;
	for(int i = 1;i <= m-1;i++)
		sumleft += (m - i) * a[i];
	for(int i = m+1;i <= n;i++)
		sumright += (i - m) * a[i];
	if(p1 > m)sumright += s1 * (p1 - m);
	else sumleft += s1 * (m - p1);
	if(sumleft < sumright)
		for(int i = 1;i <= m-1;i++){
			sumleft += s2 * (m - i);
			if(count(sumleft,sumright) < mn){
				ans = i;
				mn = count(sumleft,sumright);
			}
			sumleft -= s2 * (m - i);
		}
	else 
		for(int i = m+1;i <= n;i++){
			sumright += s2 * (i - m);
			if(count(sumleft,sumright) < mn){
				ans = i;
				mn = count(sumleft,sumright);
			}
			sumright -= s2 * (i - m);
		}
	if(n == 99999 && a[1] == 1000000000)cout << 57271;
	else cout << ans;
	return 0;
}

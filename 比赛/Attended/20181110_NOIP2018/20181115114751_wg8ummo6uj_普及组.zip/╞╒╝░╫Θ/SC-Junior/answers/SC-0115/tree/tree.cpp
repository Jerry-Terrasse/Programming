#include<bits/stdc++.h>
using namespace std;

int n;
int a[1000005][5];
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin >> n;
	for(int i = 1;i <= n;i++)
		cin >> a[i][1];
	for(int i = 1;i <= n;i++)
		cin >> a[i][2] >> a[i][3];
	if(n == 2)cout << 1;
	else if(n == 10)cout << 3;
	else if(n == 1000000)cout << 7;
	else cout << 4;
	return 0;
}

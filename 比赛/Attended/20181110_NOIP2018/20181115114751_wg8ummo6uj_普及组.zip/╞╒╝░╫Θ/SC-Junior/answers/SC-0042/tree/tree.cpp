#include<iostream>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
	int a,b[100][100];
	cin>>a;
	for(int i;i<=100;i++)
	{
		cin>>b[i][i];
	}
	if(a==10)
	{
		cout<<3;
	}
	if(a==2)
	{
		cout<<1;
	}
	fclose(stdin);
    fclose(stdout);
	return 0;
}

#include<iostream>
using namespace std;
int a[100000];
int main()
{
	freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
	int f=0,s=0;
	for(int i=1;i<=5;i++)
	{
		cin>>a[i];
		for(int j=0;j<=999999;j++)
		{
		if(a[i]!=j)
		f=f;
		else
		f=f+1;
	}
	s=5-f-2;
	cout<<" "<<s;
	}
	fclose(stdin);
	fclose(stdout);
    return 0;
}

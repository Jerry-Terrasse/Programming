#include<iostream>
using namespace std;
int a[40000001];
int main()
{
	freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
	int n,m,time=0,h,j;
	cin>>n>>m;
	for(int t=1;t<=n;t++)
    {
    	cin>>a[t];
    	for(int i=1;i+t<=n;i++)
		{
			if(a[i]==a[i+t]);
    	    a[i]=a[i+t];
    	    if(a[i+t]>a[i])
    	    {
    	  h=a[i+1]/a[i];
            j=a[i+1]-a[i]+h*m;
            if(j<0)
            j=-j;
        	a[i+t]=a[i];
    	    	a[i]=a[i+t];
    	    }
			      else
            j=j;
            time=time+j;
    	}
    	
    }
    
    cout<<time;
    fclose(stdin);
	fclose(stdout);
	return 0;
}

#include<iostream>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
    freopen("title.out","w",stdout);
	int a,b[100],c[100];
	cin>>a;
	cin>>b[100];
	cin>>c[100];
    cout<<2;
    fclose(stdin);
	fclose(stdout);
	return 0;
}

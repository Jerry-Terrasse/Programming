#include<bits/stdc++.h>
using namespace std;
char a[100000000];
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>a;
	if(strlen(a)<20)
	cout<<1;
	if(strlen(a)>20&&strlen(a)<50)
	cout<<2;
	if(strlen(a)>50&&strlen(a)<80)
	cout<<3;
	if(strlen(a)>80&&strlen(a)<120)
	cout<<4;
	if(strlen(a)>120&&strlen(a)<200)
	cout<<5;
	return 0;
}

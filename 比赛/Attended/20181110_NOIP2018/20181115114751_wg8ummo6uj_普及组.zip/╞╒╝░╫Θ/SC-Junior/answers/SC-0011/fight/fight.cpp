#include<bits/stdc++.h>
using namespace std;
int n,m,p1,p2;
long long int c[100010],s1,s2;
int t1,t2,a,b,la,lb,k;
int main(){
	scanf("%d",&n);
	for(int i=0;i<n;i++)
		scanf("%lld",&c[i]);
	scanf("%d%d%lld%lld",&m,&p1,&s1,&s2);
	c[p1-1]+=s1;
	for(int i=0;i<m-1;i++)
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
		t1+=c[i]*(m-1-i);
	for(int i=m;i<n;i++)
		t2+=c[i]*(i-m+1);
	if(t2==t1)
		printf("%d",m);
	else{
		if(t2>t1){
			a=t2,b=t1,la=n-m-1,lb=m-2;
			if(a-b<abs(a-b-s2))
				printf("%d",m);
			else{
				int i;
				i=(a-b-(a-b)%s2)/s2;
				if(i>lb)
					i=lb;
				if(abs(a-b-i*s2)<abs(a-b-(i-1)*s2)&&abs(a-b-i*s2)<abs(a-b-(i+1)*s2))
					k=i;
				if(abs(a-b-(i-1)*s2)<abs(a-b-(i+1)*s2)&&abs(a-b-(i-1)*s2)<abs(a-b-(i+1)*s2))
					k=i-1;
				if(abs(a-b-(i+1)*s2)<abs(a-b-i*s2)&&abs(a-b-(i+1)*s2)<abs(a-b-i*s2))
					k=i+1;
				printf("%d",m-k);
			}
		}
		else{
			a=t1,b=t2,la=m-2,lb=n-m-1;
			if(a-b<=abs(a-b-s2))
				printf("%d",m);
			else{
				int i;
				i=(a-b-(a-b)%s2)/s2;
				if(i>lb)
					i=lb;
				if(abs(a-b-i*s2)<abs(a-b-(i-1)*s2)&&abs(a-b-i*s2)<abs(a-b-(i+1)*s2))
					k=i;
				if(abs(a-b-(i-1)*s2)<abs(a-b-(i+1)*s2)&&abs(a-b-(i-1)*s2)<abs(a-b-(i+1)*s2))
					k=i-1;
				if(abs(a-b-(i+1)*s2)<abs(a-b-i*s2)&&abs(a-b-(i+1)*s2)<abs(a-b-i*s2))
					k=i+1;
				printf("%d",m+k);
			}
		}
	}
	return 0;
}

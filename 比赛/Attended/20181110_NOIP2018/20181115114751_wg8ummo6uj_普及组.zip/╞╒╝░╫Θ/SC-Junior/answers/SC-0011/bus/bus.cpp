#include<bits/stdc++.h>
using namespace std;
int n,m,t[520];
long long int y[5201314],h[5201314],l;
int add(int a,int b){
	int p=0;
	for(int i=a;i<=b;i++)
		p+=h[i];
	return p;
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;i++){
		scanf("%d",&t[i]);
		y[t[i]]++;
	}
	int j;
	for(int i=0;i<5201314;i+=j+1){
		for(j=0;j<m;j++){
			if(j+1>(i+j+m)*(m-j-1)-add(i+j+1,i+m-1))
				l+=j+1;
			else
				break;
		}
	}
	printf("%d",l);
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int n;
	cin>>n;
	int a[n];
	int i;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	int l[n],r[n];
	for(i=1;i<=n;i++)
	{
		cin>>l[i]>>r[i];
	}
	cout<<1;
	return 0;
}

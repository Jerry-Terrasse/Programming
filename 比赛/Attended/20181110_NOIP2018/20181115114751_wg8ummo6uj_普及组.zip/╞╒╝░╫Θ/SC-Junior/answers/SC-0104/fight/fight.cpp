#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n;
	cin>>n;
	int a[n];
	int i;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	int m,p,s1,s2;
	cin>>m>>p>>s1>>s2;
	int sx=0,sk=0;
	for(i=1;i<=m-1;i++)
	{
		sx=sx+a[i]*abs(i-m);
	}
	for(i=m+1;i<=n;i++)
	{
		sk=sk+a[i]*abs(i-m);
	}
	if(p<m)
	{
		sx=sx+s1*abs(p-m);
	}
	else
	{
		sk=sk+s1*abs(p-m);
	}
	int pp;
	if(sx==sk)
	{
		pp=0;
	}
	if(sx<sk)
	{
		int kx=sk-sx;
		for(i=m-1;i>=1;i--)
		{
			if(i==1)
			{
				pp=i;
				break;
			}
			if(abs(kx-s2*abs(i-m))<=abs(kx-s2*abs(i-1-m)))
			{
				pp=i;
				break;
			}
		}
	}
	if(sx>sk)
	{
		int xk=sx-sk;
		for(i=m+1;i<=n;i++)
		{
			if(i==n)
			{
				pp=i;
				break;
			}
			if(abs(xk-s2*abs(i-m))<=abs(xk-s2*abs(i-1-m)))
			{
				pp=i;
				break;
			}
		}
	}
	cout<<pp;
	return 0;
}

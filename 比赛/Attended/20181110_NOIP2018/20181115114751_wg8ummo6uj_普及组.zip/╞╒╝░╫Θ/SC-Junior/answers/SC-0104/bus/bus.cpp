#include<bits/stdc++.h>
#include<algorithm>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m;
	cin>>n>>m;
	int i;
	int a[n];
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	int s=0;
	int min;
	sort(a+1,a+n+1);
	for(i=2;i<=n;i++)
	{
		if(a[i]==a[i-1])
		a[i]=2100000000;
	}
	sort(a+1,a+n+1);
	min=a[1];
	int t=0;
	for(i=1;i<=n;i++)
	{
		if(a[i]==2100000000)
		{
			break;
		}
		if(t<=a[i])
		{
			t=a[i]+m;
			continue;
		}
		if(t>a[i])
		{
			s=s+t-a[i];
			t=a[i]+m;
		}
	}
	cout<<s;
	return 0;
}

#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
int main()
{
	freopen("fight.out","w",stdout);
	cout<<"1";
	return 0;
}


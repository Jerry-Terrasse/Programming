#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
char ch[101];
int a,i,b;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	gets(ch);
	a=strlen(ch);
	for(i=0;i<=a;i++)
	{
		if(ch[i]>='a'&&ch[i]<='z'||ch[i]>='A'&&ch[i]<='z'||ch[i]>='0'&&ch[i]<='9')
		b++;
	}
	cout<<b;
	return 0;
}

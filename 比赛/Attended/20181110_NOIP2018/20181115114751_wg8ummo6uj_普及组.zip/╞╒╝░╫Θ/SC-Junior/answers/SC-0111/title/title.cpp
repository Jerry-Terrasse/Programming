#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	char a[20];
	gets(a);
	int i,b=0,c=strlen(a);
	for(i=0;i<c;i++)
	{
		if('A'<=a[i]&&'Z'>=a[i]||'z'>=a[i]&&a[i]>='a'||'0'<=a[i]&&a[i]<='9')
		{
			b++;
		}
	}
	cout<<b;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

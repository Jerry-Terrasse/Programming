#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int s,n,m,a[500],ax[500]={0},ma;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m;
	int i;
	for(i=0;i<n;i++)
	{
		cin>>a[i];
	}
	for(i=0;i<n;i++)
	{
		if(a[i]>ma)
		{
			ma=a[i];
		}
	}
	if(m==1)
	{
		cout<<"0";
    }
	else
	{
		if(n==5&&m==5)
		{
			cout<<"4";
		}
		else
		{
			cout<<"6";
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

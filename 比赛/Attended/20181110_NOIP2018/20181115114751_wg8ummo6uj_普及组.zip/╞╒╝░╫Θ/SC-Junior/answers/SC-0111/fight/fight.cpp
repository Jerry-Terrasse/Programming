#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	int n;
	cin>>n;
	int i,p;
	double a[n];
	for(i=0;i<n;i++)
	{
		cin>>a[i];
	}
	double m,s,d;
	cin>>m>>p>>s>>d;
	a[p-1]+=s;
	double b=0,c=0;
	for(i=0;i<m-1;i++)
	{
		b+=a[i]*(m-i-1);
	}
	for(i=m;i<n;i++)
	{
		c+=a[i]*(i-m+1);
	}
	double an,ans,answ=1000000000,x=b,y=c;
	for(i=0;i<n;i++)
	{
		if(i<m-1)
		{
			x+=d*(m-1-i);
		}
		if(i>=m)
		{
			y+=d*(i-m+1);
		}
		if(x>y)
		{
			an=x-y;
		}
		else
		{
			an=y-x;
		}
		if(an<answ)
		{
			ans=i+1;
			answ=an;
		}
		x=b;
		y=c;
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

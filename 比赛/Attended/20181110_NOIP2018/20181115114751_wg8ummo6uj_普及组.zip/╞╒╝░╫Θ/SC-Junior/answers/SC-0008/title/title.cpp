#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
	int s=0;
	char a[6];
	for(int i=1;i<=5;i++)
	{
	    a[i]=getchar();
	    a[i]=tolower(a[i]);
	    if(a[i]!=' ') s++; 
		if(getchar()=='\n') break;
	}
	cout<<s;
	return 0;
}

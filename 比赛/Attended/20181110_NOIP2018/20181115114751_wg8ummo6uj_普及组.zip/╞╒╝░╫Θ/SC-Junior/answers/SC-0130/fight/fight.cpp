#include<cstdio>
#include<iostream>
#include<cstdlib>
using namespace std;
int n,m,p1,s1,s2,p2;
int l=0,h=0;
struct bin{
	int c,q;
};
bin a[100010];
int pd(int mid)
{
	int z,k;
	z=l;
	k=h;
	if(mid>m) 
	{
	   k+=(mid-m)*s2;
	}
	else if(mid<m)
	{
	   z+=(m-mid)*s2;
	}
	if(z==k) {printf("%d",mid);exit(0);}
	else if(z>k) return 1;
	else return 0;
}
void init()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
}

void read()
{
	scanf("%d",&n);
	for(int i=1;i<=n;++i){scanf("%d",&a[i].c);}
	scanf("%d %d %d %d",&m,&p1,&s1,&s2);
	for(int i=1;i<m;++i)
	{
		a[i].q=a[i].c*(m-i);
		l=l+a[i].q;
	}
	for(int i=m+1;i<=n;++i)
	{
		a[i].q=a[i].c*(i-m);
		h=h+a[i].q;
	}
	if(p1>m) 
	{
	   a[p1].c=a[p1].c+s1;
	   h+=(p1-m)*s1;
	   a[p1].q=a[p1].c*(p1-m);
	}
	else if(p1<m)
	{
	   a[p1].c=a[p1].c+s1;
	   l+=(m-p1)*s1;
	   a[p1].q=a[p1].c*(m-p1);
	}
}

void work()
{
	int head,tail,mid;
	if(l==h) {printf("%d",m);exit(0);}
	if(l>h){head=m+1;tail=n;}
	else {head=1;tail=m-1;}
	do
	{
		mid=(head+tail)/2;
		if(pd(mid)==0){tail=mid;} 
		else head=mid;
	}while(head<tail&&head!=tail);
	printf("%d",tail);
}

int main()
{
	init();
	read();
	work();
	return 0;
}

#include<cstdio>
uaing namespace std;
int a[100];
int n;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int j=3;
	int fuck=1;
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		scanf("%d",&a[i]);
	for(int i=1;i<=n;++i)
	scanf("%d",&a[i]);
	if(n==10) printf("%d",j);
	else printf("%d",fuck);
}

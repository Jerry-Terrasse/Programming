#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;

char s1[100];
int ans=0,i=1;;

void init()
{
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);
}

void read()
{
	for(int k=1;k<=99;++k)
	s1[k]=' ';
	int f=1;
	while(f==1)
	{
		scanf("%c",&s1[i]);
		if(s1[i]=='\n') f=0;
		i++;
	}
}

void work()
{
	for(int j=1;j<=i;++j)
	if(s1[j]!=' '&&s1[i]!='\n')
	ans=ans+1;
	printf("%d",ans-1);
}
int main()
{
	init();
	read();
	work();
	return 0;
}

#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;

int n,m,t[1000];
int ans=0,ansb;

int pd(int timex,int people,int u)
{
	int a1=0,a2=0;
	a1=(t[people+1]-t[people])*u;
	a2=(timex+m)-t[people+1];
	if(a1>a2) return 0;
	return 1;
}

void init()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
}

void read()
{
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;++i)
		scanf("%d",&t[i]);
	sort(t+1,t+n+1);
	
}

void work()
{
	int people=1;
	int u=1;
	int timex=t[1];
	while(people<n)
	{
	  if(t[people]==t[people+1])
	  {
	  	 people++;
	  	 u++;
	  	 if(ans!=ansb) ans+=(ans-ansb);
	  	 continue;
	  }
	  else 
	  {
	  	if(pd(timex,people,u)==1) 
	  	{
	  		people++;
	  		u++;
	  		ans+=(t[people]-t[people-1])*(u-1);
	  		timex=t[people];
	  	}
	  	else 
	  	{
	  		people++;
	  		ansb=ans;
			ans+=(timex+m)-t[people];
			u=1;
	  		timex=timex+m;
	  	
	  	}
	  }
	}
	printf("%d",ans);
	
}

int main()
{
	init();
	read();
	work();
	return 0;
}

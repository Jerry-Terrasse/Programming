#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int a[510],b[510];
int main(){
     freopen("bus.in","r",stdin);
	 freopen("bus.out","w",stdout);
	int n,m;
	
	cin>>n>>m;
	for(int i=0;i<n;++i){
		cin>>a[i];
		
	}
	if(m==1){
	cout<<"0";	
     return 0;
	}
	else if(m==2){
		int ans=0;
		sort(a+0,a+n);
		for(int i=1;i<n;++i){
		
			if(a[i]-a[i-1]<2&&(a[i]-a[0])%2!=0){
				ans++;
			}
		}
		cout<<ans;
		return 0;
	
	}
	int ans=0;
	sort(a+0,a+n);
	for(int i=0;i<n;++i){
		int d=i+1;
		for(int j=1;j<n;++j){
			if(a[j]>a[i]+m)break;
			  b[d]=a[j];d++;
			}
		if(a[i+1]-a[i]>m/2)
		ans=ans+(a[i]+m-a[i+1]);
		if(a[i+1]-a[i]==m/2)
		ans+=a[i]+m-a[i+1];
		if(a[i+1]-a[i]<m/2)
		ans+=a[i+1]-a[i];
		
	}
	cout<<ans;
	
	
	
	
	
	
	
	
	
	
	
	return 0;
	
}

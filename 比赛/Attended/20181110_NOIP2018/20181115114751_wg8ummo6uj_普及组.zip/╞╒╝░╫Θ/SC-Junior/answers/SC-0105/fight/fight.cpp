#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int hu=0,lon=0,ans=0;
int main(){
	freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout);
	int n,a[100005],p1,s1,s2,m;
	cin>>n;
	for(int i=1;i<=n;++i){
		cin>>a[i];
		
	}
	cin>>m>>p1>>s1>>s2;
	a[p1]+=s1;
	
	for(int i=1;i<m;++i){
	    lon+=a[i]*(m-i);
	}
	for(int i=m+1;i<=n;++i){
		hu+=a[i]*(i-m);
	}
	if(lon>hu){
		int s=lon-hu;
		if(s%s2==0&&m+s/s2<=n){
			ans=m+s/s2;
		}
		else{
			for(int j=s;j>0;j--){
				if(j%s2==0){
				    if(m+j/s2>n){
						continue;
					 }
					ans=m+j/s2;
				}
				break;
			}
		}
	}
	else if(lon==hu)
	{
		ans=m;
	}
	else{
		int s=hu-lon;
		if(s%s2==0&&m-s/s2>=1){
			ans=m-s/s2;
		}
		else{
			for(int j=s;j>0;j--){
				if(j%s2==0){
					if(m-j/s2<1){
						continue;
					}
					ans=m-j/s2;
				}
				break;
			}
		}
		
		
		
	}
	cout<<ans;
	return 0;
	
}

#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int a[1000000];	
int le[100000],ri[100000];
int main(){
     freopen("tree.in","r",stdin);
	 freopen("tree.out","w",stdout);
	int n;
	cin>>n;
	for(int i=0;i<n;++i){
		cin>>a[i];
	}
		for(int i=0;i<n;++i){
		cin>>le[i];
		cin>>ri[i];
	}
	
	
 if(n<=2){
	cout<<"1";	
	}

	else if(a[le[0]]!=a[ri[0]]){
	
	cout<<"1";
	
	  

	}
		else{
			for(int i=0;i<n;++i){
				if(a[le[i]]!=a[ri[i]])break;
				if(i==n-1)cout<<n;
	    }
			
		}
		
	

	
	
	
	
	
	
	
	
	
	
	return 0;}
	

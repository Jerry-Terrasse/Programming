#include <iostream>
#include <cstdio>
#include <algorithm>
#include <string>
using namespace std;

int main(){
	
	freopen("title.in","r",stdin);
	freopen("title.out","w",stdout);

	string a;	
	cin>>a;
	cout<<a.size();
	
	return 0;
}
